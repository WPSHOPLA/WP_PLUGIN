<?php

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Admin Class
 *
 * Handles generic Admin functionality and AJAX requests.
 *
 * @package Leads Phantom
 * @since 1.0.0
 */


class Lead_Phantom_Admin {

	public function __construct() {

	}

	/**
	 * Add Leads Phantom Menu
	 *
	 * @package Leads Phantom
	 * @since 1.0.0
	 */
	public function lead_phantom_squeeze_admin_menu() {

		add_theme_page( __( 'Phantom Settings', 'leadsphantom' ), __( 'Phantom Settings', 'leadsphantom' ), 'manage_options', 'squeeze-settings', array( $this, 'lead_phantom_squeeze_inner_custom_box' ) );
	}


	/**
	 * Save Leads Phantom Data
	 *
	 * @package Leads Phantom
	 * @since 1.0.0
	 */
	public function lead_phantom_squeeze_save_postdata() {

		global $squeeze_type;

		$type	= esc_attr( $squeeze_type );
		$squeeze_post_cat_enable	= isset( $_POST['squeeze_post_cat_enable'] ) ? $_POST['squeeze_post_cat_enable'] : array();

		update_option( 'squeeze-type', esc_attr( $squeeze_type ) );
		update_option( 'squeeze-url' . "_$type", $_POST['squeeze-url'] );
		update_option( 'squeeze-scroll' . "_$type", $_POST['squeeze-scroll'] );
		update_option( 'squeeze_post_category' . "_$type", $_POST['squeeze_post_category'] );
		update_option( 'squeeze_post_cat_enable' . "_$type", $squeeze_post_cat_enable );

		do_action( 'lead_phantom_save_admin_fields' );

		return;
	}


	/**
	 * Leads Phantom Setting Page
	 *
	 * Handle to leads phantom setting page
	 *
	 * @package Leads Phantom
	 * @since 1.0.0
	 */
	public function lead_phantom_squeeze_inner_custom_box() {

		global $squeeze_type;

		if ( isset( $_POST['action'] ) && $_POST['action'] == 'update-squeeze-settings') {
			$this->lead_phantom_squeeze_save_postdata();
			echo '<div class="updated settings-error" id="setting-error-settings_updated"><p><strong>Phantom Settings saved.</strong></p></div>';
		}

		$optin_cta = stripslashes_deep( get_option( 'squeeze-optin-cta' . "_$squeeze_type" ) );
		$optin_type	= stripslashes_deep( get_option( 'squeeze-optin-type' . "_$squeeze_type" ) );
		$optin_button = stripslashes_deep( get_option( 'squeeze-optin-button' . "_$squeeze_type" ) );
	    $footer_menu = stripslashes_deep( get_option( 'squeeze-footer-menu' . "_$squeeze_type" ) );
	    $register_settings = new LPP_Basic_Unlimited_Reg_Settings();
	    $register_settings->leads_phantom_start_maintenance_settings();
	    ?>

	    <style type="text/css">
			.squeeze-set { display: none; }
			.squeeze-set-default { display: block; }
			.center { text-align: center !important; }
			.bold { font-weight: bold; }
			.field {
				padding: 5px 0;
			}
			.field label {
				float: left; line-height: 23px; margin-right: 10px; display: block; width: 150px;
			}
			.field input.text, .field textarea, .field select {
				float: left; width:;
			}
			.field input.text {
				width: 450px;
			}
			.field textarea {
				width: 450px; min-height: 100px;
			}
			.field-squeeze-type label,
			.field-squeeze-type select {
				display: inline; float: none;
			}
			.add-list-item { margin-left: 160px; }
			.item .button { margin-left: 5px; }
			.list-items .item { padding: 0 0 10px 160px; }
			.list-items .item input { width: 350px; }
			.list-items label { line-height: 25px; }
			.squeeze-content-text textarea#content { height: 150px; }
		</style><?php

		$squeeze_scroll			= stripslashes_deep( get_option( 'squeeze-scroll' . "_$squeeze_type" ) );
		$squeeze_url			= stripslashes_deep( get_option( 'squeeze-url' . "_$squeeze_type" ) );
		$squeeze_post_category	= stripslashes_deep( get_option( 'squeeze_post_category' . "_$squeeze_type" ) );

		$squeeze_post_cat_enable= get_option('squeeze_post_cat_enable' . "_$squeeze_type" );?>

		<div class="wrap">
			<form action="" method="post" id="squeeze-type-form">
				<input id="squeeze-new-type" type="hidden" name="new-type" value="">
				<input type="hidden" name="action" value="update-squeeze-settings">

				<div id="squeeze-settings-sets">
					<h2><?php echo __( 'General Settings', 'leadsphantom' );?></h2>
					<img src="<?php echo LEADS_PHANTOM_URL . 'includes/images/leads-phantom-logo.png'; ?>" />
					<div class="field">
					    <label for="squeeze-url"><?php echo __( 'Default URL to show', 'leadsphantom' );?>:</label>
					    <input type="text" name="squeeze-url" id="squeeze-url" value="<?php echo $squeeze_url;?>" style="min-width:200px;">
					    <div class="clear"></div>
					</div>
					<div class="field">
					    <label for="squeeze-scroll-lock"><?php echo __( 'Enable Phantom', 'leadsphantom' );?>:</label>
					    <select name="squeeze-scroll" id="squeeze-scroll">
							<option value="">--<?php echo __( 'Choose', 'leadsphantom' );?>--</option>
							<option value="yes" <?php if( $squeeze_scroll == 'yes' ) echo 'selected';?>><?php echo __( 'Yes', 'leadsphantom' );?></option>
							<option value="no"<?php if( $squeeze_scroll == 'no' ) echo 'selected';?>><?php echo __( 'No', 'leadsphantom' );?></option>
						</select>
					    <div class="clear"></div>
					</div>
					<div class="clear"></div>
					<br />
					<strong><?php echo __( 'Category URL to Show', 'leadsphantom' );?></strong><br /><?php

						$args	= array(
										'type'			=> 'post',
										'taxonomy'		=> 'category',
										'hide_empty'	=> 0
									);

						$post_categories	= get_categories( $args );

						if( !empty( $post_categories ) ) { // if cetegories not empty
							foreach ( $post_categories as $post_category ) {

								$cat_ID		= isset( $post_category->cat_ID ) ? $post_category->cat_ID : '';
								$cat_value	= isset( $squeeze_post_category[$cat_ID] ) ? $squeeze_post_category[$cat_ID] : '';
								$cat_enable	= isset( $squeeze_post_cat_enable[$cat_ID] ) ? $squeeze_post_cat_enable[$cat_ID] : '';

								$checked	= '';

								if( $cat_enable == 1 ) {
									$checked = 'checked="checked"';
								}
								?>

								<div class="field">
									<label><?php echo __( 'URL to show', 'leadsphantom' );?>:</label>
									<input style="float:left;" type="text" name="squeeze_post_category[<?php echo $cat_ID;?>]" value="<?php echo $cat_value;?>" />
									<label style="margin-left:100px;"><?php echo $post_category->name;?></label>
									<input type="checkbox" value="1" name="squeeze_post_cat_enable[<?php echo $cat_ID;?>]" <?php echo $checked;?> />
								</div>
								<div class="clear"></div><?php
							}
						}
						?>
				</div>
				<?php do_action( 'lead_phantom_add_admin_fields' );?>
				<p class="submit">
					<input type="submit" value="<?php echo __( 'Save Changes', 'leadsphantom' );?>" class="button-primary" id="submit" name="submit">
				</p>
			</form>
		</div><?php
	}

	/**
	 * Adding Hooks
	 *
	 * @package Leads Phantom
	 * @since 1.0.0
	 */
	public function add_hooks() {

		add_action( 'admin_menu', array( $this, 'lead_phantom_squeeze_admin_menu' ) );
	}
}

class LPP_Basic_Unlimited_Reg_Settings {

	private $_name = 'Leads Phantom Basic Unlimited';
	private $_codename = 'leads_phantom_basic_unlimited_392';
	private $_pid = '0002';
	private $_api_url = 'http://www.licenseengine.com/licenses/a/';

	public function register_settings() {
		register_setting(sprintf($this->_codename), sprintf($this->_codename), array($this, 'leads_phantom_plugin_maintenance'));
	}

	function leads_phantom_plugin_maintenance($options) {

		if(isset($options) && ($options['license_key'] != ''))
		{
			$settings['license_key'] = $options['license_key'];
			$license = $options['license_key'];

			$api_params = array(
				'action' 	 => 'activate_license',
				'license' 	 => $license,
				'item_name'  => $this->_codename,
				'domain' 	 => urlencode($_SERVER['SERVER_NAME']),
				'product_id' => $this->_pid,
			);

			$response = wp_remote_get(add_query_arg($api_params, $this->_api_url), array('timeout' => 15, 'sslverify' => false));

			if(is_wp_error($response)) {
				return false;
			}

			$license_data = json_decode(wp_remote_retrieve_body($response));

			if(!empty($license_data) && $license_data->license == 'valid') {
				$data = array('timestamp' => time());
				update_option(sprintf($this->_codename) .'-lks', serialize($data));
				update_option(sprintf($this->_codename), $options['license_key']);
				return $settings;
			} elseif(!empty($license_data) && ($license_data->license == 'invalid')) {
				update_option(sprintf($this->_codename) .'-lks', $license_data->license);
				return $settings;
			} else {
				return false;
			}
		}
	}

	function leads_phantom_get_all_options()
	{
		$l = get_option(sprintf($this->_codename));
		$v = get_option(sprintf($this->_codename) .'-lks');
		$u = false;

		if(isset($v) && ($v !== 'invalid')) {
			$data = unserialize($v);
			if($data['timestamp'] > (time() - (24*60*60))) {
				return true;
			}
		}

		if($u == false) {

			$api_params = array(
				'action' 	 => 'activate_license',
				'license' 	 => $l,
				'item_name'  => $this->_codename,
				'domain' 	 => urlencode($_SERVER['SERVER_NAME']),
				'product_id' => $this->_pid,
			);

			$response = wp_remote_get(add_query_arg($api_params, $this->_api_url), array('timeout' => 15, 'sslverify' => false));


			if(is_wp_error($response)) {
				return false;
			}

			$license_data = json_decode(wp_remote_retrieve_body($response));

			if(!empty($license_data) && ($license_data->license == 'valid')) {
				$data = array('timestamp' => time());
				update_option(sprintf($this->_codename) .'-lks', serialize($data));
				return true;
			} elseif(!empty($license_data) && ($license_data->license == 'invalid')) {
				update_option(sprintf($this->_codename) .'-lks', $license_data->license);
				return false;
			} else {
				return false;
			}
		}
	}

	function leads_phantom_start_maintenance_settings()
	{
		if(isset($_POST['license_key'])) {
			$options = array('license_key' => $_POST['license_key']);
			$this->leads_phantom_plugin_maintenance($options);
		}

		$status = $this->leads_phantom_get_all_options();

		if($status==false): ?>
			<div style="margin-top:20px;padding:15px;font-size: 14px;width: 400px;border: 1px solid #cccccc;border-radius: 5px;">
				<div style="text-align: center">
					<img src="http://www.licenseengine.com/assets3/images/License-Engine-Lock-TransBG.png" alt="LicenseEngine.com Logo">
				</div>
				<h4><?php echo $this->_name .' Registration'; ?></h4>
				<p>Please register your copy to get updates and support.</p>

				<form method="post" action="" enctype="multipart/form-data" id="license_key">

					<?php settings_fields(sprintf($this->_codename)); ?>

					<div class="button-container" style="text-align: center;">
						<input id="license_key" name="license_key" type="text" class="input-xlarge" placeholder="Enter Your License Key" value=""/>
						<input type="submit" value="Save" id="save_button" class="button action"/>

						<p>Can't find your key? Login to
							<a href="//www.licenseengine.com/my-keys" target="_blank">License Engine</a> to retrieve your key.
						</p>
					</div>
				</form>
				<div style="float:right"><img src="//www.licenseengine.com/assets2/img/licensingpoweredbyLE.png"></div>
				<div style="clear: both"></div>
			</div>
			<?php die();
		endif;
	}
}
