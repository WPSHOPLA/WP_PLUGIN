<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Start the session if it's off.
if(!isset($_SESSION)) session_start();

/**
 * Admin Class
 *
 * Handles generic Public functionality and AJAX requests.
 *
 * @package Leads Phantom
 * @since 1.0.0
 */
class Lead_Phantom_Public {

	private $phantom_init, $phantom_links, $phantom_iframe;

	public function __construct() {
		$this->phantom_init 	= false;
		$this->phantom_links 	= true;
		$this->phantom_iframe 	= false;
	}

	/**
	 * Load a template to replace the current one and insert the iframe.
	 * @param mixed|string $template - The default template.
	 * @return mixed|string $template - A php file to use as a template.
	 * */
	public function lead_phantom_load_template( $template ) {

		global $squeeze_type, $lead_phantom_url;

		$squeeze_scroll	= get_option( 'squeeze-scroll_'. $squeeze_type );
		$uniqid = uniqid('iframe_');

		if( $squeeze_scroll == 'yes' ) {

			// lead phantom url
			$lead_phantom_url = get_option( 'squeeze-url_' . $squeeze_type );

			if( is_single() || is_category() ) {

				$cat_ID		= '';
				$categories = get_the_category();

				if( !empty( $categories ) )
					$cat_ID = isset( $categories[0]->cat_ID ) ? $categories[0]->cat_ID : '';

				if( !empty( $cat_ID ) ) {

					$squeeze_post_category		= stripslashes_deep( get_option( 'squeeze_post_category_' . $squeeze_type ) );
					$squeeze_post_cat_enable	= get_option( 'squeeze_post_cat_enable_' . $squeeze_type );

					$squeeze_cat_url	= isset( $squeeze_post_category[$cat_ID] ) ? $squeeze_post_category[$cat_ID] : '';
					$squeeze_cat_enable	= isset( $squeeze_post_cat_enable[$cat_ID] ) ? $squeeze_post_cat_enable[$cat_ID] : '';

					if( !empty( $squeeze_cat_url ) && $squeeze_cat_enable == 1 )
						$lead_phantom_url = $squeeze_cat_url;

				}
			}

			$file	= 'lead-phantom-page.php';
			$find[]	= $file;
			$find[]	= LEADS_PHANTOM_BASENAME . '/' . $file;

			if ( $file && !empty( $lead_phantom_url ) ) {

				$template = locate_template( $find );

				if ( !$template ) {
					$template = lead_phantom_get_templates_dir() . $file;
				}

				$_SESSION['lp_overlay_url'] = $lead_phantom_url;

				$this->phantom_iframe = true;
			}
		}

		wp_enqueue_script('phantom-link', plugin_dir_url(__FILE__) .'/phantom.min.js', array('jquery'), '1.1.18', true);
		/*wp_localize_script('phantom-link', 'phlnk', array(
			'url' => admin_url('admin-ajax.php'),
			'phantom_links' => $this->phantom_links ? '1' : 0,
			'phantom_iframe' => $this->phantom_iframe ? '1' : 0,
			'iframe_uid' => $uniqid,
		));*/

		return apply_filters( 'lead_phantom_load_template', $template );

	}

	/**
	 * Content Modifier
	 * Modifies post content to erase any trace of external links.
	 * @param string $matches - The matched link in link_phantom
	 * @return string - A string replacement for the link.
	 */
	public function modifier( $matches ) {

		$parsed_url = parse_url( $matches[1] );
		$domain = $parsed_url['scheme'] . '://' . $parsed_url['host'];
		$whitelist = array(); // This functionality might be added in the future.

		if(in_array($domain, $whitelist) || in_array($domain .'/', $whitelist))
			return $matches[0];

		$_SESSION['filtered'][] = array('content' => $matches[0], 'url' => $matches[1]);
		return '<span id="' . (count($_SESSION['filtered']) - 1) . '" class="phlnk"></span>';

	}

	/**
	 * Link Phantom
	 * Searches and hides links in the post content.
	 * @param mixed|string $content - The post / page content where the links must be hidden.
	 * @return mixed|string $content - The replaced content.
	 */
	public function link_phantom( $content ) {

		if(!$this->phantom_init)
			$_SESSION['filtered'] = array();

		$this->phantom_init = true;

		$content = preg_replace_callback('/<a.+?href="(.+?)".+?<\/a>/', array($this, 'modifier'), $content);
		$content = preg_replace_callback('/<iframe.+?src="(.+?)".+?<\/iframe>/', array($this, 'modifier'), $content);

		return $content;
	}

	/**
	 * Filtered Links
	 * Returns filtered link from the session to the ajax call.
	 */
	public function filtered() {

		die(json_encode($_SESSION['filtered']));

	}

	public function iframe() {
		if(isset($_POST['uid'])) {
			$uid = sanitize_text_field($_POST['uid']);
			if(isset($_SESSION[$uid])) {
				$iframe = json_encode($_SESSION[$uid]);
				die($iframe);
			}
		}

		die('Undefined.');
	}

	/**
	 * Register Hooks
	 * Registers the Plugin hooks for the template and phantom link functionality.
	 */
	public function add_hooks() {

		add_filter( 'template_include', array( $this, 'lead_phantom_load_template' ) );
		add_filter( 'the_content', array($this, 'link_phantom') );

		add_action('wp_ajax_lnk_filtered', array($this, 'filtered'));
		add_action('wp_ajax_nopriv_lnk_filtered', array($this, 'filtered'));

		add_action('wp_ajax_phantom_iframe', array($this, 'iframe'));
		add_action('wp_ajax_nopriv_phantom_iframe', array($this, 'iframe'));

	}
}
