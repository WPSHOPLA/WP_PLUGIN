$(function(){

		$.ajax({
			url: ajaxurl,
			data: {action: 'my_action_name'},
			type: 'post',
			async: false,
			success: function(output) { 
				splitData=output.split('|');
				iurl=splitData[1]; 
				if(splitData[0]=='yes'){
					height=window.innerHeight;
					width=window.innerWidth;
					bgclick=false;
				}
				else if(splitData[0]=='no'){
					height=400;
					width=600;
					bgclick=true;
				}
			},
			
		});
		//console.log(splitData[1]);
		console.log(iurl);
		$('#b4').frameWarp({
			url : iurl,
			cache:false,
			width:width,
			height:height,
			closeOnBackgroundClick: bgclick,
		});
		//$('#b4').trigger('click');

});