<?php

// This file's functionality has been moved to:
// templates/leads-phantom-page.php