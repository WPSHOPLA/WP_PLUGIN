<?php

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Admin Class
 *
 * Handles generic Admin functionality and AJAX requests.
 *
 * @package Leads Phantom
 * @since 1.0.0
 */


class Lead_Phantom_Admin {

	public function __construct() {

	}

	/**
	 * Add Leads Phantom Menu
	 *
	 * @package Leads Phantom
	 * @since 1.0.0
	 */
	public function lead_phantom_squeeze_admin_menu() {

		add_theme_page( __( 'Phantom Settings', 'leadsphantom' ), __( 'Phantom Settings', 'leadsphantom' ), 'manage_options', 'squeeze-settings', array( $this, 'lead_phantom_squeeze_inner_custom_box' ) );
	}


	/**
	 * Save Leads Phantom Data
	 *
	 * @package Leads Phantom
	 * @since 1.0.0
	 */
	public function lead_phantom_squeeze_save_postdata() {

		global $squeeze_type;

		$type	= esc_attr( $squeeze_type );
		$squeeze_post_cat_enable	= isset( $_POST['squeeze_post_cat_enable'] ) ? $_POST['squeeze_post_cat_enable'] : array();
		$squeeze_page_overlay_enable = isset( $_POST['lp_lc_page_enable'] ) ? $_POST['lp_lc_page_enable'] : array();

		switch($_POST['ph_title_position']) {
			case '1': $title_position = 'left'; break;
			case '2': $title_position = 'right'; break;
			case '3': $title_position = 'center'; break;
			case '4': $title_position = 'justified'; break;
			default: $title_position = 'left';
		}

		update_option('ph_title_settings', array(
			'enable' 	 => boolval($_POST['ph_title_enable']),
			'position'   => $title_position,
			'font_size'  => intval($_POST['ph_title_font_size']),
			'padding' 	 => intval($_POST['ph_title_padding']),
			'color' 	 => $_POST['ph_title_text_color'],
			'background' => $_POST['ph_title_background'],
		));

		update_option( 'squeeze-type', esc_attr( $squeeze_type ) );
		update_option( 'squeeze-url' . "_$type", $_POST['squeeze-url'] );
		update_option( 'squeeze-scroll' . "_$type", $_POST['squeeze-scroll'] );
		update_option( 'squeeze_post_category' . "_$type", $_POST['squeeze_post_category'] );
		update_option( 'squeeze_post_cat_enable' . "_$type", $squeeze_post_cat_enable );
		update_option( 'lp_lc_page_url'. "_$type", $_POST['lp_lc_page_url']);
		update_option( 'lp_lc_page_enable'. "_$type", $squeeze_page_overlay_enable );

		do_action( 'lead_phantom_save_admin_fields' );

		return;
	}


	/**
	 * Leads Phantom Setting Page
	 *
	 * Handle to leads phantom setting page
	 *
	 * @package Leads Phantom
	 * @since 1.0.0
	 */
	public function lead_phantom_squeeze_inner_custom_box() {

		global $squeeze_type, $wpdb;

		if ( isset( $_POST['action'] ) && $_POST['action'] == 'update-squeeze-settings') {
			$this->lead_phantom_squeeze_save_postdata();
			echo '<div class="updated settings-error" id="setting-error-settings_updated"><p><strong>Phantom Settings saved.</strong></p></div>';
		}

		$optin_cta = stripslashes_deep( get_option( 'squeeze-optin-cta' . "_$squeeze_type" ) );
		$optin_type	= stripslashes_deep( get_option( 'squeeze-optin-type' . "_$squeeze_type" ) );
		$optin_button = stripslashes_deep( get_option( 'squeeze-optin-button' . "_$squeeze_type" ) );
	    $footer_menu = stripslashes_deep( get_option( 'squeeze-footer-menu' . "_$squeeze_type" ) );
	    $register_settings = new LPP_LC_Unlimited_Reg_Settings();
		$register_settings->leads_phantom_start_maintenance_settings();
	    ?>

	    <style type="text/css">
			.squeeze-set { display: none; }
			.squeeze-set-default { display: block; }
			.center { text-align: center !important; }
			.bold { font-weight: bold; }
			.field {
				padding: 5px 0;
			}
			.field label {
				float: left; line-height: 23px; margin-right: 10px; display: block; width: 150px;
			}
			.field input.text, .field textarea, .field select {
				float: left; width:;
			}
			.field input.text {
				width: 450px;
			}
			.field textarea {
				width: 450px; min-height: 100px;
			}
			.field-squeeze-type label,
			.field-squeeze-type select {
				display: inline; float: none;
			}
			.add-list-item { margin-left: 160px; }
			.item .button { margin-left: 5px; }
			.list-items .item { padding: 0 0 10px 160px; }
			.list-items .item input { width: 350px; }
			.list-items label { line-height: 25px; }
			.squeeze-content-text textarea#content { height: 150px; }
		</style><?php

		$squeeze_scroll			= stripslashes_deep( get_option( 'squeeze-scroll' . "_$squeeze_type" ) );
		$squeeze_url			= stripslashes_deep( get_option( 'squeeze-url' . "_$squeeze_type" ) );
		$title_settings 		= get_option('ph_title_settings');
		$squeeze_post_category	= stripslashes_deep( get_option( 'squeeze_post_category' . "_$squeeze_type" ) );
		$squeeze_post_cat_enable= get_option('squeeze_post_cat_enable' . "_$squeeze_type" );


		$squeeze_page_url = get_option( 'lp_lc_page_url_'. $squeeze_type );
		$squeeze_page_enable = get_option( 'lp_lc_page_enable_'. $squeeze_type );

		$get_pages_sql = "SELECT id, post_title FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status = 'publish' ORDER BY id DESC";
		$pages = $wpdb->get_results($get_pages_sql); ?>

		<div class="wrap">
			<form action="" method="post" id="squeeze-type-form">
				<input id="squeeze-new-type" type="hidden" name="new-type" value="">
				<input type="hidden" name="action" value="update-squeeze-settings">

				<div id="squeeze-settings-sets">
					<h2><?php echo __( 'General Settings', 'leadsphantom' );?></h2>
					<img src="<?php echo LEADS_PHANTOM_URL . 'includes/images/leads-phantom-logo.png'; ?>" />
					<div class="field">
					    <label for="squeeze-url"><?php echo __( 'Default URL to show', 'leadsphantom' );?>:</label>
					    <input type="text" name="squeeze-url" id="squeeze-url" value="<?php echo $squeeze_url;?>" style="min-width:200px;">
					    <div class="clear"></div>
					</div>
					<div class="field">
					    <label for="squeeze-scroll-lock"><?php echo __( 'Enable Phantom', 'leadsphantom' );?>:</label>
					    <select name="squeeze-scroll" id="squeeze-scroll">
							<option value="yes" <?php if( $squeeze_scroll == 'yes' ) echo 'selected';?>><?php echo __( 'Yes', 'leadsphantom' );?></option>
							<option value="no"<?php if( $squeeze_scroll == 'no' ) echo 'selected';?>><?php echo __( 'No', 'leadsphantom' );?></option>
						</select>
					    <div class="clear"></div>
					</div>

					<!-- Title Settings -->
					<div class="field">
						<label>Enable Title :</label>
						<select name="ph_title_enable">
							<?php $ph_title_enable = isset($title_settings['enable'])
							? boolval($title_settings['enable']) : false; ?>
							<option value="1" <?php echo $ph_title_enable ? 'selected' : ''; ?>>Yes</option>
							<option value="0" <?php echo !$ph_title_enable ? 'selected' : ''; ?>>No</option>
						</select>
						<div class="clear"></div>
					</div>
					<div class="field">
						<label>Set title position :</label>
						<select name="ph_title_position">
							<?php $ph_title_position = isset($title_settings['position']) ? $title_settings['position'] : 'left'; ?>
							<option value="1" <?php if($ph_title_position == 'left') echo 'selected' ?>>Left</option>
							<option value="2" <?php if($ph_title_position == 'right') echo 'selected' ?>>Right</option>
							<option value="3" <?php if($ph_title_position == 'center') echo 'selected' ?>>Center</option>
							<option value="4" <?php if($ph_title_position == 'justified') echo 'selected' ?>>Justified</option>
						</select>
						<div class="clear"></div>
					</div>
					<div class="field">
						<label>Set font size :</label>
						<?php $ph_title_font_size = (isset($title_settings['font_size']) && boolval($title_settings['font_size'])) ? $title_settings['font_size'] : '';
						?>
						<input type="text" name="ph_title_font_size" style="width:64px" placeholder="default" value="<?php echo $ph_title_font_size; ?>"> px
						<div class="clear"></div>
					</div>
					<div class="field">
						<label>Set title padding :</label>
						<?php $ph_title_padding = (isset($title_settings['padding']) && boolval($title_settings['padding'])) ? $title_settings['padding'] : '';
						?>
						<input type="text" name="ph_title_padding" style="width:64px" placeholder="default" value="<?php echo $ph_title_padding; ?>"> px
						<div class="clear"></div>
					</div>
					<div class="field">
						<label>Set title text color :</label>
						<?php $ph_title_text_color = isset($title_settings['color']) ? $title_settings['color'] : ''; ?>
						<input type="text" name="ph_title_text_color" id="ph_title_text_color" value="<?php echo $ph_title_text_color; ?>">
						<div class="clear"></div>
					</div>
					<div class="field">
						<label>Set title background :</label>
						<?php $ph_title_background = isset($title_settings['background']) ? $title_settings['background'] : ''; ?>
						<input type="text" name="ph_title_background" id="ph_title_background" value="<?php echo $ph_title_background; ?>">
						<div class="clear"></div>
					</div>


					<div class="clear">&nbsp;</div>
					<hr><br>
					<p><strong><?php echo __( 'Overlay Categories', 'leadsphantom' );?></strong></p>
					<?php

						$args	= array(
										'type'			=> 'post',
										'taxonomy'		=> 'category',
										'hide_empty'	=> 0
									);

						$post_categories	= get_categories( $args );

						if( !empty( $post_categories ) ) { // if cetegories not empty
							foreach ( $post_categories as $post_category ) {

								$cat_ID		= isset( $post_category->cat_ID ) ? $post_category->cat_ID : '';
								$cat_value	= isset( $squeeze_post_category[$cat_ID] ) ? $squeeze_post_category[$cat_ID] : '';
								$cat_enable	= isset( $squeeze_post_cat_enable[$cat_ID] ) ? $squeeze_post_cat_enable[$cat_ID] : '';

								$checked	= '';

								if( $cat_enable == 1 ) {
									$checked = 'checked="checked"';
								}
								?>

								<div class="field">
									<label><?php echo $post_category->name;?></label>
									<input type="text" name="squeeze_post_category[<?php echo $cat_ID;?>]" value="<?php echo $cat_value;?>" style="margin-right:30px" />
									<input type="checkbox" value="1" name="squeeze_post_cat_enable[<?php echo $cat_ID;?>]" <?php echo $checked;?> />
								</div>
								<div class="clear"></div><?php
							}
						}
						?>

					<div class="clear">&nbsp;</div>
					<hr><br>
					<p><strong>Overlay Pages</strong></p>
					<?php if(count($pages)):
						foreach($pages as $page):

							$page_overlay_url = isset($squeeze_page_url[$page->id]) ? $squeeze_page_url[$page->id] : '';
							$page_overlay_enable = isset($squeeze_page_enable[$page->id]) ? $squeeze_page_enable[$page->id] : false;

							print '<div class="field">';
							printf('<label>%s</label>', $page->post_title);
							printf('<input type="text" name="lp_lc_page_url[%s]" value="%s" style="margin-right:30px">', $page->id, $page_overlay_url);
							printf('<input type="checkbox" name="lp_lc_page_enable[%s]" %s>', $page->id, ($page_overlay_enable ? 'checked' : ''));
							print '</div>';
						endforeach;
					endif; ?>


				</div>
				<?php do_action( 'lead_phantom_add_admin_fields' );?>
				<p class="submit">
					<input type="submit" value="<?php echo __( 'Save Changes', 'leadsphantom' );?>" class="button-primary" id="submit" name="submit">
				</p>
			</form>
		</div><?php
	}

	public function leads_phantom_enqueue_scripts() {
		wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('lpp-color-picker', LEADS_PHANTOM_URL .'/includes/colorpicker.js',
        	array('wp-color-picker'));
	}

	/**
	 * Adding Hooks
	 *
	 * @package Leads Phantom
	 * @since 1.0.0
	 */
	public function add_hooks() {

		add_action( 'admin_menu', array( $this, 'lead_phantom_squeeze_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'leads_phantom_enqueue_scripts' ) );
	}
}

class LPP_LC_Unlimited_Reg_Settings {

	private $_name = 'Leads Phantom Local Conversion Unlimited';
	private $_codename = 'leads_phantom_local_conversion_unlimited_402';
	private $_pid = '0006';
	private $_api_url = 'http://www.licenseengine.com/licenses/a/';

	public function register_settings() {
		register_setting(sprintf($this->_codename), sprintf($this->_codename), array($this, 'leads_phantom_plugin_maintenance'));
	}

	function leads_phantom_plugin_maintenance($options) {

		if(isset($options) && ($options['license_key'] != ''))
		{
			$settings['license_key'] = $options['license_key'];
			$license = $options['license_key'];

			$api_params = array(
				'action' 	 => 'activate_license',
				'license' 	 => $license,
				'item_name'  => $this->_codename,
				'domain' 	 => urlencode($_SERVER['SERVER_NAME']),
				'product_id' => $this->_pid,
			);

			$response = wp_remote_get(add_query_arg($api_params, $this->_api_url), array('timeout' => 15, 'sslverify' => false));

			if(is_wp_error($response)) {
				return false;
			}

			$license_data = json_decode(wp_remote_retrieve_body($response));

			if(!empty($license_data) && $license_data->license == 'valid') {
				$data = array('timestamp' => time());
				update_option(sprintf($this->_codename) .'-lks', serialize($data));
				update_option(sprintf($this->_codename), $options['license_key']);
				return $settings;
			} elseif(!empty($license_data) && ($license_data->license == 'invalid')) {
				update_option(sprintf($this->_codename) .'-lks', $license_data->license);
				return $settings;
			} else {
				return false;
			}
		}
	}

	function leads_phantom_get_all_options()
	{
		$l = get_option(sprintf($this->_codename));
		$v = get_option(sprintf($this->_codename) .'-lks');
		$u = false;

		if(isset($v) && ($v !== 'invalid')) {
			$data = unserialize($v);
			if($data['timestamp'] > (time() - (24*60*60))) {
				return true;
			}
		}

		if($u == false) {

			$api_params = array(
				'action' 	 => 'activate_license',
				'license' 	 => $l,
				'item_name'  => $this->_codename,
				'domain' 	 => urlencode($_SERVER['SERVER_NAME']),
				'product_id' => $this->_pid,
			);

			$response = wp_remote_get(add_query_arg($api_params, $this->_api_url), array('timeout' => 15, 'sslverify' => false));


			if(is_wp_error($response)) {
				return false;
			}

			$license_data = json_decode(wp_remote_retrieve_body($response));

			if(!empty($license_data) && ($license_data->license == 'valid')) {
				$data = array('timestamp' => time());
				update_option(sprintf($this->_codename) .'-lks', serialize($data));
				return true;
			} elseif(!empty($license_data) && ($license_data->license == 'invalid')) {
				update_option(sprintf($this->_codename) .'-lks', $license_data->license);
				return false;
			} else {
				return false;
			}
		}
	}

	function leads_phantom_start_maintenance_settings()
	{
		if(isset($_POST['license_key'])) {
			$options = array('license_key' => $_POST['license_key']);
			$this->leads_phantom_plugin_maintenance($options);
		}

		$status = $this->leads_phantom_get_all_options();

		if($status==false): ?>
			<div style="margin-top:20px;padding:15px;font-size: 14px;width: 400px;border: 1px solid #cccccc;border-radius: 5px;">
				<div style="text-align: center">
					<img src="http://www.licenseengine.com/assets3/images/License-Engine-Lock-TransBG.png" alt="LicenseEngine.com Logo">
				</div>
				<h4><?php echo $this->_name .' Registration'; ?></h4>
				<p>Please register your copy to get updates and support.</p>

				<form method="post" action="" enctype="multipart/form-data" id="license_key">

					<?php settings_fields(sprintf($this->_codename)); ?>

					<div class="button-container" style="text-align: center;">
						<input id="license_key" name="license_key" type="text" class="input-xlarge" placeholder="Enter Your License Key" value=""/>
						<input type="submit" value="Save" id="save_button" class="button action"/>

						<p>Can't find your key? Login to
							<a href="//www.licenseengine.com/my-keys" target="_blank">License Engine</a> to retrieve your key.
						</p>
					</div>
				</form>
				<div style="float:right"><img src="//www.licenseengine.com/assets2/img/licensingpoweredbyLE.png"></div>
				<div style="clear: both"></div>
			</div>
			<?php die();
		endif;
	}
}
