(function($) {

	$(document).ready(function() {

		$('#ph_title_text_color').wpColorPicker();
		$('#ph_title_background').wpColorPicker();

	});

})(jQuery);
