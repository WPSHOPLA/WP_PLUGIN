<?php
/**
 * Returns the path to the leads phantom templates directory
 *
 * @package Leads Phantom
 * @since 1.0.0
 */
function lead_phantom_get_templates_dir() {

	return apply_filters( 'lead_phantom_get_templates_dir', LEADS_PHANTOM_DIR . '/includes/templates/' );
}

if(!function_exists('boolval')) {
	function boolval($value = false) {
		if( ($value == false) || empty($value) || ($value == '')
			|| ($value == null) || ($value == 0) ) {
			return false;
		}

		return true;
	}
}
