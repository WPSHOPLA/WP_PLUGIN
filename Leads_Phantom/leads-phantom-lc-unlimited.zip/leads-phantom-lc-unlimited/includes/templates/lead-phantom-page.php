<?php

/**
 * Leads Phantom Template
 *
 * Displays all the content for the leads phantom.
 *
 * Override this template by copying it to yourtheme/leads-phantom/lead-phantom-page.php
 *
 * @author Leads Phantom
 * @package Leads-Phantom/Includes/Templates
 * @version 1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

global $squeeze_type;
global $leads_phantom_url;

$title_settings = get_option('ph_title_settings');

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">
	<title><?php wp_title( '|', true, 'right' ); ?></title>
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<!--[if lt IE 9]>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js"></script>
	<![endif]-->
	<?php wp_head(); ?>
	<link rel="stylesheet" href="<?php echo LEADS_PHANTOM_URL .'includes/squeezes/'. $squeeze_type . '/style.css'; ?>" type="text/css" media="screen"/>
	<?php if(isset($_SESSION['lp_overlay_url'])) {
		printf('<script>var lp_overlay_url = "%s";</script>', $_SESSION['lp_overlay_url']);
		unset($_SESSION['lp_overlay_url']);
	} ?>
</head>
<body <?php body_class(); ?>>

	<?php if(isset($title_settings['enable']) && boolval($title_settings['enable'])) {
		$style = '';
		$text_style = '';

		if(isset($title_settings['font_size']) && boolval($title_settings['font_size'])) {
			$style .= 'font-size:'. $title_settings['font_size'] .'px;';
		}
		if(isset($title_settings['color']) && boolval($title_settings['color'])) {
			$style .= 'color:'. $title_settings['color'] .';';
		}
		if(isset($title_settings['background']) && boolval($title_settings['background'])) {
			$style .= 'background-color:'. $title_settings['background'] .';';
		}

		if(isset($title_settings['position']) && boolval($title_settings['position'])) {
			$text_style .= 'text-align:'. $title_settings['position'] .';';
			if(isset($title_settings['padding']) && boolval($title_settings['padding'])) {
				switch($title_settings['position']) {
				    case 'left': $text_style .= 'padding-left:'. intval($title_settings['padding']) .'px;'; break;
				    case 'right': $text_style .= 'padding-right:'. intval($title_settings['padding']) .'px;'; break;
				}
			}
		}

		echo sprintf('<div id="lpp-title-container" style="%s"><h1 style="%s">%s</h1></div>', $style, $text_style, get_the_title());

	} ?>

	<div id="url-wrapper"></div>

	<div style="display:none;visibility:hidden;">
		<div id="primary" class="content-area">
			<main id="main" class="site-main" role="main">

				<?php
				// Start the loop.
				while ( have_posts() ) : the_post();

					// Include the page content template.
					get_template_part( 'content', 'page' );

					// If comments are open or we have at least one comment, load up the comment template.
					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;

					// End the loop.
				endwhile;
				?>

			</main><!-- .site-main -->
		</div><!-- .content-area -->

		<?php get_sidebar(); ?>

	</div>

	<?php wp_footer(); ?>

</body>
</html>
