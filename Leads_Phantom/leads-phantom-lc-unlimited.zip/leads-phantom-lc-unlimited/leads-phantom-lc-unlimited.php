<?php
/**
 * Plugin Name: Leads Phantom Local Conversion Unlimited
 * Plugin URI: http://leadsphantom.com
 * Description: Leads Phantom Basic WordPress Plugin
 * Version: 2.0.0
 * Author: ASM
 * Author URI: http://leadsphantom.com
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Basic plugin definitions
 *
 * @package Leads Phantom
 * @since 1.0.0
 */
global $wpdb;

if( !defined( 'LEADS_PHANTOM_VERSION' ) ) {
	define( 'LEADS_PHANTOM_VERSION', '1.0.0' ); //version of plugin
}
if( !defined( 'LEADS_PHANTOM_DIR' ) ) {
	define( 'LEADS_PHANTOM_DIR', dirname( __FILE__ ) ); // plugin dir
}
if( !defined( 'LEADS_PHANTOM_URL' ) ) {
	define( 'LEADS_PHANTOM_URL', plugin_dir_url( __FILE__ ) ); // plugin url
}
if( !defined( 'LEADS_PHANTOM_BASENAME') ) {
	define( 'LEADS_PHANTOM_BASENAME', basename( LEADS_PHANTOM_DIR ) ); // plugin base name
}
if( !defined( 'LEADS_PHANTOM_ADMIN' ) ) {
	define( 'LEADS_PHANTOM_ADMIN', LEADS_PHANTOM_DIR . '/includes/admin' ); // plugin admin dir
}
if( !defined( 'LEADS_PHANTOM_SQUEEZE' ) ) {
	define( 'LEADS_PHANTOM_SQUEEZE', 'video-squeeze-01' ); //
}

require_once( LEADS_PHANTOM_DIR . '/includes/geoip.inc' );

if(!function_exists('get_client_ip')) {
    function get_client_ip()
    {
        $ipaddress = '';
        if ($_SERVER['HTTP_CLIENT_IP'])
            $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
        else if ($_SERVER['HTTP_CF_CONNECTING_IP'])
            $ipaddress = $_SERVER['HTTP_CF_CONNECTING_IP'];
        else if ($_SERVER['HTTP_X_FORWARDED_FOR'])
            $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        else if ($_SERVER['HTTP_X_FORWARDED'])
            $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
        else if ($_SERVER['HTTP_FORWARDED_FOR'])
            $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
        else if ($_SERVER['HTTP_FORWARDED'])
            $ipaddress = $_SERVER['HTTP_FORWARDED'];
        else if ($_SERVER['REMOTE_ADDR'])
            $ipaddress = $_SERVER['REMOTE_ADDR'];
        else
            $ipaddress = 'UNKNOWN';

        return $ipaddress;
    }
}

if(!function_exists('is_bot')) {
    function is_bot()
    {
        //get user ip address
        $userip = get_client_ip();
        //load geoip database
        $gi = geoip_open(LEADS_PHANTOM_DIR . '/includes/GeoIPASNum.dat', GEOIP_STANDARD);
        //ip to organisation
        $ip_org = geoip_name_by_addr($gi, $userip);
        //close geoip database
        geoip_close($gi);
        //detect bots by asn
        if (strpos($ip_org, 'Google') || strpos($ip_org, 'Savvis') || strpos($ip_org, 'Microsoft') || strpos($ip_org, 'Yandex') || strpos($ip_org, 'Yahoo')){
            return true;
        } else {
            return false;
        }

    }
}

/**
 * Load Text Domain
 *
 * This gets the plugin ready for translation.
 *
 * @package Leads Phantom
 * @since 1.0.0
 */
function leads_phantom_load_textdomain() {

	// Set filter for plugin's languages directory
	$leads_phantom_lang_dir	= dirname( plugin_basename( __FILE__ ) ) . '/languages/';
	$leads_phantom_lang_dir	= apply_filters( 'leads_phantom_languages_directory', $leads_phantom_lang_dir );

	// Traditional WordPress plugin locale filter
	$locale	= apply_filters( 'plugin_locale',  get_locale(), 'leadsphantom' );
	$mofile	= sprintf( '%1$s-%2$s.mo', 'leadsphantom', $locale );

	// Setup paths to current locale file
	$mofile_local	= $leads_phantom_lang_dir . $mofile;
	$mofile_global	= WP_LANG_DIR . '/' . LEADS_PHANTOM_BASENAME . '/' . $mofile;

	if ( file_exists( $mofile_global ) ) { // Look in global /wp-content/languages/leads-phantom folder
		load_textdomain( 'leadsphantom', $mofile_global );
	} elseif ( file_exists( $mofile_local ) ) { // Look in local /wp-content/plugins/leads-phantom/languages/ folder
		load_textdomain( 'leadsphantom', $mofile_local );
	} else { // Load the default language files
		load_plugin_textdomain( 'leadsphantom', false, $leads_phantom_lang_dir );
	}
}

/**
 * Activation Hook
 *
 * Register plugin activation hook.
 *
 * @package Leads Phantom
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'leads_phantom_install' );

/**
 * Plugin Setup (On Activation)
 *
 * Does the initial setup,
 * stest default values for the plugin options.
 *
 * @package Leads Phantom
 * @since 1.0.0
 */
function leads_phantom_install() {

}

add_action( 'plugins_loaded', 'leads_phantom_plugins_loaded' );

/**
 * Plugin Loaded
 *
 * Handle plugin loaded
 *
 * @package Leads Phantom
 * @since 1.0.0
 */
function leads_phantom_plugins_loaded() {

	//Gets the plugin ready for translation
	leads_phantom_load_textdomain();

	/**
	 * Deactivation Hook
	 *
	 * Register plugin deactivation hook.
	 *
	 * @package Leads Phantom
	 * @since 1.0.0
	 */
	register_deactivation_hook( __FILE__, 'leads_phantom_uninstall' );

	/**
	 * Plugin Setup (On Deactivation)
	 *
	 * Delete  plugin options.
	 *
	 * @package Leads Phantom
	 * @since 1.0.0
	 */
	function leads_phantom_uninstall() {

	}

	//Global variables
	global $squeeze_type, $leads_phantom_admin, $leads_phantom_public;

	$squeeze_type = LEADS_PHANTOM_SQUEEZE;

	//Misc Functions
	require_once( LEADS_PHANTOM_DIR . '/includes/lead-phantom-misc-functions.php' );

	//Public related functionality
    if(!is_bot()){
		require_once( LEADS_PHANTOM_DIR . '/includes/class-lead-phantom-public.php' );
		$wp_leads_phantom_public	= new Lead_Phantom_Public();
		$wp_leads_phantom_public->add_hooks();
	}
	//Admin related functionality
	require_once( LEADS_PHANTOM_ADMIN . '/class-lead-phantom-admin.php' );
	$wp_leads_phantom_admin	= new Lead_Phantom_Admin();
	$wp_leads_phantom_admin->add_hooks();
}
