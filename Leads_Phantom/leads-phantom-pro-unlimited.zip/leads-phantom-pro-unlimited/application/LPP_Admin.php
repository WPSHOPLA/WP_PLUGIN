<?php if(!defined('ABSPATH')) exit;

/**
 * LLP_Admin
 * Handles the admin panel hooks and views and
 * manages plugin data.
 */
class LPP_Admin extends Leads_Phantom_Pro
{
    public $_db;
    public $_table;

    public function __construct($database, $table) {

        // Start the session
        if(!isset($_SESSION)) session_start();

        $this->_db = $database;
        $this->_table = $table;

        add_action('admin_init', array($this, 'admin_init'));
        add_action('admin_menu', array($this, 'admin_menu'));

        if(isset($_REQUEST[get_config('paypal.listener')])) {
            $this->paypal_ipn($_REQUEST);
        }

    }

    /*------------------------------------------------------------------------------------------------------------------
     * Views
     -----------------------------------------------------------------------------------------------------------------*/

    public function page_index() {

        $settings = array(
            'enable_overlay'    => get_option('lpp_enable_overlay'),
            'default_url'       => get_option('lpp_default_overlay_url'),
            'title'             => get_option('lpp_title_overlay_settings'),
            'categories'        => get_option('lpp_category_overlay_settings'),
        );

        $categories = get_categories(array(
            'type'			=> 'post',
            'taxonomy'		=> 'category',
            'hide_empty'	=> 0
        ));

        $this->view('index', array(
            'settings'       => $settings,
            'categories'     => $categories,
        ));
    }

    public function page_phantom_links() {

        $settings = get_option('lpp_hidden_links_settings');

        if(isset($settings['allowed']) && is_array($settings['allowed'])) {
            $settings['allowed'] = implode("\n", $settings['allowed']);
        } else {
            $settings['allowed'] = '';
        }

        $this->view('links', compact('settings'));

    }

    public function page_lease_settings() {

        $settings = array(
            'cta'   => get_option('lpp_lease_cta_settings'),
            'popup' => get_option('lpp_lease_popup_settings'),
        );

        $this->view('lease_settings', compact('settings'));

    }

    public function page_lease_control() {

        $wpdb = $this->_db;
        $table = $this->_table;

        // This right here is called Advanced SQL
        // It took me like 15 min. to setup properly
        $sql = "SELECT p.*, l.completed, l.lease_end_date FROM $wpdb->posts p
          LEFT OUTER JOIN $table l ON p.ID = l.post_id AND l.lease_end_date > NOW()
          WHERE (p.post_type = 'page' OR p.post_type = 'post')
          AND p.post_status = 'publish'
          GROUP BY p.ID
          ORDER BY p.post_date DESC
        ";

        $posts = $wpdb->get_results($sql, OBJECT);
        $this->view('lease_control', compact('posts'));
    }

    public function page_leads() {

        $wpdb = $this->_db;
        $table = $this->_table;

        if(isset($_GET['email']) && isset($_SESSION['lpp_email_id_bucket'])) {

            $bucket = $_SESSION['lpp_email_id_bucket'];
            $users = $wpdb->get_results("SELECT email FROM $table WHERE ID IN(". implode(',', $bucket) .")", OBJECT);
            $title_override = 'Email';
            $this->view('email', compact('title_override', 'users'));

        } else {

            $active  = "SELECT l.*, p.post_title FROM $table l
              INNER JOIN $wpdb->posts p ON l.post_id = p.ID
              WHERE l.lease_end_date > NOW()
              ORDER BY id DESC
            ";

            $expired  = "SELECT l.*, p.post_title FROM $table l
              INNER JOIN $wpdb->posts p ON l.post_id = p.ID
              WHERE l.lease_end_date < NOW()
              OR l.lease_end_date IS NULL
              OR l.lease_end_date = ''
              ORDER BY id DESC
            ";

            $active_leads = $this->_db->get_results($active);
            $expired_leads = $this->_db->get_results($expired);

            $this->view('leads', array(
                'active_leads' => $active_leads,
                'expired_leads' => $expired_leads,
            ));
        }

    }

    public function page_payment_settings() {

        $settings = get_option('lpp_payment_settings');
        $this->view('payment_settings', compact('settings'));

    }


    /*------------------------------------------------------------------------------------------------------------------
     * Data storage
     -----------------------------------------------------------------------------------------------------------------*/

    public function save_phantom_settings() {

        wp_verify_nonce($_POST['lpp_save_settings'], 'save_phantom_settings') or exit;

        if(isset($_POST['settings'])) {

            $enable_overlay     = boolval($_POST['enable']);
            $default_url        = esc_url_raw($_POST['default-url']);

            $title_enable       = boolval($_POST['title_enable']);
            $title_position     = sanitize_text_field(strtolower($_POST['title_position']));
            $font_size          = intval($_POST['title_font_size']) ?: '';
            $title_padding      = intval($_POST['title_padding']) ?: '';
            $font_color         = sanitize_text_field($_POST['title_text_color']);
            $background         = sanitize_text_field($_POST['title_background_color']);


            switch($title_position) {
                case 'left': $title_position = 'left'; break;
                case 'right': $title_position = 'right'; break;
                case 'center': $title_position = 'center'; break;
                case 'justified': $title_position = 'justified'; break;
                default: $title_position = '';
            }

            update_option('lpp_enable_overlay', $enable_overlay);
            update_option('lpp_default_overlay_url', $default_url);
            update_option('lpp_title_overlay_settings', array(
                'enable'     => $title_enable,
                'position'   => $title_position,
                'padding'    => $title_padding,
                'font_size'  => $font_size,
                'font_color' => $font_color,
                'background' => $background,
            ));

        } elseif(isset($_POST['categories'])) {

            $overlay_url       = $_POST['overlay-url'];
            $overlay_enable    = isset($_POST['overlay-disable']) ? $_POST['overlay-disable'] : array();

            update_option('lpp_category_overlay_settings', array(
                'overlay_url'       => $overlay_url,
                'overlay_disable'   => $overlay_enable,
            ));
        }

        $redirect_to = admin_url('admin.php') .'?page='. get_config('slug') .'&success=true';
        wp_redirect($redirect_to);
        exit;
    }

    public function save_phantom_links() {

        wp_verify_nonce($_POST['lpp_save_links'], 'save_phantom_links') or exit;

        $enable = boolval($_POST['enable']);
        $allowed = explode("\n", $_POST['allowed']);
        $domains = array();

        foreach($allowed as $domain) {
            if(preg_match('/^([a-z0-9-]{2,253}\.)?([a-z0-9-]{2,253})\.([a-z]{2,16})$/', trim($domain))) {
                array_push($domains, trim($domain));
            }
        }

        update_option('lpp_hidden_links_settings', array(
            'enable'    => $enable,
            'allowed'   => $domains,
        ));

        $redirect_to = admin_url('admin.php') .'?page=phantom-links&success=true';
        wp_redirect($redirect_to);
        exit;
    }

    public function save_lease_control_settings() {

        wp_verify_nonce($_POST['lpp_lease_control_settings'], 'save_lease_control_settings') or exit;

        $overlay_url        = (array) $_POST['overlay-url'];
        $price              = (array) $_POST['price'];
        $enable             = isset($_POST['enable']) ? $_POST['enable'] : array();
        $master_disable     = isset($_POST['master-disable']) ? $_POST['master-disable'] : array();
        $available          = (array) $_POST['available'];

        foreach($available as $index => $value) {

            $lease_url = isset($overlay_url[$index]) ? $overlay_url[$index] : '';
            if(!filter_var($lease_url, FILTER_VALIDATE_URL)) $lease_url = '';

            $lease_price      = floatval($price[$index]) ?: '';
            $lease_enable     = isset($enable[$index]) ? boolval($enable[$index]) : false;
            $lease_m_disable  = isset($master_disable[$index]) ? boolval($master_disable[$index]) : false;
            $lease_available  = boolval($value);

            update_post_meta(intval($index), 'lpp_lease_settings', array(
                'overlay_url'       => $lease_url,
                'price'             => $lease_price,
                'enable'            => $lease_enable,
                'master_disable'    => $lease_m_disable,
                'available'         => $lease_available,
            ));
        }

        $redirect_to = admin_url('admin.php') .'?page=lease-control&success=true';
        wp_redirect($redirect_to);
        exit;
    }

    public function save_lease_settings() {

        wp_verify_nonce($_POST['lpp_save_lease_settings'], 'save_lease_settings') or exit;

        if(isset($_POST['cta'])) {

            $title_txt        = sanitize_text_field($_POST['cta-title-txt']);
            $position         = intval($_POST['cta-position']) ?: 'default';
            $bg_color         = sanitize_text_field($_POST['cta-bg-color']);
            $opacity          = intval($_POST['cta-opacity']) ?: '100';
            $title_color      = sanitize_text_field($_POST['cta-txt-color']);

            $btn_txt          = sanitize_text_field($_POST['cta-btn-txt']);
            $btn_color        = sanitize_text_field($_POST['cta-btn-color']);
            $btn_txt_color    = sanitize_text_field($_POST['cta-btn-txt-color']);

            switch($position) {
                case '1': $position = 'default'; break;
                case '2': $position = 'bottom'; break;
                case '3': $position = 'top'; break;
                case '4': $position = 'fullscreen'; break;
                default: $position = 'default';
            }

            update_option('lpp_lease_cta_settings', array(
                'title_txt'         => $title_txt,
                'position'          => $position,
                'bg_color'          => $bg_color,
                'opacity'           => $opacity,
                'title_color'       => $title_color,
                'btn_txt'           => $btn_txt,
                'btn_color'         => $btn_color,
                'btn_txt_color'     => $btn_txt_color,
            ));

        } elseif(isset($_POST['popup'])) {

            $title = sanitize_text_field($_POST['title']);
            $content = $_POST['popup-content'];

            update_option('lpp_lease_popup_settings', array(
                'title' => $title,
                'content' => $content,
            ));

        }

        $redirect_to = admin_url('admin.php') .'?page=lease-settings&success=true';
        wp_redirect($redirect_to);
        exit;
    }

    public function save_payment_settings() {

        wp_verify_nonce($_POST['lpp_save_payment_settings'], 'save_payment_settings') or exit;

        $mode        = boolval($_POST['mode']);
        $recipient   = sanitize_email($_POST['recipient']);
        $amount      = floatval($_POST['amount']);
        $currency    = sanitize_text_field(strtoupper($_POST['currency']));
        $description = sanitize_text_field($_POST['description']);

        update_option('lpp_payment_settings', array(
            'mode'          => $mode,
            'recipient'     => $recipient,
            'amount'        => $amount,
            'currency'      => $currency,
            'description'   => $description,
        ));

        $redirect_to = admin_url('admin.php') .'?page=payments&success=true';
        wp_redirect($redirect_to);
        exit;
    }

    public function update_leads() {

        wp_verify_nonce($_POST['lpp_update_leads'], 'update_leads') or exit;

        if(isset($_POST['bulk-id']) && is_array($_POST['bulk-id']) && !empty($_POST['bulk-id'])) {

            $wpdb    = $this->_db;
            $table   = $this->_table;
            $bulk_id = $_POST['bulk-id'];
            $bucket  = array();

            if(isset($_POST['bulk-action']) && ($_POST['bulk-action'] == 'delete')) {

                foreach($bulk_id as $index => $value) {
                    if(filter_var($index, FILTER_VALIDATE_INT)) {
                        array_push($bucket, $index);
                    }
                }

                $wpdb->query("DELETE FROM $table WHERE ID IN(". implode(',', $bucket) .")");

            } elseif(isset($_POST['bulk-action']) && ($_POST['bulk-action'] == 'email')) {

                foreach($bulk_id as $index => $value) {
                    if(filter_var($index, FILTER_VALIDATE_INT)) {
                        array_push($bucket, $index);
                    }
                }

                $_SESSION['lpp_email_id_bucket'] = $bucket;
                $redirect_to = admin_url('admin.php') .'?page=leads&email=1';
                wp_redirect($redirect_to);
                exit;
            }
        }

        $redirect_to = admin_url('admin.php') .'?page=leads';
        wp_redirect($redirect_to);
        exit;
    }

    public function save_lease_status() {

        wp_verify_nonce($_POST['lpp_save_lease_status'], 'cta_submit') or exit;

        $post_id        = isset($_POST['pid']) ? intval($_POST['pid']) : '';
        $post_permalink = get_permalink($post_id);
        $site_url       = rtrim(get_site_url(), '/');

        if(!filter_var($post_id, FILTER_VALIDATE_INT)) {
            die(json_encode(array(
                'status' => 'fail',
                'message' => 'Unable to find the page you were looking at !',
            )));
        }

        $user_name      = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
        $user_email     = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
        $user_url       = isset($_POST['url']) ? esc_url_raw($_POST['url'], array('http', 'https')) : '';
        $rent_period    = isset($_POST['period']) ? intval($_POST['period']) : 1;

        if( (!$user_name) || (!$user_email) || (!$user_url) || (!$rent_period) ) {
            die(json_encode(array(
                'status' => 'fail',
                'message' => 'Please fill all form fields with accurate data',
            )));
        }

        // Store the return values
        $lpp_paypal_data = array(
            'business'      => '',
            'item_name'     => 'Leads Phantom Pro - Rent a page',
            'item_number'   => $post_id,
            'amount'        => '',
            'currency_code' => 'USD',
            'custom'         => 'x',
            'return'        => $post_permalink .'?lpp-payment-status=1',
            'cancel_return' => $post_permalink .'?lpp-payment-status=0',
            'notify_url'    => $site_url .'?'. get_config('paypal.listener') .'=1',
        );

        // Get lease settings for this page
        $lease_payment_settings = get_option('lpp_payment_settings');
        $post_lease_settings    = get_post_meta($post_id, 'lpp_lease_settings', true);

        // Get the recipient
        if(isset($lease_payment_settings['recipient'])) {
            $lpp_paypal_data['business'] = $lease_payment_settings['recipient'];
        }

        // Get the payment description
        if(isset($lease_payment_settings['description'])) {
            $lpp_paypal_data['item_name'] = $lease_payment_settings['description'];
            if($rent_period > 1) {
                $lpp_paypal_data['item_name'] .= ' ('. $rent_period .' months)';
            }
        }

        // Get the price/month and calculate total
        $price = 0;
        if(isset($lease_payment_settings['amount']) && is_numeric($lease_payment_settings['amount'])) {
            $price = $lease_payment_settings['amount'];
        }
        if(isset($post_lease_settings['price']) && is_numeric($post_lease_settings['price'])) {
            $price = $post_lease_settings['price'];
        }

        $lpp_paypal_data['amount'] = round(($price * $rent_period), 2);

        // Get the currency
        if(isset($lease_payment_settings['currency'])) {
            $lpp_paypal_data['currency_code'] = $lease_payment_settings['currency'];
        }

        $this->_db->insert($this->_table, array(
            'name'      => $user_name,
            'email'     => $user_email,
            'url'       => $user_url,
            'post_id'   => $post_id,
            'lease_period' => $rent_period,
            'ordered'   => isset($_POST['order']) ? '1' : '0',
            'completed' => '0',
            'order_date' => current_time('mysql', true),
        ), array(
            '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s',
        ));

        if($refid = $this->_db->insert_id) {
            $lpp_paypal_data['custom'] = $refid;
            $response = array(
                'status' => 'pass',
                'data'   => $lpp_paypal_data,
            );

            if(!isset($_POST['order'])) {
                include get_config('base_path', 'templates/preview.php');
            }

            die(json_encode($response));
        }

        die(json_encode(array(
            'status' => 'fail',
            'message' => 'We were unable to precess your request. Refresh the page and try again.',
        )));

    }


    /*------------------------------------------------------------------------------------------------------------------
     * PayPal IPN
     -----------------------------------------------------------------------------------------------------------------*/

    public function paypal_ipn($request = array()) {
        if(!empty($request)
            && isset($request['mc_gross'])
            && isset($request['custom'])
            && isset($request['payment_status'])) {

            if(!is_numeric($request['mc_gross']) ||
                (!filter_var($request['custom'], FILTER_VALIDATE_INT))) {
                header("HTTP/1.0 404 Not Found");
                exit;
            }

            $mc_gross   = $request['mc_gross'];
            $refid      = $request['custom'];
            $p_status   = strtolower($request['payment_status']);
            $status     = ($p_status == 'completed') ? '1' : '0';
            $wpdb       = $this->_db;
            $table      = $this->_table;

            $record = $wpdb->get_row("SELECT * FROM $table WHERE id = $refid", OBJECT);

            if(!$record) {
                header("HTTP/1.0 404 Not Found");
                exit;
            }

            // If this record is marked as not-completed
            if(!boolval($record->completed)) {

                // Set update values and format
                $update_values = array();
                $update_format = array();

                // Check / Update ordered status
                if(intval($record->ordered) == 0) {
                    $update_values['ordered'] = '1';
                    $update_format[] = '%s';
                }

                // Update payment status
                $update_values['completed'] = $status;
                $update_format[] = '%s';

                // Update mc_gross
                $update_values['mc_gross'] = $mc_gross;
                $update_format[] = '%s';

                // Update lease_start_date & lease_end_date
                switch($record->lease_period) {
                    case '1': $end_date = date('Y-m-d H:i:s', strtotime('+1 months')); break;
                    case '2': $end_date = date('Y-m-d H:i:s', strtotime('+2 months')); break;
                    case '3': $end_date = date('Y-m-d H:i:s', strtotime('+3 months')); break;
                    case '4': $end_date = date('Y-m-d H:i:s', strtotime('+4 months')); break;
                    case '5': $end_date = date('Y-m-d H:i:s', strtotime('+5 months')); break;
                    case '6': $end_date = date('Y-m-d H:i:s', strtotime('+6 months')); break;
                    default: $end_date = date('Y-m-d H:i:s', strtotime('+1 months'));
                }

                // Lease Start Date
                $update_values['lease_start_date'] = current_time('mysql');
                $update_format[] = '%s';

                // Lease End Date
                $update_values['lease_end_date'] = $end_date;
                $update_format[] = '%s';

                $wpdb->update($table, $update_values, array('id' => $refid), $update_format);
            }

            header("HTTP/1.0 200 Ok");
            exit;

        }
    }


    /*------------------------------------------------------------------------------------------------------------------
     * Send Mail to users
     -----------------------------------------------------------------------------------------------------------------*/

    public function send_mail() {

        wp_verify_nonce($_POST['send_mail_to_users'], 'lpp_send_mail_to_users') or exit;

        if(isset($_POST['email']) && !empty($_POST['email'])) {
            $send_list    = array();
            $email_bucket = $_POST['email'];
            $email_bucket = explode(',', $email_bucket);

            foreach($email_bucket as $email) {
                $email_address = trim($email);
                if(filter_var($email_address, FILTER_VALIDATE_EMAIL)
                    && (!in_array($email_address, $send_list))) {
                    array_push($send_list, $email_address);
                }
            }

            $subject = isset($_POST['subject']) ? $_POST['subject'] : '';
            $message = isset($_POST['message']) ? $_POST['message'] : '';
            $from    = isset($_POST['from']) ? $_POST['from'] : '';

            if(!filter_var($from, FILTER_VALIDATE_EMAIL)) {
                $from = 'webmaster@'. $_SERVER['SERVER_NAME'];
            }

            if(count($send_list)) {

                $headers  = "From: ". get_bloginfo('title') ." <$from>" . "\r\n";
                $headers .= "Reply-To: ". $from ."\r\n";
                $headers .= "Bcc: ". trim(implode(', ', $send_list)) ."\r\n";
                $headers .= 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

                wp_mail(null, $subject, stripslashes($message), $headers);
            }

            unset($_SESSION['lpp_email_id_bucket']);
        }

        $redirect_to = admin_url('admin.php') .'?page=leads&success=true';
        wp_redirect($redirect_to);
        exit;
    }


    /*------------------------------------------------------------------------------------------------------------------
     * Setup
     -----------------------------------------------------------------------------------------------------------------*/

    public function enqueue_scripts($page) {

        switch($page) {
            case 'toplevel_page_'. get_config('slug'):
            case 'phantom-settings_page_lease-settings':
                wp_enqueue_style('bootstrap', get_config('assets', 'css/bootstrap.css'), false);
                wp_enqueue_style('lpp-admin', get_config('assets', 'css/admin.css'));
                wp_enqueue_style('wp-color-picker');
                wp_enqueue_script('lpp-color-picker', get_config('assets', 'js/color-picker.js'), array('wp-color-picker'));
                break;

            case 'phantom-settings_page_phantom-links':
            case 'phantom-settings_page_lease-control':
            case 'phantom-settings_page_leads':
            case 'phantom-settings_page_payments':
                wp_enqueue_style('bootstrap', get_config('assets', 'css/bootstrap.css'), false);
                wp_enqueue_style('lpp-admin', get_config('assets', 'css/admin.css'));
                break;

            default:
                // Load scripts on all pages...
        }

    }

    public function admin_menu() {

        add_menu_page('Overlay Settings', get_config('menu'), get_config('capabilities'), get_config('slug'), array($this, 'page_index'));

        add_submenu_page(get_config('slug'), 'Lease Control', 'Lease Control',
            get_config('capabilities'), 'lease-control', array($this, 'page_lease_control'));

        add_submenu_page(get_config('slug'), 'Leads', 'Leads', get_config('capabilities'),
            'leads', array($this, 'page_leads'));

        add_submenu_page(get_config('slug'), 'Lease CTA Settings', 'Lease Settings',
            get_config('capabilities'), 'lease-settings', array($this, 'page_lease_settings'));

        add_submenu_page(get_config('slug'), 'Payment Settings', 'Payment Settings', get_config('capabilities'),
            'payments', array($this, 'page_payment_settings'));

        add_submenu_page(get_config('slug'), 'Links', 'Links',
            get_config('capabilities'), 'phantom-links', array($this, 'page_phantom_links'));

    }

    public function admin_init() {

        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));

        add_action('admin_post_save_phantom_settings', array($this, 'save_phantom_settings'));
        add_action('admin_post_save_phantom_links', array($this, 'save_phantom_links'));
        add_action('admin_post_save_lease_control_settings', array($this, 'save_lease_control_settings'));
        add_action('admin_post_save_lease_settings', array($this, 'save_lease_settings'));
        add_action('admin_post_save_payment_settings', array($this, 'save_payment_settings'));
        add_action('admin_post_update_leads', array($this, 'update_leads'));
        add_action('admin_post_lpp_send_mail_to_users', array($this, 'send_mail'));

        // CTA Submit Action
        add_action('admin_post_cta_submit', array($this, 'save_lease_status'));
        add_action('admin_post_nopriv_cta_submit', array($this, 'save_lease_status'));

        // PayPal IPN Handler
        add_action('admin_post_lpp_ipn_handler', array($this, 'paypal_ipn'));
        add_action('admin_post_nopriv_lpp_ipn_handler', array($this, 'paypal_ipn'));

    }
}
