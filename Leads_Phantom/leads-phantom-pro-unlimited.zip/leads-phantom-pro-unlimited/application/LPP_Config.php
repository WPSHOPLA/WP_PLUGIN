<?php if(!defined('ABSPATH')) exit;

/**
 * Retrieve Configuration Values
 * @param $query string - a dot notation string which maps
 *        to the structure of the configurations.
 * @param $append string - a string to append to the output.
 * @return mixed|array|string|bool
 */
function get_config($query, $append = '') {

    $_lpp_config_values = array(

        'version'       => '2.0',
        'capabilities'  => 'administrator',
        'table'         => 'lpp_lease_status',
        'name'          => 'Leads Phantom Pro',
        'menu'          => 'Phantom Settings',
        'slug'          => 'leads-phantom-pro-unlimited',

        'base_url'      => plugin_dir_url(dirname(__FILE__)),
        'base_path'     => plugin_dir_path(dirname(__FILE__)),
        'assets'        => plugin_dir_url(dirname(__FILE__)) .'assets/',

        'paypal'        => array(
            'sandbox'   => 'https://www.sandbox.paypal.com/cgi-bin/webscr',
            'live'      => 'https://www.paypal.com/cgi-bin/webscr',
            'listener'  => 'lpp-ipn-listener',
        ),

        // Supported Payment Currencies
        'currencies'    => array(
            'AUD' => array(
                'label' => 'AUD - Australian Dollar',
                'format' => '$ %s',
            ),
            'CAD' => array(
                'label' => 'CAD - Canadian Dollar',
                'format' => '$ %s',
            ),
            'EUR' => array(
                'label' => 'EUR - Euro',
                'format' => '� %s',
            ),
            'GBP' => array(
                'label' => 'GBP - Pound Sterling',
                'format' => '� %s',
            ),
            'JPY' => array(
                'label' => 'JPY - Japanese Yen',
                'format' => '� %s',
            ),
            'USD' => array(
                'label' => 'USD - U.S. Dollar',
                'format' => '$ %s',
            ),
            'NZD' => array(
                'label' => 'NZD - N.Z. Dollar',
                'format' => '$ %s',
            ),
            'CHF' => array(
                'label' => 'CHF - Swiss Franc',
                'format' => '%s Fr',
            ),
            'HKD' => array(
                'label' => 'HKD - Hong Kong Dollar',
                'format' => '$ %s',
            ),
            'SGD' => array(
                'label' => 'SGD - Singapore Dollar',
                'format' => '$ %s',
            ),
            'SEK' => array(
                'label' => 'SEK - Swedish Krona',
                'format' => '%s kr',
            ),
            'DKK' => array(
                'label' => 'DKK - Danish Krone',
                'format' => '%s kr',
            ),
            'PLN' => array(
                'label' => 'PLN - Polish Zloty',
                'format' => '%s z?',
            ),
            'NOK' => array(
                'label' => 'NOK - Norwegian Krone',
                'format' => '%s kr',
            ),
            'HUF' => array(
                'label' => 'HUF - Hungarian Forint',
                'format' => '%s Ft',
            ),
            'CZK' => array(
                'label' => 'CZK - Czech Koruna',
                'format' => '%s K?',
            ),
            'ILS' => array(
                'label' => 'ILS - Israeli New Sheqel',
                'format' => '? %s',
            ),
            'MXN' => array(
                'label' => 'MXN - Mexican Peso',
                'format' => '$ %s',
            ),
            'BRL' => array(
                'label' => 'BRL - Brazilian Real',
                'format' => 'R$ %s',
            ),
            'MYR' => array(
                'label' => 'MYR - Malaysian Ringgit',
                'format' => 'RM %s',
            ),
            'PHP' => array(
                'label' => 'PHP - Philippine Peso',
                'format' => '? %s',
            ),
            'TWD' => array(
                'label' => 'TWD - New Taiwan Dollar',
                'format' => 'NT$ %s',
            ),
            'THB' => array(
                'label' => 'THB - Thai Baht',
                'format' => '? %s',
            ),
            'TRY' => array(
                'label' => 'TRY - Turkish Lira',
                'format' => 'TRY %s',
            ),
        ),

    );

    $query  = explode('.', $query);
    $config = $_lpp_config_values;

    foreach($query as $bit) {
        if(isset($config[$bit]))
            $config = $config[$bit];
        else return false;
    }

    return is_string($config) ? ($config . $append) : $config;
}
