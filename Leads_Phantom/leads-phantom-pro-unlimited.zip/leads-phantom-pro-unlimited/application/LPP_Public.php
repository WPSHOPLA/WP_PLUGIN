<?php if(!defined('ABSPATH')) exit;

/**
 * LLP_Public
 * Handles the public hooks and views.
 */
class LPP_Public
{
    public $_db;
    public $_table;
    private $lpp_links_init = false;

    public function __construct($database, $table) {

        // Start the session
        if(!isset($_SESSION)) session_start();

        $this->_db = $database;
        $this->_table = $table;

        // Phantom Template
        
		
        add_filter('template_include', array($this, 'phantom_template'));

        // Enable Phantom Links
        $link_settings = get_option('lpp_hidden_links_settings');
        if(isset($link_settings['enable']) && boolval($link_settings['enable'])) {
            add_action('the_content', array($this, 'phantom_links'));
        }

        // Add actions for phantom iFrame
        add_action('wp_ajax_lpp_frame', array($this, 'lpp_frame'));
        add_action('wp_ajax_nopriv_lpp_frame', array($this, 'lpp_frame'));

        // Add actions for the phantom links
        add_action('wp_ajax_lpp_links', array($this, 'lpp_links'));
        add_action('wp_ajax_nopriv_lpp_links', array($this, 'lpp_links'));

        // Enqueue Scripts
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));

    }

    /*------------------------------------------------------------------------------------------------------------------
     * Modifiers
     -----------------------------------------------------------------------------------------------------------------*/

    public function phantom_template($template) {
		
		
		//$GLOBALS['current_theme_template'] = basename($template);
		$_SESSION['current_theme_template'] = basename($template);

        // Get ID and Config. for this post
        $wpdb           = $this->_db;
        $table          = $this->_table;
        $post_id        = get_the_ID() ?: 0;
        $lease_settings = get_post_meta($post_id, 'lpp_lease_settings', true);

        // Disable overlay if set in Lease Control Panel
        if(isset($lease_settings['master_disable'])
            && boolval($lease_settings['master_disable'])
            && (!is_home())) {
            return $this->set_template($template);
        } else {

            // Show Leased url if this post has been leased
            $lease = $wpdb->get_results("SELECT * FROM $table WHERE post_id = $post_id AND lease_end_date > NOW()", OBJECT);
            if(count($lease) == 1) {
                $template = get_config('base_path', 'templates/default.php');
                $_SESSION['lpp_iframe'] = esc_url($lease[0]->url);
                return $this->set_template($template);
            }

            // Enable Lease CTA
            if( isset($lease_settings['enable'])
                && boolval($lease_settings['enable'])
                && (!is_home()) && (!is_category()) ) {
                add_action('wp_footer', array($this, 'lease_popup'));
            }

            // Set the overlay url if defined in Lease Control Panel
            if(isset($lease_settings['overlay_url'])
                && filter_var($lease_settings['overlay_url'], FILTER_VALIDATE_URL)
                && (!is_category())) {
                $template = get_config('base_path', 'templates/default.php');
                $_SESSION['lpp_iframe'] = esc_url($lease_settings['overlay_url']);
                return $this->set_template($template);
            }

            // Show default / custom overlay url
            if(boolval(get_option('lpp_enable_overlay'))) {

                // Set the default overlay url
                $overlay_url    = get_option('lpp_default_overlay_url');

                // Checks if this is a post and if a url
                // has been defined for it's category
                if(is_single() || is_category()) {

                    $categories             = array();
                    $cat_overlay_settings   = get_option('lpp_category_overlay_settings');
                    $cat_overlay_url        = $cat_overlay_settings['overlay_url'];
                    $cat_overlay_disable    = $cat_overlay_settings['overlay_disable'];

                    foreach(get_the_category() as $category) {
                        array_push($categories, $category->cat_ID);
                    }

                    foreach($categories as $cid) {
                        if(isset($cat_overlay_disable[$cid])) {
                            $overlay_url = '';
                            break;
                        }

                        if(isset($cat_overlay_url[$cid])
                            && filter_var($cat_overlay_url[$cid], FILTER_VALIDATE_URL)) {
                            $overlay_url = $cat_overlay_url[$cid];
                            break;
                        }
                    }

                }


                // Set the overlay template
                if(filter_var($overlay_url, FILTER_VALIDATE_URL)) {
                    $template = get_config('base_path', 'templates/default.php');
                    $_SESSION['lpp_iframe'] = esc_url($overlay_url);
                }
            }
        }

        return $this->set_template($template);

    }

    private function set_template($template) {
        return apply_filters('phantom_template', $template);
    }

    private function phantom_links_handler($link) {

        if(is_bot())
        {
            return '';
        }

        $domain = parse_url($link[1], PHP_URL_HOST);
        $link_settings = get_option('lpp_hidden_links_settings');
        $whitelist = $link_settings['allowed'];

        $domain = str_ireplace('www.', '', $domain);

        if(in_array($domain, $whitelist) || in_array(($domain .'/'), $whitelist)) {
            return $link[0];
        }

        $_SESSION['lpp_links'][] = array('content' => $link[0], 'url' => $link[1]);
        return '<span id="' . (count($_SESSION['lpp_links']) - 1) . '" class="lpp-link"></span>';
    }

    public function phantom_links($content) {

        if(!$this->lpp_links_init) {
            $_SESSION['lpp_links'] = array();
            $this->lpp_links_init = true;
        }

        $content = preg_replace_callback('/<a.+?href="(.+?)".+?<\/a>/', array($this, 'phantom_links_handler'), $content);
        return $content;
    }

    public function lease_popup() {
        include get_config('base_path', 'views/lease_popup.php');
    }


    /*------------------------------------------------------------------------------------------------------------------
     * Retrievers
     -----------------------------------------------------------------------------------------------------------------*/

    public function lpp_frame() {
        if(isset($_SESSION) && isset($_SESSION['lpp_iframe'])) {
            $url = $_SESSION['lpp_iframe'];
            unset($_SESSION['lpp_iframe']);
            die($url);
        }
    }

    public function lpp_links() {
        if(isset($_SESSION) && isset($_SESSION['lpp_links'])) {
            $links = $_SESSION['lpp_links'];
            unset($_SESSION['lpp_links']);
            die(json_encode($links));
        }
    }


    /*------------------------------------------------------------------------------------------------------------------
     * Setup
     -----------------------------------------------------------------------------------------------------------------*/

    public function enqueue_scripts() {
        wp_enqueue_style('lpp-lease-popup', get_config('assets', 'css/lpp-lease-popup.css'), array(), false);
        wp_enqueue_script('popupoverlay', get_config('assets', 'js/jquery.popupoverlay.js'), array('jquery'), false, true);
        wp_enqueue_script('lpp-lease', get_config('assets', 'js/lpp-lease.js'), array('jquery'), false, true);
        wp_enqueue_script('lpp-links', get_config('assets', 'js/lpp-links.js'), array('jquery'), false, true);

        wp_localize_script('lpp-links', 'ajurl', array('url' => admin_url('admin-ajax.php')));
    }
}
