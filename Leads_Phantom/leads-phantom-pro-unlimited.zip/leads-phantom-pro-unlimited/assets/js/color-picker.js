jQuery('document').ready(function() {

    jQuery('#lpp_title_color').wpColorPicker();
    jQuery('#lpp_background_color').wpColorPicker();
    jQuery('#cta-bg-color').wpColorPicker();
    jQuery('#cta-txt-color').wpColorPicker();
    jQuery('#cta-btn-color').wpColorPicker();
    jQuery('#cta-btn-border-color').wpColorPicker();
    jQuery('#cta-btn-txt-color').wpColorPicker();

});
