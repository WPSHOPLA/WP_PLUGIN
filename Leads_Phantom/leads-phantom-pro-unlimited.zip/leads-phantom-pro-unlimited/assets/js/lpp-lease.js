(function($) {

    var lease_cta_container     = $('#lease-cta');
    var lease_cta_order_btn     = $('#lease-cta-btn');
    var lease_cta_close_btn     = $('#lease-cta-close-btn');
    var lease_cta_placeholder   = $('#lease-cta-placeholder');
    var lease_cta_form_popup    = $('#lease-popup');

    function hide_cta_placeholder() {
        lease_cta_placeholder.animate({'bottom': '-=500px'}, 'slow');
    }
    function show_cta_placeholder() {
        lease_cta_placeholder.animate({'bottom': '+=500px'}, 'slow');
    }

    function show_cta_form_popup() {
        lease_cta_form_popup.popup('show');
    }

    // CTA Form Close Button
    $('#lease-popup-close-btn').click(function(e) {
        e.preventDefault();
        lease_cta_form_popup.popup('hide');
    });

    // CTA Form Close Event
    lease_cta_form_popup.popup({
        onclose: function() {
            show_cta_placeholder();
        }
    });

    $('#lease-popup.thank-you').popup('show');

    /* ------------------------------------------------------------------------
    | Lease CTA Close Button
    ------------------------------------------------------------------------ */
    lease_cta_close_btn.click(function(e) {
        e.preventDefault();
        if(lease_cta_container.hasClass('cta-fullscreen')) {
            lease_cta_container.hide();
            show_cta_placeholder();
        } else if(lease_cta_container.hasClass('cta-top')) {
            lease_cta_container.animate({'top': '-=500px'}, 'slow');
            show_cta_placeholder();
        } else if(lease_cta_container.hasClass('cta-bottom') || lease_cta_container.hasClass('cta-default')) {
            lease_cta_container.animate({'bottom': '-=500px'}, 'slow');
            show_cta_placeholder();
        }
    });


    /* ------------------------------------------------------------------------
     | Lease CTA Order Button
     ------------------------------------------------------------------------ */
    lease_cta_order_btn.click(function(e) {
        e.preventDefault();
        if(lease_cta_container.hasClass('cta-fullscreen')) {
            lease_cta_container.hide();
            show_cta_form_popup();
        } else if(lease_cta_container.hasClass('cta-top')) {
            lease_cta_container.animate({'top': '-=500px'}, 'slow');
            show_cta_form_popup();
        } else if(lease_cta_container.hasClass('cta-bottom') || lease_cta_container.hasClass('cta-default')) {
            lease_cta_container.animate({'bottom': '-=500px'}, 'slow');
            show_cta_form_popup();
        }
    });


    /* ------------------------------------------------------------------------
     | Lease CTA Placeholder
     ------------------------------------------------------------------------ */
    lease_cta_placeholder.click(function(e) {
        e.preventDefault();
        hide_cta_placeholder();

        if(lease_cta_container.hasClass('cta-fullscreen')) {
            lease_cta_container.show();
        } else if(lease_cta_container.hasClass('cta-top')) {
            lease_cta_container.animate({'top': '+=500px'}, 'slow');
        } else if(lease_cta_container.hasClass('cta-bottom') || lease_cta_container.hasClass('cta-default')) {
            lease_cta_container.animate({'bottom': '+=500px'}, 'slow');
        }
    });


    /* ------------------------------------------------------------------------
     | Lease CTA Popup Form
     ------------------------------------------------------------------------ */
    $('#lease-popup-btn-order').click(function(e) {
        e.preventDefault();

        var lease_form = $('#lease-popup-form');
        var url = lease_form.attr('action');
        var data = {};

        lease_form.find('[name]').each(function(index, value) {
            var name = $(this).attr('name');
            var value = $(this).val();

            data[name] = value;
        });

        data['order'] = '1';

        $.post(url, data, function(response) {
            response = JSON.parse(response);

            if(response.status == 'fail') {
                alert(response.message);
                return false;
            }

            $('#paypal').find('[name]').each(function(i, v) {
                var p_name = $(this).attr('name');
                var p_value = response.data[p_name];

                if(p_value !== undefined) {
                    $(this).val(response.data[p_name]);
                }
            });

            $('#paypal').submit();
        });

    });

})(jQuery);
