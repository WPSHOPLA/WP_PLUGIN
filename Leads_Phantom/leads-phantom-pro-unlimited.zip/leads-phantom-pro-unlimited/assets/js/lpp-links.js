jQuery(document).ready(function() {

    var ajax_url = ajurl.url;
    jQuery.post(ajax_url, {action:"lpp_links"}, function(response) {
        response = JSON.parse(response);
        jQuery('span.lpp-link').each(function() {
            if(typeof response[this.id] !== 'undefined')
                jQuery(this).replaceWith(response[this.id].content);
        });
    });

});
