(function($) {

    // Screen Width & Height
    var lp_screen_width = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
    var lp_screen_height = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);

    // calculate screen height automatically
    var lpp_title = document.getElementById('lpp-title-container');
    var wp_adminbar = document.getElementById('wpadminbar');
    if(lpp_title) lp_screen_height -= lpp_title.clientHeight;
    if(wp_adminbar) lp_screen_height -= wp_adminbar.clientHeight;

    function lp_create_overlay(ua, url){

        var wrapper = $('#url-wrapper');

        switch(ua) {
            case 'default':
                $('body').width(lp_screen_width).height(lp_screen_height);
                $('<iframe>', {
                    src: url, frameborder: 0, scrolling: "yes",
                    width: lp_screen_width, height: lp_screen_height
                }).appendTo(wrapper);
                break;

            case 'ios':
                wrapper.addClass('ios');
                $('<iframe>', {src: url, frameborder: 0, scrolling: "no"}).appendTo(wrapper);
                break;

            case 'wp':
                wrapper.replaceWith($('<iframe>', {
                    src: url, id: 'lp_overlay_object',
                    width: lp_screen_width, height: lp_screen_height
                }));
                break;
        }
    }

    if(typeof lp_overlay_url !== 'undefined') {

        var lp_user_agent = navigator.userAgent;
        var lp_user_agent_code = 'default';

        if(lp_user_agent.match(/(iPod|iPhone|iPad)/)) {
            lp_user_agent_code = 'ios';
        }

        if(lp_user_agent.match(/IEMobile/i) || lp_user_agent.match(/Windows Phone/i)) {
            lp_user_agent_code = 'wp';
        }

        lp_create_overlay(lp_user_agent_code, lp_overlay_url);
    }

    $(document).ready(function() {

        // There was a really interesting comment in here.

    });

})(jQuery);
