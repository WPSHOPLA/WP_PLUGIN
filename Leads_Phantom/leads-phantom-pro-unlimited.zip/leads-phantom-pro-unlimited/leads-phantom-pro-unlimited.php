<?php if(!defined('ABSPATH')) exit;

/**
 * Plugin Name: Leads Phantom Pro Unlimited
 * Plugin URI: http://leadsphantom.com
 * Description: Leads Phantom Pro Unlimited WordPress Plugin
 * Version: 2.0
 * Author: ASM
 * Author URI: http://leadsphantom.com
 */

require_once (plugin_dir_path(__FILE__) .'application/LPP_Config.php');
require_once (plugin_dir_path(__FILE__) .'libraries/helpers.php');

class Leads_Phantom_Pro
{
	public $_db;
	public $_table;

	public function __construct($database) {

		$this->_db = $database;
		$this->_table = $database->prefix . get_config('table');

		register_activation_hook(__FILE__, array($this, 'activate_plugin'));
		register_deactivation_hook(__FILE__, array($this, 'deactivate_plugin'));

		add_action('plugins_loaded', array($this, 'loaded'));

	}

	public function view($name, $data = array()) {

		$view = get_config('base_path', 'views/'. $name .'.php');

		ob_start();

		extract($data, EXTR_SKIP);

		include get_config('base_path', 'views/header.php');

		if(file_exists($view)) include $view;

		echo ob_get_clean();

	}

	public function activate_plugin() {

		$table = $this->_table;

		$sql = "CREATE TABLE $table (
			id INT(11) NOT NULL AUTO_INCREMENT,
			name VARCHAR(255) DEFAULT NULL,
			email VARCHAR(255) DEFAULT NULL,
			url VARCHAR(512) DEFAULT NULL,
			post_id INT(11) UNSIGNED,
			lease_period VARCHAR(255) DEFAULT NULL,
			ordered VARCHAR(255) DEFAULT NULL,
			completed VARCHAR(255) DEFAULT NULL,
			mc_gross VARCHAR(255) DEFAULT NULL,
			order_date DATETIME DEFAULT NULL,
			lease_start_date DATETIME DEFAULT NULL,
			lease_end_date DATETIME DEFAULT NULL,
			UNIQUE KEY id (id)
		);";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

		dbDelta($sql);

		return true;
	}

	public function deactivate_plugin() {
		return true;
	}

	public function loaded() {

		require_once get_config('base_path', 'application/LPP_Admin.php');
		require_once get_config('base_path', 'application/LPP_Public.php');

		$admin = new LPP_Admin($this->_db, $this->_table);
		$public = new LPP_Public($this->_db, $this->_table);
	}
}

global $wpdb;

if(!is_bot())
{
	$lpp_application = new Leads_Phantom_Pro($wpdb);
}