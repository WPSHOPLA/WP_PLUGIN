<?php

require_once (plugin_dir_path(__FILE__) .'geoip.inc');

if(!function_exists('boolval')) {
    function boolval($value = false) {
        if( ($value == false) || empty($value) || ($value == '')
            || ($value == null) || ($value == 0) ) {
            return false;
        }

        return true;
    }
}

if(!function_exists('debug')) {
    function debug($output) {
        echo '<pre>', print_r($output), '</pre>';
        exit;
    }
}

if(!function_exists('convert_hex_to_rgb')) {
    function convert_hex_to_rgb($hex, $alpha = false) {
        $hex = str_replace("#", "", $hex);

        if(strlen($hex) == 3) {
            $r = hexdec(substr($hex,0,1).substr($hex,0,1));
            $g = hexdec(substr($hex,1,1).substr($hex,1,1));
            $b = hexdec(substr($hex,2,1).substr($hex,2,1));
        } else {
            $r = hexdec(substr($hex,0,2));
            $g = hexdec(substr($hex,2,2));
            $b = hexdec(substr($hex,4,2));
        }
        $rgb = array($r, $g, $b);

        if($alpha) {
            array_push($rgb, ($alpha / 100));
        }

        return $rgb;
    }
}

if(!function_exists('get_client_ip')) {
    function get_client_ip()
    {
        $ipaddress = '';
        if ($_SERVER['HTTP_CLIENT_IP'])
            $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
        else if ($_SERVER['HTTP_CF_CONNECTING_IP'])
            $ipaddress = $_SERVER['HTTP_CF_CONNECTING_IP'];
        else if ($_SERVER['HTTP_X_FORWARDED_FOR'])
            $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        else if ($_SERVER['HTTP_X_FORWARDED'])
            $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
        else if ($_SERVER['HTTP_FORWARDED_FOR'])
            $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
        else if ($_SERVER['HTTP_FORWARDED'])
            $ipaddress = $_SERVER['HTTP_FORWARDED'];
        else if ($_SERVER['REMOTE_ADDR'])
            $ipaddress = $_SERVER['REMOTE_ADDR'];
        else
            $ipaddress = 'UNKNOWN';

        return $ipaddress;
    }
}

if(!function_exists('is_bot')) {
    function is_bot()
    {
        //get user ip address
        $userip = get_client_ip();
        //load geoip database
        $gi = geoip_open(plugin_dir_path(__FILE__) .'GeoIPASNum.dat', GEOIP_STANDARD);
        //ip to organisation
        $ip_org = geoip_name_by_addr($gi, $userip);
        //close geoip database
        geoip_close($gi);
        //detect bots by asn
        if (strpos($ip_org, 'Google') || strpos($ip_org, 'Savvis') || strpos($ip_org, 'Microsoft') || strpos($ip_org, 'Yandex') || strpos($ip_org, 'Yahoo')){
            return true;
        } else {
            return false;
        }

    }
}

class LPP_Unlimited_Reg_Helpers {

    private $_name = 'Leads Phantom Pro Unlimited';
    private $_codename = 'leads_phantom_pro_unlimited_399';
    private $_pid = '0004';
    private $_api_url = 'http://www.licenseengine.com/licenses/a/';

    public function register_settings() {
        register_setting(sprintf($this->_codename), sprintf($this->_codename), array($this, 'leads_phantom_plugin_maintenance'));
    }

    function leads_phantom_plugin_maintenance($options) {

        if(isset($options) && ($options['license_key'] != ''))
        {
            $settings['license_key'] = $options['license_key'];
            $license = $options['license_key'];

            $api_params = array(
                'action' 	 => 'activate_license',
                'license' 	 => $license,
                'item_name'  => $this->_codename,
                'domain' 	 => urlencode($_SERVER['SERVER_NAME']),
                'product_id' => $this->_pid,
            );

            $response = wp_remote_get(add_query_arg($api_params, $this->_api_url), array('timeout' => 15, 'sslverify' => false));

            if(is_wp_error($response)) {
                return false;
            }

            $license_data = json_decode(wp_remote_retrieve_body($response));

            if(!empty($license_data) && $license_data->license == 'valid') {
                $data = array('timestamp' => time());
                update_option(sprintf($this->_codename) .'-lks', serialize($data));
                update_option(sprintf($this->_codename), $options['license_key']);
                return $settings;
            } elseif(!empty($license_data) && ($license_data->license == 'invalid')) {
                update_option(sprintf($this->_codename) .'-lks', $license_data->license);
                return $settings;
            } else {
                return false;
            }
        }
    }

    function leads_phantom_get_all_options()
    {
        $l = get_option(sprintf($this->_codename));
        $v = get_option(sprintf($this->_codename) .'-lks');
        $u = false;

        if(isset($v) && ($v !== 'invalid')) {
            $data = unserialize($v);
            if($data['timestamp'] > (time() - (24*60*60))) {
                return true;
            }
        }

        if($u == false) {

            $api_params = array(
                'action' 	 => 'activate_license',
                'license' 	 => $l,
                'item_name'  => $this->_codename,
                'domain' 	 => urlencode($_SERVER['SERVER_NAME']),
                'product_id' => $this->_pid,
            );

            $response = wp_remote_get(add_query_arg($api_params, $this->_api_url), array('timeout' => 15, 'sslverify' => false));


            if(is_wp_error($response)) {
                return false;
            }

            $license_data = json_decode(wp_remote_retrieve_body($response));

            if(!empty($license_data) && ($license_data->license == 'valid')) {
                $data = array('timestamp' => time());
                update_option(sprintf($this->_codename) .'-lks', serialize($data));
                return true;
            } elseif(!empty($license_data) && ($license_data->license == 'invalid')) {
                update_option(sprintf($this->_codename) .'-lks', $license_data->license);
                return false;
            } else {
                return false;
            }
        }
    }

    function leads_phantom_start_maintenance_settings()
    {
        if(isset($_POST['license_key'])) {
            $options = array('license_key' => $_POST['license_key']);
            $this->leads_phantom_plugin_maintenance($options);
        }

        $status = $this->leads_phantom_get_all_options();

        if($status==false): ?>
            <div style="margin-top:20px;padding:15px;font-size: 14px;width: 400px;border: 1px solid #cccccc;border-radius: 5px;">
                <div style="text-align: center">
                    <img src="http://www.licenseengine.com/assets3/images/License-Engine-Lock-TransBG.png" alt="LicenseEngine.com Logo">
                </div>
                <h4><?php echo $this->_name .' Registration'; ?></h4>
                <p>Please register your copy to get updates and support.</p>

                <form method="post" action="" enctype="multipart/form-data" id="license_key">

                    <?php settings_fields(sprintf($this->_codename)); ?>

                    <div class="button-container" style="text-align: center;">
                        <input id="license_key" name="license_key" type="text" class="input-xlarge" placeholder="Enter Your License Key" value=""/>
                        <input type="submit" value="Save" id="save_button" class="button action"/>

                        <p>Can't find your key? Login to
                            <a href="//www.licenseengine.com/my-keys" target="_blank">License Engine</a> to retrieve your key.
                        </p>
                    </div>
                </form>
                <div style="float:right"><img src="//www.licenseengine.com/assets2/img/licensingpoweredbyLE.png"></div>
                <div style="clear: both"></div>
            </div>
            <?php die();
        endif;
    }
}
