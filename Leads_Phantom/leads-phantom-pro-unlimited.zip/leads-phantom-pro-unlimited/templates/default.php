<?php if(!defined('ABSPATH')) exit;
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, user-scalable=0">
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <title><?php wp_title( '|', true, 'right' ); ?></title>
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    <!--[if lt IE 9]>
    <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js"></script>
    <![endif]-->
    <?php wp_head(); ?>
    <link rel="stylesheet" href="<?php echo get_config('assets', 'css/public.css'); ?>">
    <?php if(isset($_SESSION['lpp_iframe'])) {
        printf('<script>var lp_overlay_url = "%s";</script>', $_SESSION['lpp_iframe']);
        unset($_SESSION['lpp_iframe']);
    }?>
<!--    <script>--><?php //printf('var lp_overlay_url = "%s";', $_SESSION['lpp_iframe']); ?><!--</script>-->
</head>
<body <?php body_class(); ?>>

    <?php $title_settings = get_option('lpp_title_overlay_settings');
    if(isset($title_settings['enable']) && boolval($title_settings['enable'])) {
        $font_size      = isset($title_settings['font_size']) ? intval($title_settings['font_size']) : '14';
        $font_color     = isset($title_settings['font_color']) ? $title_settings['font_color'] : false;
        $background     = isset($title_settings['background']) ? $title_settings['background'] : false;

        $title_position = isset($title_settings['position']) ? $title_settings['position'] : false;
        $title_padding  = isset($title_settings['padding']) ? intval($title_settings['padding']) : false;

        $style  = boolval($font_size) ? ('font-size:'. $font_size .'px;') : '';
        $style .= boolval($font_color) ? 'color:'. $font_color .';' : '';
        $style .= boolval($background) ? 'background-color:'. $background .';' : '';

        $text_style = '';
        if($title_position) {
            $text_style = 'text-align:' . sanitize_text_field($title_position) .';';
            if(boolval($title_padding)) {
                switch($title_position) {
                    case 'left': $text_style .= 'padding-left:'. $title_padding .'px;'; break;
                    case 'right': $text_style .= 'padding-right:'. $title_padding .'px;'; break;
                }
            }
        }

        echo sprintf('<div id="lpp-title-container" style="%s"><h1 style="%s">%s</h1></div>', $style, $text_style, get_the_title());
    } ?>

    <div id="url-wrapper"></div>

    <div style="display:none;visibility:hidden;">
        <div id="primary" class="content-area">
            <main id="main" class="site-main" role="main">

                <?php while(have_posts()): the_post();
                   
                  
                    if(is_singular('page')) 
                        get_template_part( 'content', 'page' );

                    else get_template_part( 'content', 'single' );
  var_dump(is_singular('page'));
                    // If comments are open or we have at least one comment,
                    // load up the comment template.
                    if ( comments_open() || get_comments_number() ) :
                        comments_template();
                    endif;

                endwhile; ?>

            </main>
        </div>
        <?php get_sidebar(); ?>
    </div>

    <?php wp_footer(); ?>

    <script>var lpp_ajax_request_url = "<?php echo admin_url('admin-ajax.php'); ?>";</script>
    <script src="<?php echo get_config('assets', 'js/lpp-public.js'); ?>"></script>
</body>
</html>
