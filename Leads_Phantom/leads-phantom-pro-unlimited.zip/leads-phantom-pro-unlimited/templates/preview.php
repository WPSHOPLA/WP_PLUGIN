<?php if(!defined('ABSPATH')) exit;

$_POST = array();

$cta_settings   = get_option('lpp_lease_cta_settings');

// -----------------------------------------------------------------------------------
// Lease CTA Settings
// -----------------------------------------------------------------------------------
$cta_title  = 'Rent this page. Your logo, your number, your customers !';
$cta_button = 'Order Now';
// Replace defaults if settings exist
if(isset($cta_settings['title_txt']) && !empty($cta_settings['title_txt'])) {
    $cta_title = stripslashes($cta_settings['title_txt']);
}
if(isset($cta_settings['btn_txt']) && !empty($cta_settings['btn_txt'])) {
    $cta_button = stripslashes($cta_settings['btn_txt']);
}

$mode = isset($lease_payment_settings['mode']) ? boolval($lease_payment_settings['mode']) : false;
$mode = boolval($mode) ? get_config('paypal.live') : get_config('paypal.sandbox');
?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>3 Minute Preview</title>
    <?php wp_head(); ?>
    <link rel="stylesheet" href="<?php echo get_config('assets', 'css/public.css'); ?>">
    <link rel="stylesheet" href="<?php echo get_config('assets', 'css/lpp-lease-popup.css'); ?>">
    <style>html{margin-top:0 !important;}</style>
</head>
<body>

<iframe id="lpp-frame" src="<?php echo $user_url; ?>"></iframe>

<div id="lease-cta" class="text-center no-select cta-bottom" style="width:100%;max-width:100%">

    <form id="paypal" action="<?php echo $mode; ?>" method="post">
        <input type="hidden" name="cmd" value="_xclick">
        <input type="hidden" name="business" value="<?php echo $lpp_paypal_data['business']; ?>">
        <input type="hidden" name="item_name" value="<?php echo $lpp_paypal_data['item_name']; ?>">
        <input type="hidden" name="item_number" value="<?php echo $lpp_paypal_data['item_number']; ?>">
        <input type="hidden" name="amount" value="<?php echo $lpp_paypal_data['amount']; ?>">
        <input type="hidden" name="currency_code" value="<?php echo $lpp_paypal_data['currency_code']; ?>">
        <input type="hidden" name="custom" id="refid" value="<?php echo $lpp_paypal_data['custom']; ?>">

        <input type="hidden" name="button_subtype" value="services">
        <input type="hidden" name="no_note" value="1">
        <input type="hidden" name="no_shipping" value="1">
        <input type="hidden" name="rm" value="1">

        <input type="hidden" name="return" value="<?php echo $lpp_paypal_data['return']; ?>">
        <input type="hidden" name="cancel_return" value="<?php echo $lpp_paypal_data['cancel_return']; ?>">
        <input type="hidden" name="notify_url" value="<?php echo $lpp_paypal_data['notify_url']; ?>">

        <h2 id="lease-cta-title">This is a preview of how your site will overlay our pages</h2>
        <button type="submit" id="lease-cta-btn"><?php echo $cta_button; ?>
            <span id="timeout" style="margin-left:15px;color:red">02:45</span>
        </button>
    </form>
</div>
<script src="<?php echo get_config('assets', 'js/jquery.countdown.min.js'); ?>"></script>
<script>
(function($) {

    $(document).ready(function () {
        $('body').width(window.innerWidth).height(window.innerHeight);
        $('#lpp-frame').width(window.innerWidth).height(window.innerHeight);

        var threminutes = new Date().getTime() + 180000;
        $('#timeout').countdown(threminutes, function(e) {
            $(this).html(e.strftime('%M:%S'));
        }).on('finish.countdown', function() {
            window.location.href = "<?php echo $post_permalink; ?>";
        });
    });

})(jQuery);
</script>
</body>
</html><?php exit; ?>
