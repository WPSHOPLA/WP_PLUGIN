<?php if(!defined('ABSPATH')) exit;

$all_emails = array();
foreach($users as $user) { array_push($all_emails, $user->email); }

$emails = implode(', ', $all_emails);

?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">Bulk Email</h4>
                </div>
                <div class="panel-body">
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" autocomplete="off">

                        <input type="hidden" name="action" value="lpp_send_mail_to_users">
                        <?php wp_nonce_field('lpp_send_mail_to_users', 'send_mail_to_users'); ?>

                        <div class="form-group">
                            <label>From</label>
                            <input type="text" name="from" class="form-control" placeholder="your email address">
                        </div>
                        <div class="form-group">
                            <label>To</label>
                            <input type="text" name="email" class="form-control" value="<?php echo $emails; ?>">
                        </div>
                        <div class="form-group">
                            <label>Subject</label>
                            <input type="text" name="subject" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Message</label>
                            <textarea name="message" class="form-control" rows="7"></textarea>
                        </div>

                        <button type="submit" class="btn btn-phantom">Send</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php exit; ?>
