<?php if(!defined('ABSPATH')) exit;

$title = get_admin_page_title() ?: 'Leads Phantom Pro';
$title = isset($title_override) ? $title_override : $title;
$logo  = get_config('assets', 'img/leads-phantom-logo.png');
$lpp_status_init = new LPP_Unlimited_Reg_Helpers();
$lpp_status_init->leads_phantom_start_maintenance_settings(); ?>
<?php if(isset($_GET['success'])) : ?>
    <div class="clear">&nbsp;</div>

    <?php if($_GET['success'] == 'true') : ?>
    <div class="updated settings-error notice is-dismissible">
        <p><strong>Settings saved.</strong></p>
    <?php else : ?>
        <div class="error settings-error notice is-dismissible">
            <p><strong>Failed to save the settings. Please try again.</strong></p>
    <?php endif; ?>

        <button type="button" class="notice-dismiss">
            <span class="screen-reader-text">Dismiss this notice.</span>
        </button>
    </div>
<?php endif; ?>

<div class="clear">&nbsp;</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-8">
            <table class="table no-border">
                <tbody>
                    <tr>
                        <td class="col-md-4">
                            <img src="<?php echo get_config('assets', 'img/leads-phantom-logo.png'); ?>" id="phantom-logo" class="img-responsive" alt="Logo">
                        </td>
                        <td class="col-md-8"><h1 id="phantom-heading-title"><?php echo $title; ?></h1></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
