<?php if(!defined('ABSPATH')) exit; ?>

<style>
    table.no-border > tbody > tr > td > label {
        font-size: 13px;
    }
</style>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-5">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Overlay Settings</h3>
                </div>
                <div class="panel-body">
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" autocomplete="off">

                        <input type="hidden" name="action" value="save_phantom_settings">
                        <input type="hidden" name="settings" value="1">
                        <?php wp_nonce_field('save_phantom_settings', 'lpp_save_settings'); ?>

                        <div class="row">
                            <div class="col-md-12">
                                <table class="table no-border">
                                    <tbody>

                                        <tr><!-- Overlay Enable Switch -->
                                            <td class="col-md-4"><label>Enable Overlay :</label></td>
                                            <td class="col-md-8">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <select name="enable" id="enable" class="form-control">
                                                            <?php $enabled = boolval($settings['enable_overlay']);
                                                            echo sprintf('<option value="1" %s>Yes</option>',
                                                                ($enabled ? 'selected' : ''));

                                                            echo sprintf('<option value="0" %s>No</option>',
                                                                (!$enabled ? 'selected' : '')); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>

                                        <tr><!-- Default Overlay URL -->
                                            <td><label>Default URL :</label></td>
                                            <td>
                                                <input type="url" name="default-url" id="default-url" class="form-control"
                                                       placeholder="https://www.example.com"
                                                       value="<?php echo $settings['default_url']; ?>">
                                            </td>
                                        </tr>


                                        <tr><td>&nbsp;</td><td><hr style="margin:5px 0;"></td></tr>


                                        <tr><!-- Title Enable Switch -->
                                            <td><label>Enable Title :</label></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <select id="title-select" name="title_enable" class="form-control">
                                                            <?php $enabled = isset($settings['title']['enable'])
                                                                ? boolval($settings['title']['enable'])
                                                                : false;
                                                            echo sprintf('<option value="1" %s>Yes</option>',
                                                                ($enabled ? 'selected' : ''));
                                                            echo sprintf('<option value="0" %s>No</option>',
                                                                (!$enabled ? 'selected' : '')); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>

                                        <tr><!-- Title Position -->
                                            <td><label>Set title position :</label></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <select name="title_position" class="form-control">
                                                            <?php $title_position = isset($settings['title']['position'])
                                                                ? $settings['title']['position'] : 'left'; ?>
                                                            <option value="left"
                                                                <?php echo ($title_position == 'left') ? 'selected' : ''; ?>>Left</option>
                                                            <option value="right"
                                                                <?php echo ($title_position == 'right') ? 'selected' : ''; ?>>Right</option>
                                                            <option value="center"
                                                                <?php echo ($title_position == 'center') ? 'selected' : ''; ?>>Center</option>
                                                            <option value="justified"
                                                            <?php echo ($title_position == 'justified') ? 'selected' : ''; ?>>Justified</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>

                                        <tr><!-- Title Font Size -->
                                            <td><label>Set font size :</label></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="input-group">
                                                            <?php $font_size = isset($settings['title']['font_size'])
                                                                ? intval($settings['title']['font_size']) : '';
                                                                if($font_size == 0) $font_size = ''; ?>
                                                            <input type="text" name="title_font_size" class="form-control"
                                                                   value="<?php echo $font_size; ?>"
                                                                   placeholder="default">
                                                            <span class="input-group-addon" style="padding:5px;font-size:11px;">px</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>

                                        <tr><!-- Title Padding -->
                                            <td><label>Set title padding :</label></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="input-group">
                                                            <?php $title_padding = isset($settings['title']['padding']) ?
                                                                intval($settings['title']['padding']) : '';
                                                                if($title_padding == 0) $title_padding = ''; ?>
                                                            <input type="text" name="title_padding" class="form-control"
                                                                   value="<?php echo $title_padding; ?>"
                                                                   placeholder="default">
                                                            <span class="input-group-addon" style="padding:5px;font-size:11px;">px</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>

                                        <tr><!-- Title Text Color -->
                                            <td><label>Text Color :</label></td>
                                            <td>
                                                <?php $font_color = isset($settings['title']['font_color'])
                                                ? $settings['title']['font_color']
                                                : ''; ?>
                                                <input type="text" name="title_text_color" id="lpp_title_color"
                                                       value="<?php echo $font_color; ?>">
                                            </td>
                                        </tr>

                                        <tr><!-- Title Background Color -->
                                            <td><label>Background :</label></td>
                                            <td>
                                                <?php $background = isset($settings['title']['background'])
                                                ? $settings['title']['background']
                                                : ''; ?>
                                                <input type="text" name="title_background_color" id="lpp_background_color"
                                                       value="<?php echo $background; ?>">
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <input type="submit" class="button button-primary" value="Submit">
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-7">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Categories</h3>
                </div>
                <div class="panel-body">

                    <table class="table no-border" id="copy-to-all-cat-table">
                        <tbody>
                            <tr>
                                <td class="col-md-4 text">Copy this url to all categories :</td>
                                <td class="col-md-7">
                                    <input type="text" id="ctoall-value" class="form-control" placeholder="http://example.com">
                                </td>
                                <td class="col-md-1">
                                    <input type="submit" id="ctoall-submit" class="button default" value="Copy">
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" autocomplete="off">

                        <input type="hidden" name="action" value="save_phantom_settings">
                        <input type="hidden" name="categories" value="1">
                        <?php wp_nonce_field('save_phantom_settings', 'lpp_save_settings'); ?>

                        <table class="table table-striped no-border">
                            <thead>
                            <tr>
                                <th class="col-md-3">Name</th>
                                <th class="col-md-8">URL</th>
                                <th class="col-md-1 text-center">Disable</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $cat_settings = $settings['categories'];
                            foreach($categories as $category):

                                $cat_id = $category->cat_ID;
                                $cat_url = isset($cat_settings['overlay_url'][$cat_id]) ? $cat_settings['overlay_url'][$cat_id] : '';
                                $cat_disable = isset($cat_settings['overlay_disable'][$cat_id]) ? true : false; ?>

                                <tr>
                                    <td class="col-md-5" style="font-weight:bold;font-size:13px"><?php echo $category->name; ?></td>
                                    <td class="col-md-6">
                                        <?php echo sprintf('<input type="text" name="overlay-url[%d]" class="form-control cat-url-value" value="%s" %s>',
                                            $cat_id, $cat_url, 'placeholder="https://www.example.com"'); ?>
                                    </td>
                                    <td class="col-md-1 text-center">
                                        <?php echo sprintf('<input type="checkbox" name="overlay-disable[%d]" %s>',
                                            $cat_id, ($cat_disable ? 'checked' : '')); ?>
                                    </td>
                                </tr>

                            <?php endforeach; ?>
                            </tbody>
                        </table>

                        <input type="submit" class="button button-primary" value="Submit">
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<script>
    (function($) {
        $(document).ready(function() {

            var ctoall_val = $('#ctoall-value');
            var ctoall_btn = $('#ctoall-submit');
            var cat_url = $('.cat-url-value');

            ctoall_btn.click(function(e) {
                e.preventDefault();
                if(ctoall_val.val !== '') {
                    cat_url.val(ctoall_val.val());
                }
            });

        });
    })(jQuery);
</script>
