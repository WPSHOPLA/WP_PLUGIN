<?php if(!defined('ABSPATH')) exit; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">Active Leads</h4>
                </div>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" autocomplete="off">

                    <input type="hidden" name="action" value="update_leads">
                    <?php wp_nonce_field('update_leads', 'lpp_update_leads'); ?>

                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th><input type="checkbox" id="select-all-active"></th>
                                <th class="col-md-2">Name</th>
                                <th class="col-md-2">Email</th>
                                <th class="col-md-2">URL</th>
                                <th class="col-md-3">Post</th>
                                <th class="col-md-1">Start Date</th>
                                <th class="col-md-1">End Date</th>
                                <th class="col-md-1">Amount Paid</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($active_leads)): ?>
                                <?php foreach($active_leads as $record): ?>
                                    <tr>
                                        <td><input type="checkbox" name="bulk-id[<?php echo $record->id ?>]" class="bulk-id-active"></td>
                                        <td><?php echo stripslashes($record->name); ?></td>
                                        <td><?php echo stripslashes($record->email); ?></td>
                                        <td><?php echo stripslashes($record->url); ?></td>
                                        <td>
                                            <?php
                                            $post_link = get_permalink($record->post_id);
                                            $post_title = $record->post_title;
                                            echo sprintf('<a href="%s" target="_blank" class="lc-post-title">%s</a>', $post_link, $post_title);
                                            ?>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($record->lease_start_date)); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($record->lease_end_date)); ?></td>
                                        <td class="text-center">
                                            <span class="label label-primary" style="padding:5px 10px">$<?php echo $record->mc_gross; ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8">
                                        <h4>There are no active leads !</h4>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <div class="row">
                        <div class="col-md-2">
                            <table class="table no-border" style="margin-bottom:0">
                                <tbody>
                                    <tr>
                                        <td>
                                            <select name="bulk-action">
                                                <option value="0">Bulk Actions</option>
                                                <option value="delete">Delete</option>
                                                <option value="email">E-mail</option>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="submit" class="button button-primary" value="Apply">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">Leads</h4>
                </div>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" autocomplete="off">

                    <input type="hidden" name="action" value="update_leads">
                    <?php wp_nonce_field('update_leads', 'lpp_update_leads'); ?>

                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th><input type="checkbox" id="select-all-other"></th>
                            <th class="col-md-2">Name</th>
                            <th class="col-md-2">Email</th>
                            <th class="col-md-2">URL</th>
                            <th class="col-md-3">Post</th>
                            <th class="col-md-2">Date</th>
                            <th class="col-md-1">Ordered</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(count($expired_leads)): ?>
                        <?php foreach($expired_leads as $record): ?>
                            <tr>
                                <td><input type="checkbox" name="bulk-id[<?php echo $record->id ?>]" class="bulk-id-other"></td>
                                <td><?php echo stripslashes($record->name); ?></td>
                                <td><?php echo stripslashes($record->email); ?></td>
                                <td><?php echo stripslashes($record->url); ?></td>
                                <td>
                                    <?php
                                    $post_link = get_permalink($record->post_id);
                                    $post_title = $record->post_title;
                                    echo sprintf('<a href="%s" target="_blank" class="lc-post-title">%s</a>', $post_link, $post_title);
                                    ?>
                                </td>
                                <td><?php echo date('M d, Y (H:i)', strtotime($record->order_date)); ?></td>
                                <td class="text-center">
                                    <?php if(boolval($record->ordered)) {
                                        echo '<span class="label label-primary">Yes</span>';
                                    } else {
                                        echo '<span class="label label-warning">No</span>';
                                    } ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7">
                                    <h4>Nothing to display here. Looks like nobody has tried to rent a page yet !</h4>
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>

                    <div class="row">
                        <div class="col-md-2">
                            <table class="table no-border" style="margin-bottom:0">
                                <tbody>
                                <tr>
                                    <td>
                                        <select name="bulk-action">
                                            <option value="0">Bulk Actions</option>
                                            <option value="delete">Delete</option>
                                            <option value="email">E-mail</option>
                                        </select>
                                    </td>
                                    <td>
                                        <input type="submit" class="button button-primary" value="Apply">
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    jQuery('#select-all-active').click(function(e) {
        if(this.checked) {
            jQuery('.bulk-id-active').prop('checked', 'checked');
        } else {
            jQuery('.bulk-id-active').removeProp('checked');
        }
    });
    jQuery('#select-all-other').click(function(e) {
        if(this.checked) {
            jQuery('.bulk-id-other').prop('checked', 'checked');
        } else {
            jQuery('.bulk-id-other').removeProp('checked');
        }
    });
</script>
