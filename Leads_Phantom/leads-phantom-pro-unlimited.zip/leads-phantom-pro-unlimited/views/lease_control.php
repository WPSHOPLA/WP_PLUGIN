<?php if(!defined('ABSPATH')) exit; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">

            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">Lease Control Panel</h4>
                </div>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" autocomplete="off">

                        <input type="hidden" name="action" value="save_lease_control_settings">
                        <?php wp_nonce_field('save_lease_control_settings', 'lpp_lease_control_settings'); ?>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th class="col-md-1 text-center">Available</th>
                                    <th class="col-md-4">Post / Page - Title</th>
                                    <th class="col-md-1 text-center">Type</th>
                                    <th class="col-md-3">Overlay URL</th>
                                    <th class="col-md-1">Price</th>
                                    <th class="col-md-1 text-center">Enable CTA</th>
                                    <th class="col-md-1 text-center">Master Disable</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php if(count($posts)): foreach($posts as $post):
                                    $lease_settings = get_post_meta($post->ID, 'lpp_lease_settings', true); ?>
                                    <tr>

                                        <td class="" style="padding-left:20px">
                                            <?php // Check post lease status.
                                            $available = empty($post->lease_end_date);
                                            echo sprintf('<input type="hidden" name="available[%s]" value="%s">',
                                                $post->ID, intval($available));

                                            if($available) echo '<span class="label label-success"> AVAILABLE </span>';
                                            else echo '<span class="label label-danger"> LEASED </span>';
                                            ?>
                                        </td>

                                        <td>
                                            <?php $post_link = get_permalink($post->ID);
                                            echo sprintf('<a href="%s" target="_blank" class="lc-post-title">%s</a>',
                                                $post_link, $post->post_title); ?>
                                        </td>

                                        <td class="text-center">
                                            <?php $p_type = ($post->post_type == 'post') ? true : false;
                                            if($p_type) {
                                                echo '<span class="label label-default"> POST </span>';
                                            } else {
                                                echo '<span class="label label-warning"> PAGE </span>';
                                            } ?>
                                        </td>

                                        <td class="lc-input-field">
                                            <?php // Post overlay url
                                            $url = isset($lease_settings['overlay_url']) ? $lease_settings['overlay_url'] : '';
                                            $extra = (!$available) ? 'disabled' : '';
                                            echo sprintf('<input type="url" name="overlay-url[%s]" class="%s" value="%s" placeholder="%s" %s>',
                                                $post->ID, 'form-control', $url, 'default', $extra);
                                            ?>
                                        </td>

                                        <td class="lc-input-field">
                                            <?php // Post overlay price
                                            $price = isset($lease_settings['price']) ? $lease_settings['price'] : '';
                                            $extra = (!$available) ? 'disabled' : '';
                                            echo sprintf('<input type="text" name="price[%s]" class="%s" value="%s" placeholder="%s" %s>',
                                                $post->ID, 'form-control', $price, 'default', $extra);
                                            ?>
                                        </td>

                                        <td class="text-center">
                                            <?php $lease_enabled = isset($lease_settings['enable'])
                                                                   ? boolval($lease_settings['enable']) : '';
                                            echo sprintf('<input type="checkbox" class="enable" name="enable[%s]" %s>',
                                                $post->ID, ($lease_enabled ? 'checked' : '')); ?>
                                        </td>

                                        <td class="text-center">
                                            <?php $m_disable = isset($lease_settings['master_disable'])
                                                               ? $lease_settings['master_disable'] : '';
                                            echo sprintf('<input type="checkbox" class="m-disable" name="master-disable[%s]" %s>',
                                                $post->ID, ($m_disable ? 'checked' : '')); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; endif; ?>

                            </tbody>
                        </table>

                        <div style="margin:0 0 15px 15px;">
                            <input type="submit" class="button button-primary" value="Submit">
                            <input type="button" id="toggle-cta" class="button button-default" value="Toggle CTA Popup">
                            <input type="button" id="toggle-m-disable" class="button button-default" value="Toggle Master Disable">
                        </div>

                    </form>
            </div>
        </div>
    </div>
</div>

<script>
(function($) {
    $(document).ready(function() {
        var f_action = ['enable', 'enable'];
        var toggle_cta_btn = $('#toggle-cta');
        var toggle_m_disable_btn = $('#toggle-m-disable');

        toggle_cta_btn.click(function(e) {
            e.preventDefault();

            var enable_switch = $('.enable');
            if(f_action[0] == 'enable') {
                enable_switch.prop('checked', 'checked');
                f_action[0] = 'disable';
            } else {
                enable_switch.removeAttr('checked');
                f_action[0] = 'enable';
            }
        });

        toggle_m_disable_btn.click(function(e) {
            e.preventDefault();
            var enable_switch = $('.m-disable');
            if(f_action[1] == 'enable') {
                enable_switch.prop('checked', 'checked');
                f_action[1] = 'disable';
            } else {
                enable_switch.removeAttr('checked');
                f_action[1] = 'enable';
            }
        });

    });
})(jQuery);
</script>
