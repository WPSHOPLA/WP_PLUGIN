<?php if(!defined('ABSPATH')) exit;

/**
 * This code is inserted in wp_footer if the user
 * has enabled the CTA Popup in the Lease Settings page.
 */

$post_id        = get_the_ID();
$cta_settings   = get_option('lpp_lease_cta_settings');
$popup_settings = get_option('lpp_lease_popup_settings');


// Get payment settings
$payment_settings = get_option('lpp_payment_settings');
$payment_mode     = isset($payment_settings['mode']) ? boolval($payment_settings['mode']) : false;
$payment_mode     = boolval($payment_mode) ? get_config('paypal.live') : get_config('paypal.sandbox');


// -----------------------------------------------------------------------------------
// Lease CTA Text
// -----------------------------------------------------------------------------------
$cta_title = "Want to see your website in here ? We've got you covered.<br>Click the button below while it's still available !";
$cta_button = "Order Now";

if(isset($cta_settings['title_txt'])
    && (!empty($cta_settings['title_txt']))) {
    $cta_title = stripslashes($cta_settings['title_txt']);
}

if(isset($cta_settings['btn_txt'])
    && (!empty($cta_settings['btn_txt']))) {
    $cta_button = stripslashes($cta_settings['btn_txt']);
}


// -----------------------------------------------------------------------------------
// Lease CTA Style
// -----------------------------------------------------------------------------------
$cta_css = '';
$cta_title_css = '';
$cta_btn_css = '';

// Get CTA Background Color
if(isset($cta_settings['bg_color']) && !empty($cta_settings['bg_color'])) {
    if(isset($cta_settings['opacity'])
        && is_numeric($cta_settings['opacity'])
            && ($cta_settings['opacity'] !== 100)) {
        $bg_color = convert_hex_to_rgb($cta_settings['bg_color'], $cta_settings['opacity']);
        $cta_css .= 'background:rgba('. implode(',', $bg_color) .');';
    } else {
        $bg_color = convert_hex_to_rgb($cta_settings['bg_color']);
        $cta_css .= 'background:rgb('. implode(',', $bg_color) .');';
    }
}

// Get CTA Position
$cta_position = 'cta-default';
if(isset($cta_settings['position']) && !empty($cta_settings['position'])) {
    switch($cta_settings['position']) {
        case 'default': $cta_position = 'cta-default'; break;
        case 'bottom': $cta_position = 'cta-bottom'; break;
        case 'top': $cta_position = 'cta-top'; break;
        case 'fullscreen': $cta_position = 'cta-fullscreen'; break;
    }
}

// Get CTA Title color
if(isset($cta_settings['title_color']) && !empty($cta_settings['title_color'])) {
    $cta_title_css .= 'color:'. $cta_settings['title_color'] .';';
}

// Get CTA Button Color
if(isset($cta_settings['btn_color']) && !empty($cta_settings['btn_color'])) {
    $cta_btn_css .= 'background:'. $cta_settings['btn_color'] .';';
}

// Get CTA Buttons Text Color
if(isset($cta_settings['btn_txt_color']) && !empty($cta_settings['btn_txt_color'])) {
    $cta_btn_css .= 'color:'. $cta_settings['btn_txt_color'] .';';
}


// -----------------------------------------------------------------------------------
// Lease CTA Form Popup
// -----------------------------------------------------------------------------------
$popup_title = 'Replace this title in Lease Settings in Admin Dashboard';
$popup_logo = get_config('assets', 'img/leads-phantom-logo.png');
$popup_content = <<<_END
<div id="lease-popup-content" class="clearfix">
    <img class="alignnone" src="$popup_logo" alt="Logo">
    Change the content of this popup in the Lease Settings in Admin Dashboard
    <ul>
        <li>You can add logos</li>
        <li>Formated text</li>
        <li>Lists</li>
    </ul>
</div>
_END;

if(isset($popup_settings['title'])
    && (!empty($popup_settings['title']))) {
    $popup_title = $popup_settings['title'];
}
if(isset($popup_settings['content'])
    && (!empty($popup_settings['content']))) {
    $popup_content = $popup_settings['content'];
} ?>

<?php if(isset($_GET['lpp-payment-status']) && ($_GET['lpp-payment-status'] == '1')) : ?>
<div id="lease-popup" class="thank-you clearfix">
    <h3 id="lease-popup-title">Thank you for your purchase !</h3>
    <div id="lease-popup-content" style="width:100%;max-width:100%;">
        <h3>Please wait a couple seconds while we setup your url.</h3>
        <p>After the setup is completed, you will see your website in this page.</p>
    </div>
    <a id="lease-popup-close-btn"></a>
</div>
<?php else: ?>

<div id="lease-cta" class="text-center no-select <?php echo $cta_position; ?>" style="<?php echo $cta_css; ?>">
    <div id="lease-cta-cholder">
        <h2 id="lease-cta-title" style="<?php echo $cta_title_css; ?>"><?php echo $cta_title; ?></h2>
        <button id="lease-cta-btn" style="<?php echo $cta_btn_css; ?>"><?php echo $cta_button; ?></button>
    </div>
    <a id="lease-cta-close-btn"></a>
</div>
<div id="lease-cta-placeholder" style="bottom:-500px">
    <img src="<?php echo get_config('assets', 'img/expand.png') ?>">
</div>

<div id="lease-popup" class="clearfix hidden">
    <h3 id="lease-popup-title"><?php echo $popup_title ?></h3>
    <div id="lease-popup-content">
        <?php echo stripslashes($popup_content); ?>
    </div>

    <form id="paypal" action="<?php echo $payment_mode; ?>" method="post" style="display:none;visibility:hidden;">
        <input type="hidden" name="cmd" value="_xclick">
        <input type="hidden" name="business" value="">
        <input type="hidden" name="item_name" value="">
        <input type="hidden" name="item_number" value="">
        <input type="hidden" name="amount" value="">
        <input type="hidden" name="currency_code" value="">
        <input type="hidden" name="custom" value="">

        <input type="hidden" name="button_subtype" value="services">
        <input type="hidden" name="no_note" value="1">
        <input type="hidden" name="no_shipping" value="1">
        <input type="hidden" name="rm" value="1">

        <input type="hidden" name="return" value="">
        <input type="hidden" name="cancel_return" value="">
        <input type="hidden" name="notify_url" value="">
    </form>

    <form id="lease-popup-form" action="<?php echo admin_url('admin-post.php'); ?>" method="post" autocomplete="off">

        <input type="hidden" name="action" value="cta_submit">
        <input type="hidden" name="pid" value="<?php echo $post_id; ?>">
        <?php wp_nonce_field('cta_submit', 'lpp_save_lease_status'); ?>

        <p>Your name<br><input type="text" name="name" placeholder="John Doe"></p>
        <p>Your e-mail address<br><input type="email" name="email" placeholder="john.doe@example.com"></p>
        <p>Your website<br><input type="url" name="url" placeholder="https://www.example.com"></p>
        <p>How long do you want to lease<br>
            <select id="lease-popup-period-selector" name="period">
                <option value="1" selected>1 Month</option>
                <option value="2">2 Months</option>
                <option value="3">3 Months</option>
                <option value="4">4 Months</option>
                <option value="5">5 Months</option>
                <option value="6">6 Months</option>
            </select>
        </p>

        <div class="clearfix" style="margin-top:20px">
            <button type="submit" id="lease-popup-btn-order">Order Now</button>
            <button id="lease-popup-btn-trial">3 Minute Trial</button>
        </div>
    </form>

    <a id="lease-popup-close-btn"></a>
</div>

<?php endif; ?>
