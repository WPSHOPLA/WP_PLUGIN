<?php if(!defined('ABSPATH')) exit; ?>

<div class="container-fluid">
    <div class="row">

        <div class="col-md-6">

            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">CTA Settings</h4>
                </div>
                <div class="panel-body">
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" autocomplete="off">
                        <input type="hidden" name="action" value="save_lease_settings">
                        <input type="hidden" name="cta" value="1">
                        <?php wp_nonce_field('save_lease_settings', 'lpp_save_lease_settings'); ?>

                        <div class="form-group">
                            <label>CTA Heading</label>
                            <?php $cta_title = isset($settings['cta']['title_txt']) ? $settings['cta']['title_txt'] : '';
                            echo sprintf('<input type="text" name="cta-title-txt" class="form-control" value="%s" placeholder="%s">',
                                stripslashes($cta_title), 'Rent this page. Your logo, your number, your customers !');
                            ?>
                        </div>

                        <style>.table > tbody > tr > td {padding-left:0}</style>
                        <table class="table no-border">
                            <tbody>

                                <tr>
                                    <td class="col-md-6"><label>CTA Button text :</label></td>
                                    <td class="col-md-6">
                                        <div class="row">
                                            <div class="col-md-10">
                                                <?php $cta_btn_txt = isset($settings['cta']['btn_txt']) ? $settings['cta']['btn_txt'] : '';
                                                echo sprintf('<input type="text" name="cta-btn-txt" class="form-control" value="%s" placeholder="%s">',
                                                    stripslashes($cta_btn_txt), 'Order Now');
                                                ?>
                                            </div>
                                        </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="col-md-6"><label>CTA position :</label></td>
                                    <td class="col-md-6">
                                        <div class="row">
                                            <div class="col-md-10">
                                                <select name="cta-position" class="form-control">
                                                    <?php $position = isset($settings['cta']['position'])
                                                        ? $settings['cta']['position'] : 'default'; ?>
                                                    <option value="1" <?php if($position == 'default') echo 'selected'; ?>>Default / Bottom</option>
                                                    <option value="2" <?php if($position == 'bottom') echo 'selected'; ?>>Bottom / Fullwidth</option>
                                                    <option value="3" <?php if($position == 'top') echo 'selected'; ?>>Top / Fullwidth</option>
                                                    <option value="4" <?php if($position == 'fullscreen') echo 'selected'; ?>>Fullscreen</option>
                                                </select>
                                            </div>
                                        </div>
                                    </td>
                                </tr>

                                <tr><!-- CTA Background Color -->
                                    <td class="col-md-6"><label>CTA background color :</label></td>
                                    <td class="col-md-4">
                                        <?php $color = isset($settings['cta']['bg_color']) ? $settings['cta']['bg_color'] : '';
                                        echo sprintf('<input type="hidden" name="cta-bg-color" id="cta-bg-color" value="%s">',
                                            $color);
                                        ?>
                                    </td>
                                    <td class="col-md-2">&nbsp;</td>
                                </tr>

                                <tr><!-- CTA Opacity -->
                                    <td class="col-md-6"><label>CTA opacity :</label></td>
                                    <td class="col-md-6">
                                        <?php $opacity = isset($settings['cta']['opacity']) ? $settings['cta']['opacity'] : '100';
                                        echo sprintf('<input type="range" name="cta-opacity" id="cta-opacity" value="%s">', $opacity); ?>
                                    </td>
                                    <td class="col-md-0">&nbsp;</td>
                                </tr>

                                <tr><!--  -->
                                    <td class="col-md-6"><label>CTA text color :</label></td>
                                    <td class="col-md-4">
                                        <?php $color = isset($settings['cta']['title_color']) ? $settings['cta']['title_color'] : '';
                                        echo sprintf('<input type="hidden" name="cta-txt-color" id="cta-txt-color" value="%s">',
                                            $color);
                                        ?>
                                    </td>
                                    <td class="col-md-2">&nbsp;</td>
                                </tr>

                                <tr><!--  -->
                                    <td class="col-md-6"><label>CTA button color :</label></td>
                                    <td class="col-md-4">
                                        <?php $color = isset($settings['cta']['btn_color']) ? $settings['cta']['btn_color'] : '';
                                        echo sprintf('<input type="hidden" name="cta-btn-color" id="cta-btn-color" value="%s">',
                                            $color);
                                        ?>
                                    </td>
                                    <td class="col-md-2">&nbsp;</td>
                                </tr>

                                <tr>
                                    <td class="col-md-6"><label>CTA button text color :</label></td>
                                    <td class="col-md-4">
                                        <?php $color = isset($settings['cta']['btn_txt_color']) ? $settings['cta']['btn_txt_color'] : '';
                                        echo sprintf('<input type="hidden" name="cta-btn-txt-color" id="cta-btn-txt-color" value="%s">',
                                            $color);
                                        ?>
                                    </td>
                                    <td class="col-md-2">&nbsp;</td>
                                </tr>
                            </tbody>
                        </table>

                        <input type="submit" class="button button-primary" value="Submit">
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">Popup Settings</h4>
                </div>
                <div class="panel-body">
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" autocomplete="off">
                        <input type="hidden" name="action" value="save_lease_settings">
                        <input type="hidden" name="popup" value="1">
                        <?php wp_nonce_field('save_lease_settings', 'lpp_save_lease_settings'); ?>

                        <div class="form-group">
                            <label>Popup Title</label>
                            <?php $popup_title = isset($settings['popup']['title']) ? $settings['popup']['title'] : '';
                            echo sprintf('<input type="text" name="title" class="form-control" value="%s" placeholder="%s">',
                                $popup_title, ''); ?>

                        </div>

                        <div class="form-group">
                            <label>Popup Content</label><br>
                            <?php $content = isset($settings['popup']['content']) ? $settings['popup']['content'] : '';
                            wp_editor(stripslashes($content), 'popup-content', array('textarea_rows' => 10)); ?>
                        </div>

                        <input type="submit" class="button button-primary" value="Submit">
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>
