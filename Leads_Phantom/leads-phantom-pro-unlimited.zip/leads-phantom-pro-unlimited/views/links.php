<?php if(!defined('ABSPATH')) exit; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-5">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">Phantom Links Settings</h4>
                </div>
                <div class="panel-body">
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" autocomplete="off">

                        <input type="hidden" name="action" value="save_phantom_links">
                        <?php wp_nonce_field('save_phantom_links', 'lpp_save_links'); ?>

                        <table class="table no-border">
                            <tbody>
                                <tr>
                                    <td class="col-md-5" style="padding-left:0;"><label for="allowed">Enable Phantom Links:</label></td>
                                    <td class="col-md-3">
                                        <select id="allowed" name="enable" class="form-control">

                                            <?php $enabled = $settings['enable'];
                                            echo sprintf('<option value="1" %s>Yes</option>', ($enabled ? 'selected' : ''));
                                            echo sprintf('<option value="0" %s>No</option>', (!$enabled ? 'selected' : '')); ?>

                                        </select>
                                    </td>
                                    <td class="col-md-4">&nbsp;</td>
                                </tr>
                            </tbody>
                        </table>

                        <div class="form-group">
                            <label for="allowed">Allowed domains</label>
                            <textarea id="allowed" name="allowed" class="form-control"
                            rows="8" wrap="hard"><?php echo $settings['allowed']; ?></textarea>
                        </div>

                        <input type="submit" class="button button-primary" value="Submit">

                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-5">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">Help</h4>
                </div>
                <div class="panel-body">
                    <p class="help-list-title">
                        Use this feature to hide links from search engines and increase your ranking.
                    </p>
                    <ul class="help-list">
                        <li>
                            <h4>Hide links from search engines</h4>
                            <p class="description">
                                This can result in lower PPC costs, and you can increase your search engine rankings
                                and link to whatever offer or website you choose without search engines penalizing you.
                            </p>
                        </li>
                        <li>
                            <h4>Allowed Domains</h4>
                            <p class="description">
                                You can choose to allow some domains through by entering them in the box.
                                Each domain must be entered in a separate line and without the <i>http://</i> or <i>www</i> part.
                                Just the domain name.<br>
                                See the example below.
                            </p>
                            <?php echo sprintf("<pre>%s\n%s</pre>", 'domain.com', 'another-domain.com') ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
