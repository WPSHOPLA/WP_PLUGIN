<?php if(!defined('ABSPATH')) exit; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">PayPal Settings</h4>
                </div>
                <div class="panel-body">
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" autocomplete="off">
                        <input type="hidden" name="action" value="save_payment_settings">
                        <?php wp_nonce_field('save_payment_settings', 'lpp_save_payment_settings'); ?>

                        <table class="table no-border">
                            <tbody>
                                <tr>
                                    <td class="col-md-3" style="padding-left:0;">
                                        <label>PayPal mode</label>
                                    </td>
                                    <td class="col-md-4">
                                        <select id="allowed" name="mode" class="form-control">
                                            <?php $mode = isset($settings['mode']) ? boolval($settings['mode']) : false;
                                            echo sprintf('<option value="1" %s>Live Mode</option>', ($mode ? 'selected' : ''));
                                            echo sprintf('<option value="0" %s>Testing Mode</option>', (!$mode ? 'selected' : '')); ?>
                                        </select>
                                    </td>
                                    <td class="col-md-5">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="padding-left:0;">
                                        <label>Amount</label>
                                    </td>
                                    <td>
                                        <?php $amount = isset($settings['amount']) ? $settings['amount'] : '';
                                        $amount = boolval($amount) ? $amount : '';
                                        echo sprintf('<input type="text" name="amount" class="form-control" value="%s" placeholder="%s">',
                                            $amount, '79.99'); ?>
                                    </td>
                                    <td>&nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="padding-left:0;">
                                        <label>Currency</label>
                                    </td>
                                    <td>
                                        <select name="currency" class="form-control">
                                            <?php // Display a list of currencies
                                            $selected_currency = isset($settings['currency']) ? $settings['currency'] : 'USD';
                                            foreach(get_config('currencies') as $code => $currency) {
                                                echo sprintf('<option value="%s" %s>%s</option>', $code,
                                                    ($selected_currency == $code ? 'selected' : ''),
                                                    $currency['label']);
                                            } ?>
                                        </select>
                                    </td>
                                    <td>&nbsp;</td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="form-group">
                            <label>PayPal recipient e-mail</label>
                            <?php $recipient = isset($settings['recipient']) ? $settings['recipient'] : '';
                            echo sprintf('<input type="email" name="recipient" class="form-control" value="%s" placeholder="%s">',
                                $recipient, 'john.doe@example.com'); ?>
                        </div>
                        <div class="form-group">
                            <label>PayPal Description</label>
                            <?php $description = isset($settings['description']) ? $settings['description'] : '';
                            echo sprintf('<textarea name="description" class="form-control" rows="5">%s</textarea>', $description); ?>
                        </div>

                        <input type="submit" class="button button-primary" value="Submit">
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-5">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">Help</h4>
                </div>
                <div class="panel-body">
                    <ul class="help-list">
                        <li>
                            <h4>PayPal mode</h4>
                            <p class="description">
                                Choose testing mode when you want to test the features,
                                but you must have a PayPal Sandbox account to be able to purchase / test the functionality. When you chose Live Mode, all transactions will be with real money.
                            </p>
                        </li>
                        <li>
                            <h4>PayPal Description</h4>
                            <p class="description">
                                This is the description of the product you're selling.
                                The clients will see this description when they purchase your product,
                                and will also see it in their transactions history in PayPal.
                            </p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
