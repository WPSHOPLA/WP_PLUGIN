/*!
 * jQuery Build Personal Page Plugin
 * version: 1.0
 */
(function ($) {

 	"use strict";

 	$.fn.build_personal_page = function(){

 		var xhttp;
		if (window.XMLHttpRequest) {
		    xhttp = new XMLHttpRequest();
		    } else {
		    // code for IE6, IE5
		    xhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		xhttp.onreadystatechange = function() {
      	  if (xhttp.readyState == 4 && xhttp.status == 200) {
            document.getElementById("demo").innerHTML = xhttp.responseText;
        	}
    	};

		xhttp.open("POST", "../includes/create.php", true);
		xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xhttp.send("fname=Henry&lname=Ford");

 	}



 }(jQuery));