   $this->upload_dir                            = wp_upload_dir();

        $this->uploads_dir                              = $this->upload_dir['basedir'];
        // C:\path\to\wordpress\wp-content\uploads

        $this->uploads_url                              = $this->upload_dir['baseurl'];
        // http://example.com/wp-content/uploads

        $this->uploads_cm_dir                   = $this->upload_dir['path'];
        //C:\path\to\wordpress\wp-content\uploads\2016\07

        $this->uploads_cm_url                   = $this->upload_dir['url'];
        // http://example.com/wp-content/uploads/2016/07


        $this->upload_plugin_url                = $this->upload_dir['baseurl'].'/ppc-builder';
        // http://example.com/wp-content/uploads/ppc-builder

        $this->upload_plugin_dir                = $this->upload_dir['basedir'].'/ppc-builder';
        // C:\path\to\wordpress\wp-content\uploads\ppc-builder

        $this->upload_ad_dir      = $this->upload_plugin_dir.'/image/Ad';
        // C:\path\to\wordpress\wp-content\uploads\ppc-builder\image\Ad

        $this->upload_logo_dir    = $this->upload_plugin_dir.'/image/Logo';
        // C:\path\to\wordpress\wp-content\uploads\ppc-builder\image\Logo

        $this->upload_img_dir     = $this->upload_plugin_dir.'/image';
        // C:\path\to\wordpress\wp-content\uploads\ppc-builder\image
        
        $this->upload_img_dir     = $this->upload_plugin_dir.'/xlsx';
        // C:\path\to\wordpress\wp-content\uploads\ppc-builder\xlsx
        