<?php
/**
create personal page with template
*/

//check whether tempalte exists

include_once('../../../../../wp-load.php');

$result = array();
$error = array();
$create_pp_result = array();
$current = 0;

if( isset($_POST['files']) )
{
    $upload_dir         = wp_upload_dir();

    $uploads_dir         = $upload_dir['basedir'];
    $uploads_url         = $upload_dir['baseurl'];
    $uploads_cm_dir      = $upload_dir['path'];
    $uploads_cm_url      = $upload_dir['url'];
    $upload_plugin_url   = $upload_dir['baseurl'].'/ppc-builder';
    $upload_plugin_dir   = $upload_dir['basedir'].'/ppc-builder';
    $upload_ad_dir      = $upload_plugin_dir.'/image/Ad';
    $upload_logo_dir    = $upload_plugin_dir.'/image/Logo';
    $upload_img_dir     = $upload_plugin_dir.'/image';
    $upload_xlsx_dir     = $upload_plugin_dir.'/xlsx';



    function estimate($create_files){

        global $upload_xlsx_dir;

        $total_row = 0;

        foreach($create_files as $create_file){
        
            $options_file = $upload_xlsx_dir.'/'.$create_file.'.options.json';

            if(file_exists($options_file)){
                $options = (array) json_decode(file_get_contents($options_file));

                if(isset($options['sheet_names'])){
                    foreach($options['sheet_names'] as $sheetId => $sheetName){

                        $file= '';

                        if($sheetId != 1){
                            $file = $upload_xlsx_dir.'/'.$options['slug'].'_sheet_'.$sheetId.'.json';
                        } else {
                            $file = $upload_xlsx_dir.'/'.$options['slug'].'.json';
                        }

                         if(!file_exists($file))
                        {
                            continue;
                        }

                        $content=(array) json_decode(file_get_contents($file));

                        $row_count=count($content);

                        //eliminate header row
                        $row_count -= 1;

                        $total_row += $row_count;
                    }
                } else {
                    continue;
                }
            } 
        }

        return $total_row;
    }

    function create_personal_pages($create_files){

        global $error, $upload_xlsx_dir;
        $res='success';

        foreach($create_files as $create_file){

            
            $options_file = $upload_xlsx_dir.'/'.$create_file.'.options.json';

            if(file_exists($options_file)){
                $options = (array) json_decode(file_get_contents($options_file));

                if(isset($options['sheet_names'])){
                    foreach($options['sheet_names'] as $sheetId => $sheetName){
                        if($sheetId != 1){
                            $temp_res=create_one_file($create_file, $sheetName, $upload_xlsx_dir.'/'.$options['slug'].'_sheet_'.$sheetId.'.json');
                        } else {
                            $temp_res=create_one_file($create_file, $sheetName, $upload_xlsx_dir.'/'.$options['slug'].'.json');
                        }

                        if( $temp_res == false )
                        {   
                            $res='fail';
                        }
                    }
                }

            }else{
                array_push($error, 'File not found'.$options_file);
            }
        }
        $result['result'] = $res;

    }

    function create_one_file($slug, $sheetName, $file)
    {

        global $create_pp_result, $current;

        $res=true;

        $cerror=array();

        if(!file_exists($file))
        {
            $cerror[0]=$slug;
            $cerror[1]=$sheetName;
            $cerror[2]="File Not Found: ".$file;
            array_push($create_pp_result, $cerror);
            return false;
        }

        $content=(array) json_decode(file_get_contents($file));


        $row_count=count($content);
        if($row_count == 0)
            return true;

        $col_count=count($content[0]);

        for($row=1; $row<$row_count; $row++){

            $one_pp_array=$content[$row];

            $real_row=$row+1;

            if(!create_personal_page($one_pp_array)){
            
                $cerror=array($slug, $sheetName, 'Row: '.$real_row.' Create FAILURE');
                array_push($create_pp_result, $cerror);
                $res=false;

            } else {
                $current++;    
            }
        }//end row

        return $res;
    }

    function create_personal_page($page_array){

        $page_title=$page_array[0].' '.$page_array[1];

        $the_page = get_page_by_title($page_title);

        if (!$the_page)
        {
            // Create post object
            $_p = array();
            $_p['post_title']     = $page_title;
            $_p['post_content']   = "This text may be overridden by the plugin. You shouldn't edit it.";
            $_p['post_status']    = 'publish';
            $_p['post_type']      = 'page';
            $_p['comment_status'] = 'closed';
            $_p['ping_status']    = 'closed';
            $_p['post_category'] = array(1); // the default 'Uncatrgorised'

            // Insert the post into the database: posts table
            $page_id = wp_insert_post($_p);

        } else {
            $page_id = $the_page->ID;
        }


        if($page_id)
        {
            //get custom field from xls data
            $custom_pcfa=make_custom_pcfa($page_array);

            //set custom field
            add_custom_field_to_page($page_id, $custom_pcfa);
        }

        return true;

    }

    function make_custom_pcfa( $page_array){

        $cpcfa=array();
        $cpcfa["personal_last_name"]=$page_array[0];
        $cpcfa["personal_first_name"]=$page_array[1];
        $cpcfa["personal_youtube_url"]=$page_array[2];
        $cpcfa["personal_bt_before_value"]=$page_array[3];
        $cpcfa["personal_bt_after_value"]=$page_array[4];


        $logo_img = $page_array[5];
        $ad_img = $page_array[6];

        //Image processing
        $logo_img = get_real_img_url($logo_img, 0);
        $ad_img = get_real_img_url($ad_img, 1);

        $cpcfa["personal_logo"]=$logo_img;
        $cpcfa["personal_ad_img"]=$ad_img;

        return $cpcfa;
    }

    function get_real_img_url($filename, $la){

        global $upload_logo_dir, $uploads_cm_dir, $uploads_url, $upload_plugin_url, $upload_ad_dir;

        if($la == 0)
        {
            $filename1=$upload_logo_dir.DIRECTORY_SEPARATOR.$filename;
            $w1 = $upload_plugin_url.'/image/Logo/'.$filename;
        } else {
            
            $filename1=$upload_ad_dir.DIRECTORY_SEPARATOR.$filename;
            $w1 = $upload_plugin_url.'/image/Ad/'.$filename;
        }

        $filename1 = str_replace('\\', '/', $filename1);
        $w1 = str_replace('\\', '/', $w1);

        if(file_exists($filename1))
        {
            return $w1;
        }

        $filename2 = $uploads_cm_dir.DIRECTORY_SEPARATOR.$filename;
        $w2 = $uploads_cm_url.'/'.$filename;

        $filename2 = str_replace('\\', '/', $filename2);
        $w2 = str_replace('\\', '/', $w2);

        if (file_exists($filename2)){
            return $w2;
        }

        $subdirs = glob($uploads_dir.'/*', GLOB_ONLYDIR);

        if ($subdirs)
        {
            foreach ($subdirs as $subdir) {
                $filename3= $subdir.DIRECTORY_SEPARATOR.$filename;
                $fileurl = $uploads_url.'/'.(basename(dirname($subdir))).'/'.(basename($subdir)).$filename;

                if(($subdir != $uploads_cm_dir) && (file_exists($filename3)))
                    return $fileurl;
            }
        }

    }

    function get_default_pcfa(){
        $pcfa = array();
        $pcfa['_wp_page_template'] = 'Personal-page-template.php';
        $pcfa['personal_bt_before_title'] = 'Cost Per Lead Before';
        $pcfa['personal_bt_before_value'] = '40';
        $pcfa['personal_bt_after_title'] = 'Cost Per Lead After';
        $pcfa['personal_bt_after_value'] = '-20';
        $pcfa['personal_p-1'] = 'Learn more about my guarantee to increase your sales an make your money.';
        $pcfa['personal_p-2'] = 'Case Studies that demonstrate my ability to deliver results.';
        $pcfa["personal_help_button"] = "See Proof";
        $pcfa["personal_see_button"] = "Help Me Increase My Sales";
        $pcfa["personal_ad_title"] = "Who's Getting All Your Money?";
        $pcfa["personal_youtube_url"] = "https://www.youtube.com/embed/p2qhmgxPrsk?feature=oembed";
        return $pcfa;
    }

    function add_custom_field_to_page($page_id, $custom_pcfa)
    {
        /**
        * set post meta to current page or created new page
        *
        *   $post_meta=get_post_meta($page_id, '', false);
        *
        *   ["_edit_last"]=> array(1) { [0]=> string(1) "1" }
        *   ["_edit_lock"]=> array(1) { [0]=> string(12) "1468072304:1" }
        *   ["_wp_page_template"]=> array(1) { [0]=> string(26) "Personal-page-template.php" }
        *   ["personal_logo"]=> array(1) { [0]=> string(2) "35" }
        *   ["_personal_logo"]=> array(1) { [0]=> string(19) "field_57805a2eb7e70" }
        *   ["personal_bt_before_title"]=> array(1) { [0]=> string(20) "Cost Per Lead Before" }
        *   ["_personal_bt_before_title"]=> array(1) { [0]=> string(19) "field_57805a89b7e71" }
        *   ["personal_bt_before_value"]=> array(1) { [0]=> string(2) "40" }
        *   ["_personal_bt_before_value"]=> array(1) { [0]=> string(19) "field_57805bf6b7e72" }
        *   ["personal_bt_after_title"]=> array(1) { [0]=> string(19) "Cost Per Lead After" }
        *   ["_personal_bt_after_title"]=> array(1) { [0]=> string(19) "field_57805c51b7e73" }
        *   ["personal_bt_after_value"]=> array(1) { [0]=> string(3) "-20" }
        *   ["_personal_bt_after_value"]=> array(1) { [0]=> string(19) "field_57805c95b7e74" }
        *   ["personal_ad_img"]=> array(1) { [0]=> string(2) "38" }
        *   ["_personal_ad_img"]=> array(1) { [0]=> string(19) "field_57805ce9b7e75" }
        *   ["personal_ad_title"]=> array(1) { [0]=> string(29) "Who's Getting All Your Money?" }
        *   ["_personal_ad_title"]=> array(1) { [0]=> string(19) "field_57805d08b7e76" }
        *   ["personal_content_title"]=> array(1) { [0]=> string(19) "Andrew Goldstein..." }
        *   ["_personal_content_title"]=> array(1) { [0]=> string(19) "field_57805d95b7e77" }
        *   ["personal_p-1"]=> array(1) { [0]=> string(72) "Learn more about my guarantee to increase your sales an     make your money." }
        *   ["_personal_p-1"]=> array(1) { [0]=> string(19) "field_57805eb7b7e78" }
        *   ["personal_help_button"]=> array(1) { [0]=> string(25) "Help Me Increase My Sales" }
        *   ["_personal_help_button"]=> array(1) { [0]=> string(19) "field_57805f28b7e79" }
        *   ["personal_help_button_link"]=> array(1) { [0]=> string(1) "1" }
        *   ["_personal_help_button_link"]=> array(1) { [0]=> string(19) "field_57805f66b7e7a" }
        *   ["personal_p-2"]=> array(1) { [0]=> string(60) "Case Studies that demonstrate my ability to deliver results." }
        *   ["_personal_p-2"]=> array(1) { [0]=> string(19) "field_57805f98b7e7b" }
        *   ["personal_see_button"]=> array(1) { [0]=> string(9) "See Proof" }
        *   ["_personal_see_button"]=> array(1) { [0]=> string(19) "field_57805fe3b7e7c" }
        *   ["personal_see_button_link"]=> array(1) { [0]=> string(1) "1" }
        *   ["_personal_see_button_link"]=> array(1) { [0]=> string(19) "field_5780600db7e7d" }
        *   ["personal_youtube_url"]=> array(1) { [0]=> string(40) "http://www.youtube.com/embed/oHg5SJYRHA0" }
        *   ["_personal_youtube_url"]=> array(1) { [0]=> string(19) "field_57806043b7e7e" }
        *   ["personal_first_name"]=> array(1) { [0]=> string(6) "Andrew" }
        *   ["_personal_first_name"]=> array(1) { [0]=> string(19) "field_57806bc42f674" }
        *   ["personal_last_name"]=> array(1) { [0]=> string(9) "Goldstein" }
        *   ["_personal_last_name"]=> array(1) { [0]=> string(19) "field_57806be42f675" 
        */

        //set default custom field
        $pcfa= get_default_pcfa();

        foreach ($pcfa as $key => $value) {
            if ( ! add_post_meta( $page_id, $key, $value, true ) ) {
                update_post_meta( $page_id, $key, $value );
            }
        }

        foreach ($custom_pcfa as $key => $value) {
            if ( ! add_post_meta( $page_id, $key, $value, true ) ) { 
                update_post_meta( $page_id, $key, $value );
            }
        }
    }



    $create_files = $_POST['files'];
    $create_files = explode(',', $create_files);

    $total_count = estimate($create_files);
    $result['total_count'] = $total_count;

    create_personal_pages($create_files);
    
} else {
  $error  = 'Files are not selected.';
  $result['result'] = 'fail';
}

$result['current'] = $current;
$result['error'] = $error;
$result['create_pp_result'] = $create_pp_result;

header("Content-Type: application/json");

echo json_encode($result);

?>
