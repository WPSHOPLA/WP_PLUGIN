<?php
/**
 * WP Excel CMS
 * 
 * @package   PPC_Builder_Admin
 * @author    Erik Johnsson
 * @license   GPL-2.0+
 * @link      http://twitter.com/ero92104823
 * @copyright 2016 TopWebErik
 */

/**
 * Plugin class. This class should ideally be used to work with the
 * administrative side of the WordPress site.
 *
 * If you're interested in introducing public-facing
 * functionality, then refer to `class-plugin-name.php`
 *
 *
 */
class PPC_Builder_Admin {

	/**
	 * Instance of this class.
	 *
	 * @since    1.0.0
	 *
	 * @var      object
	 */
	protected static $instance = null;

	/**
	 * Slug of the plugin screen.
	 *
	 * @since    1.0.0
	 *
	 * @var      string
	 */
	protected $plugin_screen_hook_suffix = null;

	/**
	 * Slug of the plugin screen.
	 *
	 * @since    1.0.0
	 *
	 * @var      string
	 */
	protected $plugin_setting_hook_suffix = null;

	/**
	 * Initialize the plugin by loading admin scripts & styles and adding a
	 * settings page and menu.
	 *
	 * @since     1.0.0
	 */
	private function __construct() {

		/*
		 * @TODO :
		 *
		 * - Uncomment following lines if the admin class should only be available for super admins
		 */
		/* if( ! is_super_admin() ) {
			return;
		} */

		/*
		 * Call $plugin_slug from public plugin class.
		 *
		 * @TODO:
		 *
		 * - Rename "Plugin_Name" to the name of your initial plugin class
		 *
		 */
		$plugin = PPC_Builder::get_instance();
		$this->plugin_slug = $plugin->get_plugin_slug();

		// Load admin style sheet and JavaScript.
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_styles' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );

		// Add the options page and menu item.
        add_action( 'admin_menu', array( $this, 'register_my_custom_menu_page' )  );
        
		add_action( 'admin_menu', array( $this, 'add_plugin_admin_menu' ) );

		add_action( 'admin_menu', array( $this, 'add_personal_template' ) );

		// Add an action link pointing to the options page.
		$plugin_basename = plugin_basename( plugin_dir_path( __DIR__ ) . $this->plugin_slug . '.php' );
		add_filter( 'plugin_action_links_' . $plugin_basename, array( $this, 'add_action_links' ) );

		/*
		 * Define custom functionality.
		 *
		 * Read more about actions and filters:
		 * http://codex.wordpress.org/Plugin_API#Hooks.2C_Actions_and_Filters
		 */
		add_action( '@TODO', array( $this, 'action_method_name' ) );
		add_filter( '@TODO', array( $this, 'filter_method_name' ) );

        
        $this->upload_dir 				= wp_upload_dir();

        $this->uploads_dir		  		= $this->upload_dir['basedir'];
        // C:\path\to\wordpress\wp-content\uploads

        $this->uploads_url		  		= $this->upload_dir['baseurl'];
        // http://example.com/wp-content/uploads

        $this->uploads_cm_dir			= $this->upload_dir['path'];
        //C:\path\to\wordpress\wp-content\uploads\2016\07

        $this->uploads_cm_url			= $this->upload_dir['url'];
        // http://example.com/wp-content/uploads/2016/07


        $this->upload_plugin_url		= $this->upload_dir['baseurl'].'/ppc-builder';
        // http://example.com/wp-content/uploads/ppc-builder

        $this->upload_plugin_dir		= $this->upload_dir['basedir'].'/ppc-builder';
        // C:\path\to\wordpress\wp-content\uploads\ppc-builder

        $this->upload_ad_dir      = $this->upload_plugin_dir.'/image/Ad';
        // C:\path\to\wordpress\wp-content\uploads\ppc-builder\image\Ad

        $this->upload_logo_dir    = $this->upload_plugin_dir.'/image/Logo';
        // C:\path\to\wordpress\wp-content\uploads\ppc-builder\image\Logo

        $this->upload_img_dir     = $this->upload_plugin_dir.'/image';
        // C:\path\to\wordpress\wp-content\uploads\ppc-builder\image
        
        $this->upload_xlsx_dir     = $this->upload_plugin_dir.'/xlsx';
        // C:\path\to\wordpress\wp-content\uploads\ppc-builder\xlsx
        


        if (isset($_GET['page'])){
        	$this->admin_plugin_url   = admin_url( "options-general.php?page=".$_GET["page"] );
        }

        $this->validate_excel_result  = array();
        $this->create_pp_result 	  = array();
        
        $this->current_theme_directory = get_template_directory();


        $this->pcfa=array();

		$this->get_default_pcfa();
        
	}


    function register_my_custom_menu_page(){
      
   
   		$this->plugin_screen_hook_suffix = add_menu_page(
			__( 'PPC Builder', $this->plugin_slug ),
			__( 'PPC Builder', $this->plugin_slug ),
			'edit_pages',
			$this->plugin_slug.'-admin-menu',
			array( $this, 'display_plugin_admin_menu_page' ),
            '',
            '6'
		);
   
   }


  

################################################################################



  function formatSizeUnits($bytes)
    {
        if ($bytes >= 1073741824)
        {
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
        }
        elseif ($bytes >= 1048576)
        {
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
        }
        elseif ($bytes >= 1024)
        {
            $bytes = number_format($bytes / 1024, 2) . ' KB';
        }
        elseif ($bytes > 1)
        {
            $bytes = $bytes . ' bytes';
        }
        elseif ($bytes == 1)
        {
            $bytes = $bytes . ' byte';
        }
        else
        {
            $bytes = '0 bytes';
        }

        return $bytes;
	}





function create_excel_file($file_name){
   
    $new_file_name  = $file_name;
    
    if(empty($new_file_name)){
        return false;
    }
    if(empty($_FILES['file']) || empty($_FILES["file"]['name'])){
        return false;
    }
   
    require_once( plugin_dir_path( __FILE__ ) . '../includes/simplexlsx.class.php' );

	$xlsx = new SimpleXLSX( $_FILES['file']['tmp_name'] );

	$sheetNames = $xlsx->sheetNames();

	if(is_array($sheetNames)){
		foreach($sheetNames as $sheetId => $sheetName){
			if($sheetId != 1){
				$the_name = $new_file_name.'_sheet_'.$sheetId;
			}else{
				$the_name = $new_file_name;
			}

			$jsonData[$sheetId] = json_encode($xlsx->rows($sheetId));
			$this->createJsonDataFile( $jsonData[$sheetId], $the_name );

		}
	}

	$file_ext_temp=explode( ".", $_FILES["file"]['name'] );
	$file_ext = end( $file_ext_temp );
    
    $options = array(
        'slug'          => $new_file_name,
        'filename'      => $new_file_name.'.'.$file_ext,
        'json_file'     => $new_file_name.'.json',
        'options_file'  => $new_file_name.'.options.json',
        'file_ext'      => $file_ext,
        'filesize'      => filesize($_FILES["file"]["tmp_name"]),
        'upload_time'   => time(),
	    'sheet_names'   => $sheetNames,
    );
    
    
    
    $file_name      = $this->upload_xlsx_dir.'/'.$new_file_name.'.options.json';
    $fp = fopen($file_name,"wb");
    fwrite($fp, json_encode($options));
    fclose($fp);   
    
    return array(
        'jsonData' => $jsonData,
        'options' => $options,
    );
    
}

/**
* @param $jsonData
* @param $new_file_name
*
* @return array
*/
public function createJsonDataFile($jsonData, $new_file_name ) {


	$file_name        = $this->upload_xlsx_dir . '/' . $new_file_name . '.json';


	$fp = fopen( $file_name, "wb" );
	fwrite( $fp, $jsonData );
	fclose( $fp );


	if(!strpos($new_file_name, '_sheet_'))
	{
		$file_ext_temp=explode( ".", $_FILES["file"]['name'] );
		$file_ext = end( $file_ext_temp );
		$file_name = $this->upload_xlsx_dir . '/' . $new_file_name . '.' . $file_ext;
		$fp        = fopen( $file_name, "wb" );
		fwrite( $fp, file_get_contents( $_FILES["file"]["tmp_name"] ) );
		fclose( $fp );		
	}


	return true;
}



function getFileList(){
  
      
    //get all image files with a .jpg extension.
    $files = glob($this->upload_xlsx_dir . "/*.options.json");

    if(!$files)
    	return null;
    
    for($i=0;$i<count($files);$i++){ 
        $file_data[$i] = (array) json_decode(file_get_contents($files[$i]));
    }
  
    return $file_data;  
}

function delete_excel_files($del_files){
    
    
    if(!is_array($del_files)){
        return false;
    }
    
    foreach($del_files as $del_file){
        
        $options_file = $this->upload_xlsx_dir.'/'.$del_file.'.options.json';
        
        if(file_exists($options_file)){
            $options = (array) json_decode(file_get_contents($options_file));

	        if(isset($options['sheet_names'])){
		        foreach($options['sheet_names'] as $sheetId => $sheetName){
			        if($sheetId != 1){
			            $res    = @unlink($this->upload_xlsx_dir.'/'.$options['slug'].'_sheet_'.$sheetId.'.json');
			            //$res    = @unlink($this->upload_dir.'/'.$options['slug'].'_sheet_'.$sheetId.'.xlsx');
			        }
		        }
	        }

            $res    = @unlink($this->upload_xlsx_dir.'/'.$options['json_file']);
            $res    = @unlink($this->upload_xlsx_dir.'/'.$options['options_file']);
            $res    = @unlink($this->upload_xlsx_dir.'/'.$options['filename']);
        }else{
            $res = false;
        }
        
    }
    return $res;
    
 }

 function validate_excel_files($validate_files){
    
    if(!is_array($validate_files)){
        return 'fail';
    }
	$res='success';

    foreach($validate_files as $validate_file){
        
        $options_file = $this->upload_xlsx_dir.'/'.$validate_file.'.options.json';
        
        if(file_exists($options_file)){
            $options = (array) json_decode(file_get_contents($options_file));

	        if(isset($options['sheet_names'])){
		        foreach($options['sheet_names'] as $sheetId => $sheetName){
		        	if($sheetId != 1){
			            $temp_res=$this->validate_one_file($validate_file, $sheetName, $this->upload_xlsx_dir.'/'.$options['slug'].'_sheet_'.$sheetId.'.json');
			        } else {
			        	$temp_res=$this->validate_one_file($validate_file, $sheetName, $this->upload_xlsx_dir.'/'.$options['slug'].'.json');
			        }

			        if( $temp_res == false )
			          	$res='fail';
		        }
	        }

        }else{
            $res = 'file_not_found';
        }
        
    }

    return $res;
 }

function validate_one_file($slug, $sheetName, $file){

	$res=true;

	$error=array();

	$image_ext_array=array('jpeg', 'jpg', 'png', 'rar');

 	if(!file_exists($file))
 	{
 		$res=false;
 		$error[0]=$slug;
 		$error[1]=$sheetName;
 		$error[2]="File Not Found: ".$file;
 		array_push($this->validate_excel_result, $error);
 		return false;
 	}

 	$content=(array) json_decode(file_get_contents($file));

 	//validate1: empty
 	//validate2: FistName: String, Last Name: String, Youtubelink: url, CostB: Float, CostA: float, LOGO: FileName(*.jpg, *.jpeg, *.png, *.rar), Ad: FileName(*.jpg, *.jpeg, *.png, *.rar)

 	$row_count=count($content);
 	if($row_count == 0)
 		return true;

 	$col_count=count($content[0]);

 	if($col_count != 7)
 	{
 		$error="Column Count should be 7: First Name, Last Name, Video Link, Cost Before, Cost After, Logo, Ad";
 		array_push($this->validate_excel_result, $error);
 		return false;
 	}


 	for($row=1; $row<$row_count; $row++){
 		$one_row=$content[$row];

 		for($col=0; $col<$col_count ; $col++){

 			$data=$one_row[$col];
 			$real_row=$row+1;
 			$real_col=$col+1;

			if(empty($data))
			{
				$error=array($slug, $sheetName, 'Row: '.$real_row.' Col: '.$real_col.' Data Empty');
				array_push($this->validate_excel_result, $error);
				$res=false;
				continue;
			} elseif (($col == 0 || $col == 1 ) && ( ! is_string($data) )) {

	 	   		$error=array($slug, $sheetName, 'Row: '.$real_row.' Col: '.$real_col.' Should Be String');
	 	   		array_push($this->validate_excel_result, $error);
	 	   		$res=false;

 			} elseif (($col == 2 ) && (!filter_var($data, FILTER_VALIDATE_URL))){

	 	   		$error=array($slug, $sheetName, 'Row: '.$real_row.' Col: '.$real_col.' Should Be Valid Video Link');
	 	   		array_push($this->validate_excel_result, $error);
	 	   		$res=false;

 			} elseif ((($col == 3 ) || ($col == 4) )&& ( ! is_numeric($data) )){

	 	   		$error=array($slug, $sheetName, 'Row: '.$real_row.' Col: '.$real_col.' Should Be Number');
	 	   		array_push($this->validate_excel_result, $error);
	 	   		$res=false;

	 	   	} elseif( (($col == 5)  || ($col == 6)) ) {
	 	   		$info = new SplFileInfo($data);
	 	   		$ext = $info->getExtension();
	 	   		$ext=strtolower($ext);
	 	   		if(!in_array($ext, $image_ext_array)){
	 	   			$error=array($slug, $sheetName, 'Row: '.$real_row.' Col: '.$real_col.' Should Be Valid Image name');
	 	   			array_push($this->validate_excel_result, $error);
	 	   			$res=false;
	 	   		}
	 	   	} else {

	 	   	}
 		}//end column
 	}//end row

 	return $res;
 }



 function validate_logo_files($validate_files){
    
      
    if(!is_array($validate_files)){
        return 'fail';
    }
	$res='success';

    foreach($validate_files as $validate_file){
        
        $options_file = $this->upload_xlsx_dir.'/'.$validate_file.'.options.json';
        
        if(file_exists($options_file)){
            $options = (array) json_decode(file_get_contents($options_file));

	        if(isset($options['sheet_names'])){
		        foreach($options['sheet_names'] as $sheetId => $sheetName){
		        	if($sheetId != 1){
			            $temp_res=$this->validate_image_file($validate_file, $sheetName, $this->upload_xlsx_dir.'/'.$options['slug'].'_sheet_'.$sheetId.'.json', 0);
			        } else {
			        	$temp_res=$this->validate_image_file($validate_file, $sheetName, $this->upload_xlsx_dir.'/'.$options['slug'].'.json', 0);
			        }

			        if( $temp_res == false )
			          	$res='fail';
		        }
	        }

        }else{
            $res = 'file_not_found';
        }
        
    }

    return $res;
 }


function validate_image_file($slug, $sheetName, $file, $la){
	$res=true;

	$error=array();

	$image_ext_array=array('jpeg', 'jpg', 'png', 'rar');

 	if(!file_exists($file))
 	{
 		$res=false;
 		$error[0]=$slug;
 		$error[1]=$sheetName;
 		$error[2]="File Not Found: ".$file;
 		array_push($this->validate_excel_result, $error);
 		return false;
 	}

 	$content=(array) json_decode(file_get_contents($file));


 	$row_count=count($content);
 	if($row_count == 0)
 		return true;

 	$col_count=count($content[0]);

 	for($row=1; $row<$row_count; $row++){
 		if($la == 0)
 		{
 			$one_image=$content[$row][5];
 		}
 		else{
 			$one_image=$content[$row][6];
 		}

 		$real_row=$row+1;

		if(!$this->file_exists_in_ppc_or_uploads($one_image, $la)){
		
			$error=array($slug, $sheetName, 'Row: '.$real_row.' FILENAME: '.$one_image.' FAILURE');
	 	   	array_push($this->validate_excel_result, $error);
	 	   	$res=false;

		}
 		
 	}//end row

 	return $res;
}


function file_exists_in_ppc_or_uploads($filename, $la){
 	
    $w2=$this->uploads_cm_dir;//current uplaods/yy/mm/

 	if($la == 0)
 	{
 		$filename1=$this->upload_logo_dir.DIRECTORY_SEPARATOR.$filename;
 	} else {
 		$filename1=$this->upload_ad_dir.DIRECTORY_SEPARATOR.$filename;
 	}

 	$filename2=$this->uploads_cm_dir.DIRECTORY_SEPARATOR.$filename;

 	if(file_exists($filename1))
 		return true;

 	if(file_exists($filename2))
 		return true;
 	
 	//find all sudir of uploads
 	$subdirs = glob($this->uploads_dir.'/*', GLOB_ONLYDIR);
 	if($subdirs)
 	{
 		foreach ($subdirs as $subdir) {
 			$filename2 = $subdir.DIRECTORY_SEPARATOR.$filename;
 			if( ($subdir != $this->uploads_cm_dir) && file_exists($filename2))
 				return true;
 		}
 	}

}



 function validate_ad_files($validate_files){
 	  

    if(!is_array($validate_files)){
        return 'fail';
    }
	$res='success';

    foreach($validate_files as $validate_file){
        
        $options_file = $this->upload_xlsx_dir.'/'.$validate_file.'.options.json';
        
        if(file_exists($options_file)){
            $options = (array) json_decode(file_get_contents($options_file));

	        if(isset($options['sheet_names'])){

		        foreach($options['sheet_names'] as $sheetId => $sheetName){
		        	if($sheetId != 1){
			            $temp_res=$this->validate_image_file($validate_file, $sheetName, $this->upload_xlsx_dir.'/'.$options['slug'].'_sheet_'.$sheetId.'.json', 1);
			        } else {
			        	$temp_res=$this->validate_image_file($validate_file, $sheetName, $this->upload_xlsx_dir.'/'.$options['slug'].'.json', 1);
			        }

			        if( $temp_res == false )
			          	$res='fail';
		        }
	        }

        }else{
            $res = 'file_not_found';
        }
        
    }

    return $res;
 }


 function create_personal_pages($create_files){
	
    if(!is_array($create_files)){
        return 'fail';
    }
	$res='success';

    foreach($create_files as $create_file){
        
        $options_file = $this->upload_xlsx_dir.'/'.$create_file.'.options.json';
        
        if(file_exists($options_file)){
            $options = (array) json_decode(file_get_contents($options_file));

	        if(isset($options['sheet_names'])){
	        	$i = 1;
		        foreach($options['sheet_names'] as $sheetId => $sheetName){
		        	if($sheetId != 1){
			            $temp_res=$this->create_one_file($create_file, $sheetName, $this->upload_xlsx_dir.'/'.$options['slug'].'_sheet_'.$sheetId.'.json');
			        } else {
			        	$temp_res=$this->create_one_file($create_file, $sheetName, $this->upload_xlsx_dir.'/'.$options['slug'].'.json');
			        }

			        if( $temp_res == false )
			          	$res='fail';
			    }

	        }

        }else{
            $res = 'file_not_found';
        }
        
    }

    return $res;
}

function create_one_file($slug, $sheetName, $file)
{
	$res=true;

	$error=array();

 	if(!file_exists($file))
 	{
 		$error[0]=$slug;
 		$error[1]=$sheetName;
 		$error[2]="File Not Found: ".$file;
 		array_push($this->create_pp_result, $error);
 		return false;
 	}

 	$content=(array) json_decode(file_get_contents($file));


 	$row_count=count($content);
 	if($row_count == 0)
 		return true;

 	$col_count=count($content[0]);

 	for($row=1; $row<$row_count; $row++){

		$one_pp_array=$content[$row];

 		$real_row=$row+1;

		if(!$this->create_personal_page($one_pp_array)){
		
			$error=array($slug, $sheetName, 'Row: '.$real_row.' Create FAILURE');
	 	   	array_push($this->create_pp_result, $error);
	 	   	$res=false;

		}
 		
 	}//end row

 	return $res;
}




function create_personal_page($page_array){


	$page_title=$page_array[0].' '.$page_array[1];

	$the_page = get_page_by_title($page_title);

	if (!$the_page)
	{
		// Create post object
		$_p = array();
		$_p['post_title']     = $page_title;
		$_p['post_content']   = "This text may be overridden by the plugin. You shouldn't edit it.";
		$_p['post_status']    = 'publish';
		$_p['post_type']      = 'page';
		$_p['comment_status'] = 'closed';
		$_p['ping_status']    = 'closed';
		$_p['post_category'] = array(1); // the default 'Uncatrgorised'

		// Insert the post into the database: posts table
		$page_id = wp_insert_post($_p);

	} else {
		$page_id = $the_page->ID;
	}


	if($page_id)
	{
		//get custom field from xls data
		$custom_pcfa=$this->make_custom_pcfa($page_array);

		//set custom field
		$this->add_custom_field_to_page($page_id, $custom_pcfa);
	}

	return true;

}



function make_custom_pcfa( $page_array){

	$cpcfa=array();
	$cpcfa["personal_last_name"]=$page_array[0];
	$cpcfa["personal_first_name"]=$page_array[1];
	$cpcfa["personal_youtube_url"]=$page_array[2];
	$cpcfa["personal_bt_before_value"]=$page_array[3];
	$cpcfa["personal_bt_after_value"]=$page_array[4];


	$logo_img = $page_array[5];
	$ad_img = $page_array[6];

	//Image processing
	$logo_img = $this->get_real_img_url($logo_img, 0);
	$ad_img = $this->get_real_img_url($ad_img, 1);

	$cpcfa["personal_logo"]=$logo_img;
	$cpcfa["personal_ad_img"]=$ad_img;

	return $cpcfa;
}

function get_real_img_url($filename, $la){

 	if($la == 0)
 	{
 		$filename1=$this->upload_logo_dir.DIRECTORY_SEPARATOR.$filename;
 		$w1 = $this->upload_plugin_url.'/image/Logo/'.$filename;
 	} else {
 		
 		$filename1=$this->upload_ad_dir.DIRECTORY_SEPARATOR.$filename;
 		$w1 = $this->upload_plugin_url.'/image/Ad/'.$filename;
 	}

 	$filename1 = str_replace('\\', '/', $filename1);
 	$w1 = str_replace('\\', '/', $w1);

 	if(file_exists($filename1))
 	{
 		return $w1;
 	}

 	$filename2 = $this->uploads_cm_dir.DIRECTORY_SEPARATOR.$filename;
 	$w2 = $this->uploads_cm_url.'/'.$filename;

 	$filename2 = str_replace('\\', '/', $filename2);
 	$w2 = str_replace('\\', '/', $w2);

 	if (file_exists($filename2)){
 		return $w2;
 	}

 	$subdirs = glob($this->uploads_dir.'/*', GLOB_ONLYDIR);

 	if ($subdirs)
 	{
 		foreach ($subdirs as $subdir) {
 			$filename3= $subdir.DIRECTORY_SEPARATOR.$filename;
 			$fileurl = $this->uploads_url.'/'.(basename(dirname($subdir))).'/'.(basename($subdir)).$filename;

 			if(($subdir != $this->uploads_cm_dir) && (file_exists($filename3)))
 				return $fileurl;
 		}
 	}

}


function get_default_pcfa(){
  	$this->pcfa['_wp_page_template'] = 'Personal-page-template.php';
  	$this->pcfa['personal_bt_before_title'] = 'Cost Per Lead Before';
  	$this->pcfa['personal_bt_before_value'] = '40';
  	$this->pcfa['personal_bt_after_title'] = 'Cost Per Lead After';
  	$this->pcfa['personal_bt_after_value'] = '-20';
  	$this->pcfa['personal_p-1'] = 'Learn more about my guarantee to increase your sales an make your money.';
  	$this->pcfa['personal_p-2'] = 'Case Studies that demonstrate my ability to deliver results.';
  	$this->pcfa["personal_help_button"] = "See Proof";
  	$this->pcfa["personal_see_button"] = "Help Me Increase My Sales";
  	$this->pcfa["personal_ad_title"] = "Who's Getting All Your Money?";
  	$this->pcfa["personal_youtube_url"] = "https://www.youtube.com/embed/p2qhmgxPrsk?feature=oembed";
}



function add_custom_field_to_page($page_id, $custom_pcfa)
{
	/**
	* set post meta to current page or created new page
	*
	*	$post_meta=get_post_meta($page_id, '', false);
	*
	* 	["_edit_last"]=> array(1) { [0]=> string(1) "1" }
	*	["_edit_lock"]=> array(1) { [0]=> string(12) "1468072304:1" }
	*	["_wp_page_template"]=> array(1) { [0]=> string(26) "Personal-page-template.php" }
	*	["personal_logo"]=> array(1) { [0]=> string(2) "35" }
	*	["_personal_logo"]=> array(1) { [0]=> string(19) "field_57805a2eb7e70" }
	*	["personal_bt_before_title"]=> array(1) { [0]=> string(20) "Cost Per Lead Before" }
	*	["_personal_bt_before_title"]=> array(1) { [0]=> string(19) "field_57805a89b7e71" }
	*	["personal_bt_before_value"]=> array(1) { [0]=> string(2) "40" }
	*	["_personal_bt_before_value"]=> array(1) { [0]=> string(19) "field_57805bf6b7e72" }
	*	["personal_bt_after_title"]=> array(1) { [0]=> string(19) "Cost Per Lead After" }
	*	["_personal_bt_after_title"]=> array(1) { [0]=> string(19) "field_57805c51b7e73" }
	*	["personal_bt_after_value"]=> array(1) { [0]=> string(3) "-20" }
	*	["_personal_bt_after_value"]=> array(1) { [0]=> string(19) "field_57805c95b7e74" }
	*	["personal_ad_img"]=> array(1) { [0]=> string(2) "38" }
	*	["_personal_ad_img"]=> array(1) { [0]=> string(19) "field_57805ce9b7e75" }
	*	["personal_ad_title"]=> array(1) { [0]=> string(29) "Who's Getting All Your Money?" }
	*	["_personal_ad_title"]=> array(1) { [0]=> string(19) "field_57805d08b7e76" }
	*	["personal_content_title"]=> array(1) { [0]=> string(19) "Andrew Goldstein..." }
	*	["_personal_content_title"]=> array(1) { [0]=> string(19) "field_57805d95b7e77" }
	*	["personal_p-1"]=> array(1) { [0]=> string(72) "Learn more about my guarantee to increase your sales an 	make your money." }
	*	["_personal_p-1"]=> array(1) { [0]=> string(19) "field_57805eb7b7e78" }
	*	["personal_help_button"]=> array(1) { [0]=> string(25) "Help Me Increase My Sales" }
	*	["_personal_help_button"]=> array(1) { [0]=> string(19) "field_57805f28b7e79" }
	*	["personal_help_button_link"]=> array(1) { [0]=> string(1) "1" }
	*	["_personal_help_button_link"]=> array(1) { [0]=> string(19) "field_57805f66b7e7a" }
	*	["personal_p-2"]=> array(1) { [0]=> string(60) "Case Studies that demonstrate my ability to deliver results." }
	*	["_personal_p-2"]=> array(1) { [0]=> string(19) "field_57805f98b7e7b" }
	*	["personal_see_button"]=> array(1) { [0]=> string(9) "See Proof" }
	*	["_personal_see_button"]=> array(1) { [0]=> string(19) "field_57805fe3b7e7c" }
	*	["personal_see_button_link"]=> array(1) { [0]=> string(1) "1" }
	*	["_personal_see_button_link"]=> array(1) { [0]=> string(19) "field_5780600db7e7d" }
	*	["personal_youtube_url"]=> array(1) { [0]=> string(40) "http://www.youtube.com/embed/oHg5SJYRHA0" }
	*	["_personal_youtube_url"]=> array(1) { [0]=> string(19) "field_57806043b7e7e" }
	*	["personal_first_name"]=> array(1) { [0]=> string(6) "Andrew" }
	*	["_personal_first_name"]=> array(1) { [0]=> string(19) "field_57806bc42f674" }
	*	["personal_last_name"]=> array(1) { [0]=> string(9) "Goldstein" }
	*	["_personal_last_name"]=> array(1) { [0]=> string(19) "field_57806be42f675" 
	*/

	//set default custom field

	foreach ($this->pcfa as $key => $value) {
		if ( ! add_post_meta( $page_id, $key, $value, true ) ) {
   			update_post_meta( $page_id, $key, $value );
		}
	}

	foreach ($custom_pcfa as $key => $value) {
		if ( ! add_post_meta( $page_id, $key, $value, true ) ) { 
   			update_post_meta( $page_id, $key, $value );
		}
	}
}
################################################################################


	/**
	 * Return an instance of this class.
	 *
	 * @since     1.0.0
	 *
	 * @return    object    A single instance of this class.
	 */
	public static function get_instance() {

		/*
		 * @TODO :
		 *
		 * - Uncomment following lines if the admin class should only be available for super admins
		 */
		/* if( ! is_super_admin() ) {
			return;
		} */

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	/**
	 * Register and enqueue admin-specific style sheet.
	 *
	 * @TODO:
	 *
	 * - Rename "Plugin_Name" to the name your plugin
	 *
	 * @since     1.0.0
	 *
	 * @return    null    Return early if no settings page is registered.
	 */
	public function enqueue_admin_styles() {

		if ( ! isset( $this->plugin_screen_hook_suffix ) ) {
			return;
		}

		$screen = get_current_screen();

		if ( $this->plugin_screen_hook_suffix == $screen->id ) {
			wp_enqueue_style( $this->plugin_slug .'-admin-styles', plugins_url( 'assets/css/admin.css', __FILE__ ), array(), PPC_Builder::VERSION );
		}

	}

	/**
	 * Register and enqueue admin-specific JavaScript.
	 *
	 * @TODO:
	 *
	 * - Rename "Plugin_Name" to the name your plugin
	 *
	 * @since     1.0.0
	 *
	 * @return    null    Return early if no settings page is registered.
	 */
	public function enqueue_admin_scripts() {

		if ( ! isset( $this->plugin_screen_hook_suffix ) ) {
			return;
		}

		$screen = get_current_screen();
		if ( $this->plugin_screen_hook_suffix == $screen->id ) {
			wp_enqueue_script( $this->plugin_slug . '-admin-script', plugins_url( 'assets/js/admin.js', __FILE__ ), array( 'jquery' ));

			wp_enqueue_script( 'jquery' );
		}

	}

	/**
	 * Register the administration menu for this plugin into the WordPress Dashboard menu.
	 *
	 * @since    1.0.0
	 */
	public function add_plugin_admin_menu() {

		/*
		 * Add a settings page for this plugin to the Settings menu.
		 *
		 * NOTE:  Alternative menu locations are available via WordPress administration menu functions.
		 *
		 *        Administration Menus: http://codex.wordpress.org/Administration_Menus
		 *
		 * @TODO:
		 *
		 * - Change 'Page Title' to the title of your plugin admin page
		 * - Change 'Menu Text' to the text for menu item for the plugin settings page
		 * - Change 'manage_options' to the capability you see fit
		 *   For reference: http://codex.wordpress.org/Roles_and_Capabilities
		 */
		$this->plugin_setting_hook_suffix = add_options_page(
			__( 'PPC Builder Settings', $this->plugin_slug ),
			__( 'PPC Builder', $this->plugin_slug ),
			'manage_options',
			$this->plugin_slug,
			array( $this, 'display_plugin_admin_page' )
		);

	}

	public function template_exists($template_name){
		$template_file_name=$this->current_theme_directory.'/'.$template_name.'.php';
		if(file_exists($template_file_name))
			return true;
		return false;
	}


	/**
	* check if personal page template file exists in current theme directory, if not copy file from plugin
	*/
	public function add_personal_template() {

		if(!$this->template_exists('Personal-page-template'))
		{
			$src_file=plugins_url('includes/Personal-page-template.php', __FILE__);
			
			$target=$this->current_theme_directory.DIRECTORY_SEPARATOR.'Personal-page-template.php';
			copy($src_file, $target);
		}

	}

	/**
	 * Render the settings page for this plugin.
	 *
	 * @since    1.0.0
	 */
	public function display_plugin_admin_page() {
		include_once( 'views/admin.php' );
	}
    
	/**
	 * Render the settings page for this plugin.
	 *
	 * @since    1.0.0
	 */
	public function display_plugin_admin_menu_page() {
	   
        //plugins_url( 'images/wordpress.png' , __FILE__ )
        

        if (isset($_GET['page'])){
        	$this->admin_plugin_url   = admin_url( "options-general.php?page=".$_GET["page"] );	
        }

        if(!is_dir($this->upload_plugin_dir)){
            $createUploadFolderStarted  = true;
            $createUploadFolderRes      = mkdir($this->upload_plugin_dir);
        }
        if(!is_dir($this->upload_plugin_dir)){
            $uploadFolderDoesNotExists = true;
        }

        if (!is_dir($this->upload_xlsx_dir))
        {
        	mkdir($this->upload_xlsx_dir);
        }

        if (!is_dir($this->upload_img_dir))
        {
        	mkdir($this->upload_img_dir);
        }
       
        if (!is_dir($this->upload_ad_dir))
        {
        	mkdir($this->upload_ad_dir);
        }

        if (!is_dir($this->upload_logo_dir))
        {
        	mkdir($this->upload_logo_dir);
        }
       
        if(isset($_POST['action1']) && $_POST['action1']=='delete'){
            $deleteStarted = true;
            if(isset($_POST['apply_slugs']))
            	$deleteResult = $this->delete_excel_files($_POST['apply_slugs']);
            else
            	$deleteResult='not_selected';
        }

        if(isset($_POST['action1']) && $_POST['action1']=='validate_excel'){
            $validateExcelStarted = true;

            if(isset($_POST['apply_slugs']))
            {
            	$slug=$_POST['apply_slugs'];

            	$validateExcelResult = $this->validate_excel_files($slug);
            }
            else
            	$validateExcelResult='not_selected';
        }


        if(isset($_POST['action1']) && $_POST['action1']=='validate_logo'){
            $validateLogoStarted = true;
            if(isset($_POST['apply_slugs']))
            {
            	$slug=$_POST['apply_slugs'];
           		$validateLogoResult = $this->validate_excel_files($slug);

           		if($validateLogoResult!=='success'){
           			$validateLogoResult = 'excel_validate_need';	
           		} else {
           			$validateLogoResult=$this->validate_logo_files($slug);
           		}
            	
            } else {
            	$validateLogoResult='not_selected';
            }
        }


		if(isset($_POST['action1']) && $_POST['action1']=='validate_ad'){
            $validateAdStarted = true;
            if(isset($_POST['apply_slugs']))
            {
            	$slug=$_POST['apply_slugs'];
           		
           		$validateAdResult = $this->validate_excel_files($slug);

           		if($validateAdResult!=='success'){
           			$validateAdResult = 'excel_validate_need';	
           		} else {
           			$validateAdResult=$this->validate_ad_files($slug);
           		}

            } else {
            	$validateAdResult='not_selected';
            }	
        }


		if(isset($_POST['action1']) && $_POST['action1']=='build'){
            $buildPPCStarted = true;
            if(isset($_POST['apply_slugs']))
            {
            	$slug=$_POST['apply_slugs'];
           		
           		$buildPPCResult = $this->create_personal_pages($slug);

            } else {
            	$buildPPCResult='not_selected';
            }	
        }

       
        if (isset($_FILES['file'])) {
            $uploadStarted  = true;
            $uploadResult     = $this->create_excel_file($_POST['file_name']); 
        }
       
        $file_data = $this->getFileList();
       
		include_once( 'views/admin-menu.php' );
	}




	/**
	 * Add settings action link to the plugins page.
	 *
	 * @since    1.0.0
	 */
	public function add_action_links( $links ) {

		return array_merge(
			array(
				'settings' => '<a href="' . admin_url( 'options-general.php?page=' . $this->plugin_slug ) . '">' . __( 'Settings', $this->plugin_slug ) . '</a>'
			),
			$links
		);

	}

	/**
	 * NOTE:     Actions are points in the execution of a page or process
	 *           lifecycle that WordPress fires.
	 *
	 *           Actions:    http://codex.wordpress.org/Plugin_API#Actions
	 *           Reference:  http://codex.wordpress.org/Plugin_API/Action_Reference
	 *
	 * @since    1.0.0
	 */
	public function action_method_name() {
		// @TODO: Define your action hook callback here
	}

	/**
	 * NOTE:     Filters are points of execution in which WordPress modifies data
	 *           before saving it or sending it to the browser.
	 *
	 *           Filters: http://codex.wordpress.org/Plugin_API#Filters
	 *           Reference:  http://codex.wordpress.org/Plugin_API/Filter_Reference
	 *
	 * @since    1.0.0
	 */
	public function filter_method_name() {
		// @TODO: Define your filter hook callback here
	}


}
