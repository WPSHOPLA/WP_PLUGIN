<?php
/**
 * Represents the view for the administration dashboard.
 *
 * This includes the header, options, and other information that should provide
 * The User Interface to the end user.
 *
 * @package   PPC_Builder
 * @author    Vincent Schroeder <info@webteilchen.de>
 * @license   GPL-2.0+
 * @link      http://webteilchen.de
 * @copyright 2015 Vincent Schroeder
 */

?>



<?php if (isset($createUploadFolderStarted)) { ?>
    
    <?php if($createUploadFolderRes){ ?>
        <div id="message" class="updated fade"><p>Upload folder "wp-content/uploads/ppc-builder" successfully created. </p></div>
    <?php }else{ ?>
        
    <?php }?>

<?php } ?>


<?php if (isset($uploadFolderDoesNotExists)) { ?>
    
<div id="message" class="error fade"><p>Can't create upload folder "wp-content/uploads/ppc-builder". Please create it manually and make it writable. </p></div>

<?php } ?>


<?php if(isset($deleteStarted)){ ?>
    
    <?php if($deleteResult===TRUE){ ?>
        <div id="message" class="updated fade"><p>Files are successfully deleted! </p></div>
    <?php }elseif ($deleteResult == 'not_selected'){ ?>
        <div id="message" class="error fade"><p>Please choose File to delete.</p></div>
    <?php }else{ ?>
        <div id="message" class="error fade"><p>File deletion failed, or have already been deleted before.</p></div>
    <?php  }?>

<?php  }?>


<?php if(isset($validateExcelStarted)){ ?>
    
    <?php if($validateExcelResult=='success'){ ?>
        <div id="message" class="updated fade"><p>Validation Excel Succeded!</p></div>
    <?php }elseif ($validateExcelResult == 'not_selected'){ ?>
        <div id="message" class="error fade"><p>Please choose File to validate.</p></div>
    <?php }elseif ($validateExcelResult == 'file_not_found'){ ?>
        <div id="message" class="error fade"><p>Selected Excel File doesn't exist.</p></div>
    <?php  }else {?>
        <div id="message" class="error fade"><p>Validation Failed.</p></div>
    <?php  }?>        

<?php  }?>


<?php if(isset($validateLogoStarted)){ ?>
    
    <?php if($validateLogoResult=='success'){ ?>
        <div id="message" class="updated fade"><p>Validation Logo Succeded!</p></div>
    <?php }elseif ($validateLogoResult == 'excel_validate_need'){ ?>
        <div id="message" class="error fade"><p>You need to validate the Excel file first.</p></div>
    <?php }elseif ($validateLogoResult == 'not_selected'){ ?>
        <div id="message" class="error fade"><p>Please choose File to validate.</p></div>
    <?php }elseif ($validateLogoResult == 'file_not_found'){ ?>
        <div id="message" class="error fade"><p>Selected Excel File doesn't exist.</p></div>
    <?php  } else {?>
        <div id="message" class="error fade"><p>Validation Logo Failed.</p></div>
    <?php  }?>        

<?php  }?>


<?php if(isset($validateAdStarted)){ ?>
    
    <?php if($validateAdResult=='success'){ ?>
        <div id="message" class="updated fade"><p>Validation Ad Succeded!</p></div>
    <?php }elseif ($validateLogoResult == 'excel_validate_need'){ ?>
        <div id="message" class="error fade"><p>You need to validate the Excel file first.</p></div>
    <?php }elseif ($validateAdResult == 'not_selected'){ ?>
        <div id="message" class="error fade"><p>Please choose File to validate.</p></div>
    <?php }elseif ($validateAdResult == 'file_not_found'){ ?>
        <div id="message" class="error fade"><p>Selected Excel File doesn't exist.</p></div>
    <?php  } else {?>
        <div id="message" class="error fade"><p>Validation Ad Failed.</p></div>
    <?php  }?>        

<?php  }?>

<?php if(isset($buildPPCStarted)){ ?>
    
    <?php if($buildPPCResult=='success'){ ?>
        <div id="message" class="updated fade"><p>Build Personal Pages Succeded!</p></div>
    <?php }elseif ($buildPPCResult == 'not_selected'){ ?>
        <div id="message" class="error fade"><p>Please choose File to build.</p></div>
    <?php }elseif ($buildPPCResult == 'file_not_found'){ ?>
        <div id="message" class="error fade"><p>Selected Excel File doesn't exist.</p></div>
    <?php  } else {?>
        <div id="message" class="error fade"><p>Build Personal Pages Failed.</p></div>
    <?php  }?>        

<?php  }?>





<?php if (isset($uploadStarted)) { ?>
    
    <?php if(!$uploadResult){ ?>
        <div id="message" class="error fade"><p>Upload failed! Please give it a Name and Select a File.</p></div>
    <?php }else{ ?>
        <div id="message" class="updated fade"><p>Files are successfully uploaded! </p></div>
    <?php }?>

<?php } ?>

<?php 
    
    $ad_upload_file_dir=plugins_url( 'includes/upload_ad.php', dirname(__FILE__));
    $logo_upload_file_dir=plugins_url( 'includes/upload_logo.php', dirname(__FILE__));
    $create_pp_file=plugins_url('includes/create.php', dirname(__FILE__));
?>

<script>

$j=jQuery.noConflict();

$j(document).ready(function() {
    
    var uploader = $j('.uploader');
    
     $clone = uploader.clone( true );

     $j( ".edit-entry" ).bind( "click", function() {
            var slug = $j(this).attr("data-slug");
            $clone.prependTo('#uploader-' + slug);
            $j('.input_file_name').val(slug);
    });
    
    $j( ".add-new-file" ).bind( "click", function() {
         $j('#new-file-uploader').toggle();
    });
    
    $j("#adfileuploader").uploadFile({
        url:"<?php echo $ad_upload_file_dir;?>",
        fileName:"myfile"
    });

    $j("#logofileuploader").uploadFile({
        url:"<?php echo $logo_upload_file_dir;?>",
        fileName:"myfile"
    });




});
</script>

<div class="wrap">

	<?php screen_icon('edit-pages'); ?>
	<h2>
        Personal Page Builder
        <a href="#" class="add-new-h2 add-new-file">Create new</a>
    </h2>

    

    
    
    <h2>
        Upload Data
        <span class="ppc-desc">REQUIRED FILE TYPE: .XLS</span>
    </h2>
    <div class="postbox">
        <div class="inside ppc-upload-inside">
            <h3 class="ppc-desc">REQUIRED FIELDS:</h3>

            <table class="widefat ppc-table">
                <thead>
                    <tr>
                        <th>Client Name</th>
                        <th>Youtube link</th>
                        <th>Cost per Lead Before</th>
                        <th>After Value</th>
                        <th>Logo Name</th>       
                        <th>Ad Image name</th>    
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>COLUMN A</td>
                        <td>COLUMN B</td>
                        <td>COLUMN C</td>
                        <td>COLUMN D</td>
                        <td>COLUMN E</td>
                        <td>COLUMN F</td>
                    </tr>
                </tbody>
            </table>


            <div style="display: none;" id="new-file-uploader">
                <div id="poststuff">
                    <div id="post-body" class="metabox-holder"  style="width:520px">
                        <div id="post-body-content">
                            <div id="namediv" class="stuffbox">
                                <h3>Add new Excel File</h3>
                                <div class="inside">
                                    <form method="post" enctype="multipart/form-data">
                                        <table class="form-table" style="width:500px">
                                            <tr>
                                                <td>Name:</td>
                                                <td><input type="text" name="file_name" placeholder="Give it a name (required)"/> </td>
                                            </tr>
                                            <tr>
                                                <td>File:</td>
                                                <td><input type="file" name="file"  style="width:400px"   />Only *.xlsx Filetypes are supported</td>
                                            </tr>    
                                            <tr>
                                                <td>Upload:</td>
                                                <td><input type="submit" class="button-primary" value="Start upload" /></td>
                                            </tr>
                                        </table>
                                    </form>
                                </div>
                            </div>
                        </div><!-- /post-body-content -->
                    </div>
                </div>
            </div>  

            <div style="display: none;">
                <div class="uploader" id="uploader">
                    <form method="post" enctype="multipart/form-data">
                    <input class="input_file_name" type="hidden" name="file_name" /><input type="file" name="file"  /><input type="submit" class="button-primary" value="Start upload" />
                    </form>
                 </div>   
            </div>

            <div style="margin-top:20px;">
                <h2>Manage EXCEL Files</h2>
                <p>Select Excel Files and Validate or Build based on uploaded File Data.</p>
                <p>When Build Personal Pages, confirm that Navigation menu is already made. If not, created Page will add to menu automatically.</p>
                    <form method="post" id="ppc-mgmt">
                        <table class="widefat">
                        <thead>
                            <tr>
                                <th style="width: 60px;text-align: center;">Action</th>
                                <th style="width: 60px;text-align: center;">Edit</th>
                                <th>Name</th>
                                <th>File Size</th>       
                                 <th>Last Update</th>    
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th style="text-align: center;">Action</th>
                                <th style="text-align: center;">Edit</th>
                                <th>Name</th>
                                <th>File Size</th>
                                <th>Last Update</th>       
                                
                            </tr>
                        </tfoot>
                        <tbody>
                        <?php 
                        if(is_array($file_data))
                        foreach($file_data as $file){ 
                        ?>
                        
                           <tr>
                             <td style="text-align: center;"><input type="checkbox" name="apply_slugs[]" value="<?php echo $file['slug'];?>" /></td>
                             <td style="text-align: center;"><a href="#" class="edit-entry" data-slug="<?php echo $file['slug'];?>">Edit</a></td>
                             <td class="row-title">
                                <a href="<?php echo $this->upload_base_url.'/'.$file['filename']; ?>" target="_blank"><?php echo $file['slug']; ?></a>
                                <div id="uploader-<?php echo $file['slug'];?>"> </div>
                             </td>
                             <!--td><code>[ppc_builder name="<?php echo $file['slug'];?>"]<!--/code></td-->
                             <!--$data = ppc_builder_get("<?php echo $file['slug'];?>");-->
                             <td><?php echo $this->formatSizeUnits($file['filesize']); ?></td>
                             <td><?php echo date(get_option('date_format'),$file['upload_time']); ?> | <?php echo date(get_option('time_format'),$file['upload_time']); ?></td>
                         </tr>
                        
                        <?php } ?>
                        
                        </tbody>
                        </table>
                        
                        <div class="tablenav bottom">
                            <div class="alignleft actions bulkactions">
                                <select name="action1">
                                    <option value="-1" selected="selected">Select action</option>
                                    <option value="delete" class="hide-if-no-js">Delete</option>
                                    <option value="validate_excel" class="hide-if-no-js">Validate Excel File</option>
                                    <option value="validate_logo" class="hide-if-no-js">Validate Logo Image</option>
                                    <option value="validate_ad" class="hide-if-no-js">Validate Ad Image</option>
                                    <option value="build" class="hide-if-no-js">Build</option>
                                </select>
                                <input class="button action" type="submit" name="submit" value="Apply" />
                            </div>
                            <div class="alignleft actions">
                            </div>
                            <br class="clear"/>
                        </div>
                    
                    </form>
            </div>

            <?php
                $user_info = wp_get_current_user();
                if(empty($user_info->user_firstname )){
                    $show_username = ucfirst($user_info->user_login);
                }else{
                    $show_username = $user_info->user_firstname;
                }
            ?>

            <?php if(!empty($uploadResult['jsonData'])):?>
          
                <h2 class="ppc-import-preview">Import Preview</h2>
                <div style="overflow:scroll;height:300px;width:100%;font-size:11px;color:#fff;background-color:#000;">
                    <pre><?php
                        $count = 1;
                        foreach($uploadResult['jsonData'] as $data){
                           echo "################ SHEET $count #########################";
                            echo "\r\n";
                            print_r( json_decode($data));
                            $count++;
                        }
                        ?></pre>
                </div>

            <?php endif; ?>

            <?php if(!empty($this->validate_excel_result)):?>
                <div class="ppc-excel-result">
                    <sub class="ppc-validate-title">SUCCESS OR FAILURE</sub>
                    <div class="ppc-validate-result">
                        <p class="upload-failure">
                            <?php
                                foreach ($this->validate_excel_result as $key => $error_one) {

                                    $error="";
                                    $error="File: ".$error_one[0]." Sheet: ".$error_one[1]." ".$error_one[2]."<br>";
                                    echo $error;
                                }

                            ?>
                        </p>

                    </div>
                </div>
            <?php endif;
                unset($this->validate_excel_result);
            ?>

           <div class="ppc-upload" id="upload_logo_outer">
                <div class="ppc-line ppc-line-title">
                    <div class="col-left">
                        <h4>Upload Logo</h4>
                    </div>
                    <div class="col-right">
                        <h4 class="upload-desc">(.png, .jpg, jpeg and .rar file can be accepted)</h4>
                    </div>
                </div>
                <div class="ppc-line ppc-upload-image">
                    <div class="col-left">
                        <div id="logofileuploader">Upload</div>
                    </div>
                    <div class="col-right">
                        
                    </div>
                </div>
            </div>

            <div class="ppc-upload" id="upload_ad_outer">
                <div class="ppc-line ppc-line-title">
                    <div class="col-left">
                        <h4>Upload AD</h4>
                    </div>
                    <div class="col-right">
                        <h4 class="upload-desc">(.png, .jpg, jpeg and .rar file can be accepted)</h4>
                    </div>
                </div>
                <div class="ppc-line ppc-upload-image">
                    <div class="col-left">
                        <div id="adfileuploader">Upload</div>
                    </div>
                    <div class="col-right">
                        
                    </div>
                </div>
            </div>
                    
        </div>
    </div>
    
    <div id="build_outer">
        <h2>Result</h2>
        <div class="gray-div">
            <p>You can see the result of Build operation here.</p>

            <div>
                <button id='build_bt' class="button-primary" onclick="build_personal_page(progress_data)">BUILD PAGE</button>
            </div>

            <p><span id='current_build_count'>Current</span> OUT OF <span id='total_build_count'>Total</span><p>
            <div id="buildProgress">
              <div id="buildBar">
                <div id="buildlabel">0%</div>
              </div>
            </div>

            <sub class="ppc-validate-title">SUCCESS OR FAILURE</sub>
            <div class="ppc-validate-result" id = 'build_result'>
                <?php
                    if(!empty($this->create_pp_result)) {

                        echo '<p class="upload-failure">';
                
                        foreach ($this->create_pp_result as $key => $error_one) {
                            $error="";
                            $error="File: ".$error_one[0]." Sheet: ".$error_one[1]." ".$error_one[2]."<br>";
                            echo $error;
                        }

                        echo '</p>';
                    } else {
                        echo '<p class="upload-success">Build All Success</p>';
                    }
                
                    unset($this->create_pp_result);

                ?>
            </div>
        </div>

      

    </div>

    

    <script>

    function move(width) {
      var elem = document.getElementById("buildBar");
      elem.style.width = width + '%';
      document.getElementById("buildlabel").innerHTML = width * 1  + '%';
    }

    function build_personal_page(progress_data){


        var removeItem = -1;

        
        var files = [] ;
        jQuery('#ppc-mgmt input[type = checkbox]:checked').each(function() {
            files.push(jQuery(this).val());
        });

        files = jQuery.grep(files, function(value) {
            return value != removeItem;
        });


        if(files.length == 0)
        {
            alert("Select Excel File to Build Personal Pages");
            return;
        }

        var php = '<?php echo $create_pp_file; ?>';

        jQuery.ajax({
          method: "POST",
          url: php,
          data: "files="+files,
          datatype: "JSON",
          success: function(data){
            progress_data(data);
          },
          error: function(){
            alert("Error occured while building pages. Please validate and try again later.");
          }

            
        });

    }

    function progress_data(data){
        //change progress
        var current = data.current;
        var total_count = data.total_count;

        jQuery('#total_build_count').html(total_count);
        jQuery('#current_build_count').html(current);

        var go =(current / total_count ) * 100;
        
        move(go);

        if(data.result == 'fail')
        {
            var error_content='';

            jQuery('#build_result').html(error_content);
        }
    }

</script>
    
</div>
 


        <!--Temp Upload and Validate
            div class="ppc-upload" id="upload_excel">
                <div class="ppc-line">
                    <div class="col-left">
                        <input type="submit" class="button-primary" value="UPLOAD DATA"></input>
                    </div>
                    <div class="col-right">
                        <sub class="ppc-upload-result">1 OUT OF 1365</sub>
                        <div class="ppc-upload-progressbar"></div>
                    </div>
                </div>
                <div class="ppc-line">
                    <div class="col-left">
                        <button class="button-secondary">Validate</button>
                    </div>
                    <div class="col-right">
                        <sub class="ppc-validate-title">SUCCESS OR FAILURE</sub>
                        <div class="ppc-validate-result">
                            <p class="upload-failure">LINES: 2,252 NOT UPLOADED</p>
                        </div>
                    </div>
                </div>
            </div-->

